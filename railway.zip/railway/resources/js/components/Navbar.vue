<template>
    <nav
        class="fixed w-full z-[60] transition-all duration-500 font-sans"
        :class="[scrolled ? 'bg-[#0a0f1a]/95 backdrop-blur-md shadow-2xl py-3 border-b border-white/5' : 'bg-transparent py-6']"
        dir="rtl"
    >
        <div class="container mx-auto px-6">
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-3 cursor-pointer group" @click="navigateTo('home')">
                    <div class="relative">
                        <svg class="w-10 h-10 text-yellow-500 animate-spin-slow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                            <path d="M12 6V4M12 6C10.8954 6 10 6.89543 10 8C10 9.10457 10.8954 10 12 10C13.1046 10 14 9.10457 14 8C14 6.89543 13.1046 6 12 6ZM12 6V4M6 12H4M6 12C6 13.1046 6.89543 14 8 14C9.10457 14 10 13.1046 10 12C10 10.8954 9.10457 10 8 10C6.89543 10 6 10.8954 6 12ZM18 12H20M18 12C18 10.8954 17.1046 10 16 10C14.8954 10 14 10.8954 14 12C14 13.1046 14.8954 14 16 14C17.1046 14 18 13.1046 18 12ZM12 18V20M12 18C10.8954 18 10 17.1046 10 16C10 14.8954 10.8954 14 12 14C13.1046 14 14 14.8954 14 16C14 17.1046 13.1046 18 12 18Z" stroke-linecap="round"/>
                        </svg>
                    </div>
                    <div>
                        <h1 class="text-2xl font-black text-white tracking-tighter leading-none">Rail<span class="text-yellow-500">Guard</span></h1>
                        <p class="text-[10px] text-slate-500 font-mono tracking-[0.2em] uppercase mt-1">AI Inspection System</p>
                    </div>
                </div>

                <div class="hidden md:flex items-center gap-8">
                    <button v-for="link in navLinks" :key="link.id" @click="navigateTo(link.id)"
                        class="text-gray-300 hover:text-yellow-400 transition-colors relative group text-lg font-medium"
                        :class="{'text-yellow-400': currentPage === link.id}">
                        {{ link.name }}
                        <span class="absolute -bottom-1 right-0 w-0 h-0.5 bg-yellow-400 transition-all group-hover:w-full" :class="{'w-full': currentPage === link.id}"></span>
                    </button>
                </div>

                <div class="flex items-center gap-4">
                    <button @click="showLogin = true" class="px-5 py-2 text-gray-300 hover:text-white transition-colors font-medium flex items-center gap-2 group">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 transform group-hover:-translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
                        </svg>
                        <span>دخول</span>
                    </button>
                </div>
            </div>
        </div>

        <LoginPanel :isOpen="showLogin" @close="showLogin = false" />
    </nav>
</template>

<script>
import LoginPanel from '@/components/LoginPanel.vue';
export default {
    components: { LoginPanel },
    props: {
        currentPage: { type: String, default: 'home' }
    },
    data() {
        return {
            scrolled: false,
            showLogin: false,
            navLinks: [
                { name: 'الرئيسية', id: 'home' },
                { name: 'عن المشروع', id: 'about' },
                { name: 'المميزات', id: 'features' },
                { name: 'العيوب', id: 'defects' },
                { name: 'تواصل معنا', id: 'contact' }
            ]
        }
    },
    mounted() { window.addEventListener('scroll', this.handleScroll); },
    methods: {
        handleScroll() { this.scrolled = window.scrollY > 50; },
        navigateTo(pageId) { this.$emit('change-page', pageId); }
    }
}
</script>
