<template>
    <section id="inspections" class="py-24 bg-[#0a0f1a] relative overflow-hidden">
        <div class="absolute top-0 right-0 w-1/3 h-1/3 bg-blue-500/5 blur-[120px] pointer-events-none"></div>

        <div class="container mx-auto px-6 relative z-10">
            <div class="text-center mb-16" data-aos="fade-up">
                <div class="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-red-500/10 border border-red-500/20 mb-4">
                    <span class="flex h-2 w-2">
                        <span class="animate-ping absolute inline-flex h-2 w-2 rounded-full bg-red-400 opacity-75"></span>
                        <span class="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
                    </span>
                    <span class="text-red-500 font-bold text-[10px] uppercase tracking-[0.2em]">Live Detection Feed</span>
                </div>
                <h2 class="text-4xl font-black text-white mt-2 mb-6 tracking-tight">سجل الفحص الذكي</h2>
                <p class="text-slate-400 max-w-2xl mx-auto leading-relaxed">
                    استعراض لحظي للعيوب التي تم رصدها بواسطة محرك الرؤية الحاسوبية، مصنفة حسب درجة الخطورة ونسبة التأكد.
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-10 max-w-5xl mx-auto">
                <div v-for="(inspection, index) in inspections" :key="index"
                     class="group bg-slate-800/30 backdrop-blur-md rounded-[2rem] overflow-hidden border border-slate-700/50 hover:border-yellow-500/40 transition-all duration-500 shadow-2xl"
                     data-aos="fade-up"
                     :data-aos-delay="index * 150">

                    <div class="relative h-64 overflow-hidden bg-slate-900">
                        <img :src="inspection.image" :alt="inspection.title"
                             class="w-full h-full object-cover transition-transform duration-[2000ms] group-hover:scale-110 filter grayscale-[20%] group-hover:grayscale-0">

                        <div class="absolute inset-4 border border-white/10 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                            <div class="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-yellow-400"></div>
                            <div class="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-yellow-400"></div>
                            <div class="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-yellow-400"></div>
                            <div class="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-yellow-400"></div>
                        </div>

                        <div class="absolute top-0 left-0 w-full h-[2px] bg-yellow-400/50 shadow-[0_0_15px_#eab308] animate-scan-fast opacity-0 group-hover:opacity-100"></div>

                        <div class="absolute top-6 left-6" v-if="inspection.severity === 'عالية'">
                             <span class="flex items-center gap-2 bg-red-600 text-[10px] text-white px-3 py-1 rounded-full font-mono animate-pulse shadow-lg shadow-red-600/40">
                                <span class="w-1.5 h-1.5 bg-white rounded-full"></span>
                                CRITICAL_DEFECT
                             </span>
                        </div>

                        <div class="absolute bottom-6 right-6">
                            <span :class="severityClasses(inspection.severity)"
                                  class="px-5 py-2 rounded-xl text-[11px] font-black uppercase tracking-wider backdrop-blur-md shadow-2xl border border-white/10">
                                {{ inspection.type }} | {{ inspection.severity }}
                            </span>
                        </div>
                    </div>

                    <div class="p-8">
                        <div class="flex justify-between items-start mb-4">
                            <div>
                                <h3 class="text-2xl font-black text-white group-hover:text-yellow-400 transition-colors">{{ inspection.title }}</h3>
                                <div class="flex items-center gap-2 mt-2 text-slate-500 text-xs font-mono">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                    </svg>
                                    {{ inspection.location }}
                                </div>
                            </div>
                            <div class="text-left bg-slate-900/50 p-2 rounded-lg border border-slate-700/50">
                                <div class="text-[9px] text-slate-500 font-bold uppercase tracking-tighter">Confidence</div>
                                <div class="text-xl font-black text-green-500 font-mono tracking-tighter">{{ inspection.confidence }}%</div>
                            </div>
                        </div>

                        <p class="text-slate-400 text-sm leading-relaxed mb-8 h-12 overflow-hidden line-clamp-2">
                            {{ inspection.description }}
                        </p>

                        <div class="bg-slate-900/80 rounded-2xl p-5 border border-slate-700/50 mb-8">
                            <div class="flex justify-between items-center mb-3 text-[10px] font-bold text-slate-500 uppercase font-mono">
                                <span class="flex items-center gap-2">
                                    <span class="w-1 h-1 bg-yellow-400 rounded-full"></span>
                                    System Analysis
                                </span>
                                <span class="text-slate-400">{{ inspection.date }}</span>
                            </div>
                            <div class="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                                <div class="h-full bg-gradient-to-r from-yellow-500 via-orange-500 to-red-600 rounded-full transition-all duration-1000"
                                     :style="{ width: inspection.progress + '%' }"></div>
                            </div>
                        </div>

                        <button class="w-full py-4 bg-slate-800 hover:bg-yellow-500 text-white hover:text-black font-black rounded-2xl transition-all duration-300 flex items-center justify-center gap-3 group/btn border border-slate-700 hover:border-yellow-400 shadow-xl">
                            <span>فتح ملف التحقيق الكامل</span>
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 transform group-hover/btn:translate-x-[-5px] transition-transform rotate-180" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M15 19l-7-7 7-7" />
                            </svg>
                        </button>
                    </div>
                </div>
            </div>

            <div class="text-center mt-20">
                <button class="group relative px-12 py-5 bg-transparent overflow-hidden rounded-2xl inline-block">
                    <div class="absolute inset-0 border-2 border-slate-800 rounded-2xl group-hover:border-yellow-500/50 transition-colors"></div>
                    <div class="absolute inset-0 bg-yellow-500 transform translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
                    <span class="relative text-slate-400 group-hover:text-black font-black transition-colors flex items-center gap-4">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4" />
                        </svg>
                        الوصول إلى السجلات التاريخية الكاملة
                    </span>
                </button>
            </div>
        </div>
    </section>
</template>

<script>
export default {
    methods: {
        severityClasses(severity) {
            const config = {
                'عالية': 'bg-red-500/20 text-red-500 border-red-500/30',
                'متوسطة': 'bg-yellow-500/20 text-yellow-500 border-yellow-500/30',
                'منخفضة': 'bg-green-500/20 text-green-500 border-green-500/30'
            };
            return config[severity] || 'bg-slate-500/20 text-slate-500';
        }
    },
    data() {
        return {
            inspections: [
                {
                    image: 'https://matsda2sh.com/graph/uploads/870x500/content_images/2021_04_6556-1-645x427-1.jpeg',
                    title: 'تصدع هيكلي عميق',
                    type: 'كسر حاد',
                    severity: 'عالية',
                    date: '15 يناير 2026',
                    location: 'إقليم الدلتا - كم 42.8',
                    confidence: 99.8,
                    progress: 100,
                    description: 'تم رصد كسر طولي يتجاوز 15 سم في رأس القضيب، مما يشكل خطراً وشيكاً على سلامة المسار.'
                },
                {
                    image: 'https://5.imimg.com/data5/SELLER/Default/2023/9/345820266/HZ/GI/JB/76043908/mild-steel-dg-crane-rail-1000x1000.jpg',
                    title: 'تآكل سطحي منتظم',
                    type: 'تآكل',
                    severity: 'متوسطة',
                    date: '14 يناير 2026',
                    location: 'خط الصعيد - كم 210',
                    confidence: 94.2,
                    progress: 75,
                    description: 'تآكل ناتج عن الاحتكاك المستمر يتطلب جدولة صيانة دورية خلال الـ 30 يوماً القادمة.'
                }
            ]
        }
    }
}
</script>

<style scoped>
@keyframes scan-fast {
    0% { top: 0%; }
    100% { top: 100%; }
}

.animate-scan-fast {
    animation: scan-fast 2.5s linear infinite;
}

.group:hover img {
    filter: contrast(115%) brightness(85%) saturate(120%);
}

.line-clamp-2 {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

h2, h3, p, span {
    font-family: 'Inter', 'Noto Sans Arabic', sans-serif;
}
</style>
