<template>
    <section class="py-24 bg-gradient-to-b from-gray-900 to-black relative overflow-hidden">
        <!-- خلفية متحركة -->
        <div class="absolute inset-0">
            <div class="absolute top-0 left-0 w-full h-full">
                <div v-for="n in 5" :key="n"
                     class="absolute rounded-full mix-blend-screen filter blur-3xl opacity-20 animate-pulse"
                     :style="{
                         width: Math.random() * 400 + 200 + 'px',
                         height: Math.random() * 400 + 200 + 'px',
                         left: Math.random() * 100 + '%',
                         top: Math.random() * 100 + '%',
                         background: `radial-gradient(circle, rgba(250,204,${Math.random() * 50 + 150},0.8) 0%, rgba(249,115,22,0) 70%)`,
                         animationDelay: Math.random() * 5 + 's'
                     }">
                    </div>
            </div>
        </div>

        <div class="container mx-auto px-6 relative z-10">
            <!-- عنوان القسم -->
            <div class="text-center mb-16" data-aos="fade-up">
                <span class="text-yellow-400 font-semibold text-lg flex items-center justify-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    </svg>
                    <span>الذكاء الاصطناعي</span>
                </span>
                <h2 class="text-4xl font-bold text-white mt-4 mb-6">قدرات تحليلية متطورة</h2>
                <p class="text-gray-400 max-w-2xl mx-auto">
                    نستخدم أحدث نماذج الذكاء الاصطناعي لتحليل الصور بدقة متناهية
                </p>
            </div>

            <!-- بطاقات القدرات -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div v-for="(cap, index) in capabilities" :key="index"
                     class="group relative bg-gray-800/30 backdrop-blur-sm p-6 rounded-2xl border border-gray-700 hover:border-yellow-400/50 transition-all duration-500 hover:transform hover:-translate-y-2"
                     :data-aos="'fade-up'"
                     :data-aos-delay="index * 100">

                    <!-- أيقونة -->
                    <div class="relative w-16 h-16 mb-4">
                        <div class="absolute inset-0 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-2xl opacity-20 group-hover:opacity-30 transition-all"></div>
                        <div class="absolute inset-1 bg-gray-900 rounded-xl flex items-center justify-center">
                            <!-- أيقونة حسب القدرة -->
                            <svg v-if="index === 0" xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                            </svg>
                            <svg v-else-if="index === 1" xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
                            </svg>
                            <svg v-else-if="index === 2" xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4" />
                            </svg>
                            <svg v-else-if="index === 3" xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
                            </svg>
                        </div>
                        <!-- دائرة النبض -->
                        <div class="absolute -top-1 -right-1">
                            <span class="relative flex h-3 w-3">
                                <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-yellow-400 opacity-75"></span>
                                <span class="relative inline-flex rounded-full h-3 w-3 bg-yellow-500"></span>
                            </span>
                        </div>
                    </div>

                    <h3 class="text-lg font-bold text-white mb-2">{{ cap.title }}</h3>
                    <p class="text-sm text-gray-400 mb-4">{{ cap.description }}</p>

                    <!-- شريط الدقة -->
                    <div class="space-y-2">
                        <div class="flex justify-between text-xs">
                            <span class="text-gray-400">الدقة</span>
                            <span class="text-yellow-400">{{ cap.accuracy }}%</span>
                        </div>
                        <div class="w-full h-1.5 bg-gray-700 rounded-full overflow-hidden">
                            <div class="h-full bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full transition-all duration-1000"
                                 :style="{ width: cap.accuracy + '%' }"></div>
                        </div>
                    </div>

                    <!-- إحصائيات صغيرة -->
                    <div class="mt-4 grid grid-cols-2 gap-2 text-center">
                        <div class="bg-gray-800/50 rounded-lg p-2">
                            <div class="text-white font-bold flex items-center justify-center gap-1">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                </svg>
                                <span>{{ cap.processed }}</span>
                            </div>
                            <div class="text-xs text-gray-400">صورة/ثانية</div>
                        </div>
                        <div class="bg-gray-800/50 rounded-lg p-2">
                            <div class="text-white font-bold flex items-center justify-center gap-1">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                                <span>{{ cap.detection }}</span>
                            </div>
                            <div class="text-xs text-gray-400">ms</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- نموذج 3D للتحليل -->
            <div class="mt-16 bg-gray-800/20 backdrop-blur-sm rounded-3xl p-8 border border-gray-700" data-aos="zoom-in">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                    <div>
                        <h3 class="text-2xl font-bold text-white mb-4 flex items-center gap-2">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                            </svg>
                            <span>كيف يحلل الذكاء الاصطناعي الصور؟</span>
                        </h3>
                        <p class="text-gray-300 mb-6 leading-relaxed">
                            يستخدم نظامنا شبكات عصبية عميقة مدربة على ملايين الصور لقضبان السكة الحديد،
                            مما يمكنه من اكتشاف أصغر التشققات والعيوب بدقة تفوق العين البشرية.
                        </p>
                        <ul class="space-y-3">
                            <li v-for="(item, i) in aiFeatures" :key="i"
                                class="flex items-center gap-2 text-gray-300">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                                </svg>
                                <span>{{ item }}</span>
                            </li>
                        </ul>
                    </div>
                    <div class="relative">
                        <img src="https://images.unsplash.com/photo-1581092335871-4c7cb3c3bd6f?w=800"
                             alt="AI Analysis"
                             class="rounded-2xl border-4 border-yellow-400/30">
                        <!-- تراكب تحليل -->
                        <div class="absolute inset-0 flex items-center justify-center">
                            <div class="relative w-32 h-32">
                                <div class="absolute inset-0 border-4 border-yellow-400 rounded-full animate-ping"></div>
                                <div class="absolute inset-2 border-4 border-orange-400 rounded-full animate-pulse"></div>
                                <div class="absolute inset-4 bg-yellow-400/20 rounded-full backdrop-blur-sm flex items-center justify-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
export default {
    data() {
        return {
            capabilities: [
                {
                    title: 'كشف التشققات',
                    description: 'اكتشاف التشققات الدقيقة التي لا ترى بالعين المجردة',
                    accuracy: 99.2,
                    processed: '1.2K',
                    detection: '0.3'
                },
                {
                    title: 'قياس التآكل',
                    description: 'حساب نسبة التآكل في القضبان بدقة متناهية',
                    accuracy: 98.7,
                    processed: '950',
                    detection: '0.5'
                },
                {
                    title: 'تحليل الانحراف',
                    description: 'قياس انحراف القضبان عن المسار الصحيح',
                    accuracy: 99.5,
                    processed: '1.5K',
                    detection: '0.2'
                },
                {
                    title: 'اكتشاف الصدأ',
                    description: 'تحديد المناطق المتأثرة بالصدأ والتآكل',
                    accuracy: 97.8,
                    processed: '800',
                    detection: '0.4'
                }
            ],
            aiFeatures: [
                'تحليل فوري بأقل من 0.5 ثانية',
                'دقة تصل إلى 99.5% في الكشف',
                'التعلم المستمر من البيانات الجديدة',
                'دعم لأنماط متعددة من العيوب',
                'تقارير مفصلة مع صور توضيحية'
            ]
        }
    }
}
</script>
