<template>
    <section id="how-it-works" class="py-24 bg-black relative">
        <!-- خلفية تروس متحركة -->
        <div class="absolute inset-0 opacity-10">
            <div class="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                <div class="relative w-[800px] h-[800px]">
                    <div class="absolute inset-0 border-4 border-yellow-400/20 rounded-full animate-spin-slow"></div>
                    <div class="absolute inset-32 border-4 border-yellow-400/10 rounded-full animate-spin-slow-reverse"></div>
                    <div class="absolute inset-64 border-4 border-yellow-400/5 rounded-full animate-spin-slow"></div>
                </div>
            </div>
        </div>

        <div class="container mx-auto px-6 relative z-10">
            <div class="text-center mb-16" data-aos="fade-up">
                <span class="text-yellow-400 font-semibold text-lg flex items-center justify-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                    </svg>
                    <span>آلية العمل</span>
                </span>
                <h2 class="text-4xl font-bold text-white mt-4">كيف يعمل النظام؟</h2>
            </div>

            <!-- الخطوات -->
            <div class="relative">
                <!-- خط الربط -->
                <div class="absolute top-1/2 left-0 w-full h-1 bg-gradient-to-r from-transparent via-yellow-400 to-transparent transform -translate-y-1/2 hidden lg:block"></div>

                <div class="grid grid-cols-1 lg:grid-cols-4 gap-8">
                    <div v-for="(step, index) in steps" :key="index"
                         class="relative text-center"
                         :data-aos="'fade-up'"
                         :data-aos-delay="index * 200">

                        <!-- دائرة الخطوة -->
                        <div class="relative inline-block mb-6">
                            <div class="w-24 h-24 bg-gray-800 rounded-2xl rotate-45 transform transition-all group-hover:rotate-0 border-2 border-yellow-400/30 flex items-center justify-center">
                                <div class="-rotate-45">
                                    <!-- أيقونة حسب الخطوة -->
                                    <svg v-if="index === 0" xmlns="http://www.w3.org/2000/svg" class="h-10 w-10 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                                    </svg>
                                    <svg v-else-if="index === 1" xmlns="http://www.w3.org/2000/svg" class="h-10 w-10 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                                    </svg>
                                    <svg v-else-if="index === 2" xmlns="http://www.w3.org/2000/svg" class="h-10 w-10 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                                    </svg>
                                    <svg v-else-if="index === 3" xmlns="http://www.w3.org/2000/svg" class="h-10 w-10 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                                    </svg>
                                </div>
                            </div>
                            <div class="absolute -top-2 -right-2 w-8 h-8 bg-yellow-400 rounded-full flex items-center justify-center text-black font-bold">
                                {{ index + 1 }}
                            </div>

                            <!-- شرر -->
                            <div class="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-12 h-12">
                                <div class="w-2 h-2 bg-yellow-400 rounded-full animate-ping"
                                     :style="{ animationDelay: index * 0.2 + 's' }"></div>
                            </div>
                        </div>

                        <h3 class="text-xl font-bold text-white mb-3">{{ step.title }}</h3>
                        <p class="text-gray-400">{{ step.description }}</p>
                    </div>
                </div>
            </div>

            <!-- فيديو توضيحي -->
            <div class="mt-16 relative rounded-2xl overflow-hidden group" data-aos="zoom-in">
                <img src="https://images.unsplash.com/photo-1581092160562-40aa08e6b6e2?w=1200"
                     alt="نظام الفحص"
                     class="w-full h-96 object-cover group-hover:scale-110 transition-transform duration-700">
                <div class="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"></div>
                <div class="absolute bottom-8 left-8 right-8 text-center">
                    <button class="px-8 py-4 bg-gradient-to-r from-yellow-400 to-orange-500 text-black rounded-lg font-bold hover:from-yellow-500 hover:to-orange-600 transition-all transform hover:scale-105 inline-flex items-center gap-2">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <span>شاهد كيف يعمل النظام</span>
                    </button>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
export default {
    data() {
        return {
            steps: [
                {
                    title: 'التصوير',
                    description: 'كاميرات عالية الدقة مثبتة على القطارات تلتقط صوراً مستمرة للقضبان'
                },
                {
                    title: 'تحليل AI',
                    description: 'الذكاء الاصطناعي يحلل الصور ويكشف أي عيوب أو تشوهات'
                },
                {
                    title: 'التنبيه',
                    description: 'تنبيه فوري للفرق المختصة عند اكتشاف أي خلل'
                },
                {
                    title: 'الصيانة',
                    description: 'توجيه فرق الصيانة للموقع بدقة مع تقرير مفصل عن المشكلة'
                }
            ]
        }
    }
}
</script>

<style scoped>
@keyframes spin-slow {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}
@keyframes spin-slow-reverse {
    from { transform: rotate(360deg); }
    to { transform: rotate(0deg); }
}
.animate-spin-slow {
    animation: spin-slow 20s linear infinite;
}
.animate-spin-slow-reverse {
    animation: spin-slow-reverse 25s linear infinite;
}
</style>
