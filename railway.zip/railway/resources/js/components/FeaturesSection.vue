<template>
  <section id="features" class="py-24 bg-[#0a0f1a] relative overflow-hidden">
    <div class="absolute inset-0 z-0">
      <div class="absolute top-1/4 -right-20 w-96 h-96 bg-blue-600/10 blur-[120px] rounded-full"></div>
      <div class="absolute bottom-1/4 -left-20 w-96 h-96 bg-yellow-500/10 blur-[120px] rounded-full"></div>

      <div class="absolute inset-0 opacity-[0.03]"
           style="background-image: radial-gradient(#fff 1px, transparent 1px); background-size: 40px 40px;">
      </div>
    </div>

    <div class="container mx-auto px-6 relative z-10">
      <div class="text-center mb-20" data-aos="fade-down">
        <div class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-yellow-500/10 border border-yellow-500/20 mb-4">
          <span class="w-2 h-2 bg-yellow-500 rounded-full animate-pulse"></span>
          <span class="text-yellow-500 font-bold text-xs uppercase tracking-widest">Capabilities</span>
        </div>
        <h2 class="text-4xl md:text-5xl font-black text-white mt-4 mb-6 leading-tight">
          محرك ذكاء اصطناعي <br/>
          <span class="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500">فائق الدقة</span>
        </h2>
        <p class="text-slate-400 max-w-2xl mx-auto leading-relaxed">
          نظامنا لا يكتفي بالرصد فقط، بل يحلل البيانات بعمق لضمان استمرارية حركة النقل السككي بأمان تام وتكلفة صيانة أقل.
        </p>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <div v-for="(feature, index) in features" :key="index"
             class="feature-card group"
             data-aos="fade-up"
             :data-aos-delay="index * 100">

          <div class="relative h-full bg-slate-800/40 backdrop-blur-xl p-8 rounded-[2rem] border border-slate-700/50 hover:border-yellow-500/50 transition-all duration-500 overflow-hidden">

            <div class="absolute -top-24 -right-24 w-48 h-48 bg-yellow-500/5 rounded-full group-hover:bg-yellow-500/10 transition-all duration-500 blur-3xl"></div>

            <div class="relative w-16 h-16 mb-8 transform group-hover:scale-110 transition-transform duration-500">
              <div class="absolute inset-0 bg-yellow-500/20 rounded-2xl rotate-6 group-hover:rotate-12 transition-transform"></div>
              <div class="absolute inset-0 bg-slate-900 rounded-2xl border border-slate-700 flex items-center justify-center shadow-xl">
                <component :is="feature.iconComponent" class="h-8 w-8 text-yellow-500" />
              </div>
            </div>

            <h3 class="text-xl font-black text-white mb-4 group-hover:text-yellow-400 transition-colors">
              {{ feature.title }}
            </h3>
            <p class="text-slate-400 text-sm leading-relaxed mb-8 group-hover:text-slate-300 transition-colors">
              {{ feature.description }}
            </p>

            <div class="space-y-2">
              <div class="flex justify-between items-center text-[10px] font-bold uppercase tracking-widest text-slate-500">
                <span>معدل الدقة</span>
                <span class="text-yellow-500">{{ feature.progress }}%</span>
              </div>
              <div class="w-full h-1.5 bg-slate-900 rounded-full overflow-hidden p-[2px]">
                <div class="h-full bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-full transition-all duration-1000 ease-out shadow-[0_0_10px_#eab30866]"
                     :style="{ width: feature.progress + '%' }"></div>
              </div>
            </div>

            <div class="absolute bottom-4 left-8 text-5xl font-black text-white/[0.03] select-none">
              0{{ index + 1 }}
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
// يمكنك استخدام Lucide Icons أو HeroIcons - هنا سأضع الـ SVG مباشرة في المصفوفة للسهولة
export default {
  data() {
    return {
      features: [
        {
          title: 'التعلم العميق',
          description: 'خوارزميات متطورة تتعرف على أنماط الكسور المجهرية بدقة تتفوق على العين البشرية.',
          progress: 99.4,
          iconComponent: {
            template: `<svg fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>`
          }
        },
        {
          title: 'المعالجة الحية',
          description: 'تحليل دفق الفيديو المباشر من القطارات المتحركة بسرعة تصل إلى 200 كم/ساعة دون تأخير.',
          progress: 98.2,
          iconComponent: {
            template: `<svg fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>`
          }
        },
        {
          title: 'التنبؤ بالأعطال',
          description: 'نظام إحصائي يتوقع احتمالية حدوث عطل في المستقبل بناءً على معدلات التآكل الحالية.',
          progress: 92.5,
          iconComponent: {
            template: `<svg fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>`
          }
        },
        {
          title: 'الذكاء المكاني',
          description: 'ربط العطل فوراً بإحداثيات GPS دقيقة لتمويل فرق الصيانة إلى النقطة المستهدفة مباشرة.',
          progress: 97.8,
          iconComponent: {
            template: `<svg fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>`
          }
        },
        {
          title: 'الأرشفة السحابية',
          description: 'تخزين سجل كامل لكل مليمتر من السكة الحديد للرجوع إليه في التحقيقات والتقارير الدورية.',
          progress: 100,
          iconComponent: {
            template: `<svg fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>`
          }
        },
        {
          title: 'الأمن السيبراني',
          description: 'حماية كاملة للبيانات والتقارير لضمان عدم التلاعب بالمعلومات الحساسة لسلامة الركاب.',
          progress: 99.9,
          iconComponent: {
            template: `<svg fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.040L3 14.535a12.003 12.003 0 008.062 10.702a12.003 12.003 0 008.063-10.703l-.445-8.551z" /></svg>`
          }
        }
      ]
    }
  }
}
</script>

<style scoped>
.feature-card {
  perspective: 1000px;
}

/* تأثير التوهج عند الحوم */
.feature-card:hover .h-full {
  box-shadow: 0 20px 40px -15px rgba(234, 179, 8, 0.15);
  transform: translateY(-10px);
}

/* تنعيم حركات الـ Progress Bar */
[style*="width"] {
  transition: width 1.5s cubic-bezier(0.17, 0.55, 0.55, 1);
}
</style>
