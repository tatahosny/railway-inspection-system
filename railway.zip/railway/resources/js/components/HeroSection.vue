<template>
  <header class="relative h-[650px] flex items-center overflow-hidden bg-slate-900">

    <div class="absolute inset-0 z-0">
      <img
        src="https://images.unsplash.com/photo-1532105956626-9569c03602f6?q=80&w=2000&auto=format&fit=crop"
        alt="Real Railway Track"
        class="w-full h-full object-cover opacity-50 transform scale-105 hover:scale-100 transition-transform duration-[10000ms]"
      />
      <div class="absolute inset-0 bg-gradient-to-r from-slate-900 via-slate-900/80 to-transparent"></div>

      <div class="absolute inset-0 opacity-20 pointer-events-none">
        <div class="h-[2px] w-full bg-yellow-400 shadow-[0_0_15px_#eab308] absolute top-0 animate-scan"></div>
      </div>
    </div>

    <div class="relative container mx-auto px-6 z-10">
      <div class="grid lg:grid-cols-2 gap-12 items-center">

        <div class="text-right">
          <div class="inline-flex items-center gap-3 bg-yellow-500/10 border border-yellow-500/20 px-4 py-2 rounded-full mb-6">
            <span class="relative flex h-3 w-3">
              <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-yellow-400 opacity-75"></span>
              <span class="relative inline-flex rounded-full h-3 w-3 bg-yellow-500"></span>
            </span>
            <span class="text-yellow-500 text-xs font-black tracking-widest uppercase">نظام التحليل الجيوفيزيائي - متصل الآن</span>
          </div>

          <h2 class="text-6xl md:text-7xl font-black text-white mb-6 leading-[1.1]">
            رؤية ذكية لسلامة <br/>
            <span class="text-yellow-500 underline decoration-blue-500 underline-offset-8">لا تتوقف</span>
          </h2>

          <p class="text-slate-300 text-xl mb-10 leading-relaxed max-w-xl">
            بإستخدام خوارزميات التعلم العميق (Deep Learning)، نقوم بمسح الميليمترات في القضبان الحديدية لضمان استباقية الصيانة وتقليل نسبة الحوادث إلى صفر.
          </p>

          <div class="flex flex-wrap gap-5">
            <button @click="visitCount++" class="bg-yellow-500 hover:bg-yellow-400 text-slate-900 px-10 py-5 rounded-2xl font-black text-lg shadow-[0_10px_20px_rgba(234,179,8,0.3)] transition-all transform hover:-translate-y-1 flex items-center gap-3">
              <span>بدء المسح الميداني</span>
              <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </button>

            <div class="flex items-center gap-4 bg-white/5 backdrop-blur-md border border-white/10 p-2 pl-6 rounded-2xl">
              <div class="bg-blue-600 p-3 rounded-xl shadow-lg">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.040L3 14.535a12.003 12.003 0 008.062 10.702a12.003 12.003 0 008.063-10.703l-.445-8.551z" />
                </svg>
              </div>
              <div>
                <p class="text-slate-400 text-xs font-bold uppercase">قوة المعالجة</p>
                <p class="text-white font-black text-lg">1.2 PetaFLOPS</p>
              </div>
            </div>
          </div>
        </div>

        <div class="hidden lg:block relative">
          <div class="relative w-full h-[400px] border border-white/10 rounded-3xl overflow-hidden shadow-2xl backdrop-blur-sm bg-slate-800/30">
             <img
               src="https://images.unsplash.com/photo-1525207934214-58e69a8f8a3e?q=80&w=800&auto=format&fit=crop"
               class="w-full h-full object-cover mix-blend-overlay opacity-80"
             />
             <div class="absolute inset-0 p-6 font-mono text-[10px] text-blue-400 space-y-1">
               <p>ANALYZING_TRACK_ID: #QR-9921</p>
               <p>SENSITIVITY: 0.002mm</p>
               <p class="text-yellow-500 font-bold tracking-widest animate-pulse">DEEP_SCAN_IN_PROGRESS...</p>
               <div class="w-full bg-slate-700 h-1 mt-2">
                 <div class="bg-blue-500 h-full w-2/3 animate-[progress_2s_infinite]"></div>
               </div>
             </div>

             <div class="absolute bottom-6 right-6 bg-slate-900/90 p-4 rounded-xl border border-yellow-500/50">
                <div class="text-yellow-500 text-[10px] mb-1">السرعة الحالية للمركبة</div>
                <div class="text-2xl font-black text-white italic">85 <span class="text-xs">كم/س</span></div>
             </div>
          </div>
        </div>

      </div>
    </div>
  </header>
</template>

<style scoped>
/* انيميشن خط المسح الضوئي */
@keyframes scan {
  0% { top: 0%; opacity: 0; }
  50% { opacity: 1; }
  100% { top: 100%; opacity: 0; }
}
.animate-scan {
  animation: scan 4s linear infinite;
}

@keyframes progress {
  0% { width: 0%; }
  100% { width: 100%; }
}
</style>
