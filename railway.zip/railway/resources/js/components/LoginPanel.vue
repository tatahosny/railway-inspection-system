<template>
    <transition name="fade">
        <div v-if="isOpen" class="fixed inset-0 z-[100] flex items-center justify-center p-6" dir="rtl">
            <div class="absolute inset-0 bg-[#05080f]/90 backdrop-blur-xl" @click="$emit('close')"></div>

            <div class="relative w-full max-w-md bg-[#0a101f] border border-white/10 rounded-[2.5rem] p-10 shadow-2xl overflow-hidden animate-slide-up">

                <div class="absolute -top-24 -left-24 w-48 h-48 bg-yellow-500/10 blur-[80px] rounded-full"></div>

                <div class="text-center mb-10 relative z-10 font-sans">
                    <div class="inline-flex p-4 bg-yellow-500/10 rounded-2xl border border-yellow-500/20 mb-4">
                        <svg class="w-8 h-8 text-yellow-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 00-2 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
                        </svg>
                    </div>
                    <h2 class="text-3xl font-black text-white mb-2">بوابة الوصول</h2>
                    <p class="text-slate-500 text-sm italic font-mono uppercase tracking-widest">Authorized Personnel Only</p>
                </div>

                <form @submit.prevent="handleLogin" class="space-y-6 relative z-10 font-sans text-right">

                    <transition name="fade">
                        <div v-if="errorMessage" class="bg-red-500/10 border border-red-500/20 text-red-500 text-xs py-3 px-4 rounded-xl text-center">
                            {{ errorMessage }}
                        </div>
                    </transition>

                    <div>
                        <label class="block text-slate-400 text-xs font-bold mb-2 mr-2">كود المهندس (البريد الإلكتروني)</label>
                        <input
                            v-model="form.email"
                            type="email"
                            required
                            placeholder="engineer@railguard.com"
                            class="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-yellow-500 transition-all shadow-inner"
                        >
                    </div>

                    <div>
                        <label class="block text-slate-400 text-xs font-bold mb-2 mr-2">كلمة المرور</label>
                        <input
                            v-model="form.password"
                            type="password"
                            required
                            placeholder="••••••••"
                            class="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-yellow-500 transition-all shadow-inner"
                        >
                    </div>

                    <button
                        type="submit"
                        :disabled="loading"
                        class="w-full bg-yellow-500 text-[#0a101f] py-4 rounded-2xl font-black text-lg hover:bg-yellow-400 transform active:scale-95 transition-all shadow-xl shadow-yellow-500/10 disabled:opacity-50"
                    >
                        <div class="flex items-center justify-center gap-2">
                            <svg v-if="loading" class="animate-spin h-5 w-5 text-[#0a101f]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            <span>{{ loading ? 'جاري التحقق...' : 'تحقق من الهوية' }}</span>
                        </div>
                    </button>
                </form>

                <p class="text-center text-[10px] text-slate-600 mt-8 uppercase tracking-widest relative z-10">
                    RailGuard Security Protocol v2.0
                </p>
            </div>
        </div>
    </transition>
</template>

<script setup>
import { reactive, ref } from 'vue';
import axios from 'axios';

// الاستقبال من الـ Navbar
const props = defineProps({
    isOpen: Boolean
});

// إرسال الأوامر للـ Navbar
const emit = defineEmits(['close']);

// حالة الفورم
const loading = ref(false);
const errorMessage = ref(null);
const form = reactive({
    email: '',
    password: '',
    remember: true
});

// دالة تسجيل الدخول باستخدام Axios
const handleLogin = async () => {
    loading.value = true;
    errorMessage.value = null;

    try {
        // إرسال البيانات لمسار /login في Laravel
        const response = await axios.post('/login', form);

        // إذا نجح الدخول، نقوم بتوجيه المستخدم لصفحة الداش بورد
        // استخدمنا window.location لضمان تحديث حالة الجلسة (Session) بالكامل
        window.location.href = '/dashboard';

    } catch (error) {
        loading.value = false;

        // التعامل مع أخطاء التحقق (Validation Errors)
        if (error.response && error.response.status === 422) {
            errorMessage.value = "البريد الإلكتروني أو كلمة المرور غير صحيحة.";
        } else if (error.response && error.response.status === 419) {
            errorMessage.value = "انتهت صلاحية الصفحة، يرجى تحديث المتصفح.";
        } else {
            errorMessage.value = "حدث خطأ غير متوقع، حاول مرة أخرى لاحقاً.";
            console.error("Login Error:", error);
        }
    }
};
</script>

<style scoped>
/* انيميشن الظهور */
.animate-slide-up {
    animation: slideUp 0.4s cubic-bezier(0.16, 1, 0.3, 1);
}

@keyframes slideUp {
    from { opacity: 0; transform: translateY(30px); }
    to { opacity: 1; transform: translateY(0); }
}

/* انيميشن التلاشي */
.fade-enter-active, .fade-leave-active {
    transition: opacity 0.3s ease;
}
.fade-enter-from, .fade-leave-to {
    opacity: 0;
}

/* انيميشن تحميل الزر */
.animate-spin {
    animation: spin 1s linear infinite;
}
@keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}
</style>
