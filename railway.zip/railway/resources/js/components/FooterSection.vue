<template>
    <footer class="bg-[#05080f] relative overflow-hidden border-t border-white/5 font-sans" dir="rtl">
        <div class="absolute inset-0 z-0 overflow-hidden pointer-events-none">
            <div class="absolute -bottom-24 -left-24 w-96 h-96 bg-yellow-500/5 blur-[120px] rounded-full"></div>
            <div class="absolute top-0 right-0 w-64 h-64 bg-blue-500/5 blur-[100px] rounded-full"></div>
        </div>

        <div class="container mx-auto px-6 pt-20 pb-10 relative z-10">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">

                <div data-aos="fade-up">
                    <div class="flex items-center gap-3 mb-6 group">
                        <div class="p-2 bg-yellow-500/10 rounded-xl group-hover:bg-yellow-500/20 transition-all duration-500">
                            <svg class="w-8 h-8 text-yellow-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M12 6V4M6 12H4M18 12H20M12 18V20M12 6C10.8954 6 10 6.89543 10 8C10 9.10457 10.8954 10 12 10C13.1046 10 14 9.10457 14 8C14 6.89543 13.1046 6 12 6Z" stroke-linecap="round"/>
                                <path d="M8 14C9.10457 14 10 13.1046 10 12C10 10.8954 9.10457 10 8 10C6.89543 10 6 10.8954 6 12C6 13.1046 6.89543 14 8 14Z" />
                                <path d="M16 14C17.1046 14 18 13.1046 18 12C18 10.8954 17.1046 10 16 10C14.8954 10 14 10.8954 14 12C14 13.1046 14.8954 14 16 14Z" />
                                <path d="M12 18C13.1046 18 14 17.1046 14 16C14 14.8954 13.1046 14 12 14C10.8954 14 10 14.8954 10 16C10 17.1046 10.8954 18 12 18Z" />
                            </svg>
                        </div>
                        <h3 class="text-2xl font-black text-white tracking-tight">Rail<span class="text-yellow-500">Guard</span></h3>
                    </div>
                    <p class="text-slate-400 leading-relaxed mb-8 text-sm">
                        حلول ذكية تعتمد على رؤية الكمبيوتر (Computer Vision) لتأمين مستقبل السكك الحديدية وضمان سلامة الركاب بأعلى معايير الدقة العالمية.
                    </p>
                    <div class="flex gap-3">
                        <a v-for="social in socialLinks" :key="social.name" :href="social.href"
                           class="w-10 h-10 bg-white/5 border border-white/10 rounded-full flex items-center justify-center text-slate-400 hover:text-white hover:border-yellow-500 hover:bg-yellow-500 transition-all duration-500">
                            <i :class="['fab', 'fa-' + social.name]"></i>
                        </a>
                    </div>
                </div>

                <div data-aos="fade-up" data-aos-delay="100">
                    <h4 class="text-white font-bold mb-6 flex items-center gap-2">
                        <span class="w-5 h-[2px] bg-yellow-500"></span>
                        استكشف
                    </h4>
                    <ul class="space-y-4">
                        <li v-for="link in quickLinks" :key="link.name">
                            <a :href="link.href" class="text-slate-400 hover:text-yellow-500 transition-colors text-sm flex items-center gap-2 group">
                                <span class="w-1.5 h-1.5 bg-slate-700 rounded-full group-hover:bg-yellow-500 transition-all"></span>
                                {{ link.name }}
                            </a>
                        </li>
                    </ul>
                </div>

                <div data-aos="fade-up" data-aos-delay="200">
                    <h4 class="text-white font-bold mb-6 flex items-center gap-2">
                        <span class="w-5 h-[2px] bg-yellow-500"></span>
                        الخدمات التقنية
                    </h4>
                    <ul class="space-y-4">
                        <li v-for="service in services" :key="service" class="flex items-center gap-3 text-slate-400 text-sm">
                            <svg class="w-4 h-4 text-yellow-500/50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                            </svg>
                            {{ service }}
                        </li>
                    </ul>
                </div>

                <div data-aos="fade-up" data-aos-delay="300">
                    <h4 class="text-white font-bold mb-6 flex items-center gap-2">
                        <span class="w-5 h-[2px] bg-yellow-500"></span>
                        النشرة التقنية
                    </h4>
                    <p class="text-slate-400 text-sm mb-6">احصل على إشعارات فورية حول تحديثات الأنظمة والتقارير.</p>
                    <div class="relative group">
                        <input type="email" placeholder="البريد الإلكتروني"
                               class="w-full px-5 py-4 bg-white/5 border border-white/10 rounded-2xl text-white text-sm focus:outline-none focus:border-yellow-500 transition-all placeholder:text-slate-600">
                        <button class="absolute left-2 top-2 bottom-2 px-4 bg-yellow-500 text-[#05080f] rounded-xl text-xs font-bold hover:bg-yellow-400 transition-all active:scale-95">
                            اشترك الآن
                        </button>
                    </div>
                </div>
            </div>

            <div class="pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
                <div class="text-slate-500 text-sm flex items-center gap-2 font-mono">
                    <span>© {{ currentYear }} </span>
                    <span class="w-1 h-1 bg-slate-700 rounded-full"></span>
                    <span class="text-white font-bold tracking-widest uppercase">RailGuard Project</span>
                </div>

                <div class="group flex items-center gap-2 bg-white/5 px-4 py-2 rounded-full border border-white/5">
                    <span class="text-slate-400 text-xs uppercase tracking-tighter">Designed & Developed By</span>
                    <span class="text-yellow-500 font-black text-sm hover:text-yellow-400 transition-colors cursor-pointer">
                        Mostafa_Hosny
                    </span>
                </div>

                <div class="flex gap-6 text-xs text-slate-500">
                    <a href="#" class="hover:text-white transition-colors">سياسة الخصوصية</a>
                    <a href="#" class="hover:text-white transition-colors">اتفاقية الاستخدام</a>
                </div>
            </div>
        </div>
    </footer>
</template>

<script>
export default {
    data() {
        return {
            currentYear: new Date().getFullYear(),
            socialLinks: [
                { name: 'twitter', href: '#' },
                { name: 'linkedin-in', href: '#' },
                { name: 'github', href: '#' },
                { name: 'youtube', href: '#' }
            ],
            quickLinks: [
                { name: 'الرئيسية', href: '#' },
                { name: 'عن المشروع', href: '#' },
                { name: 'تكنولوجيا النظام', href: '#' },
                { name: 'مكتبة العيوب', href: '#' },
                { name: 'فريق العمل', href: '#' }
            ],
            services: [
                'كشف التشققات العرضية',
                'تحليل تآكل السطح الهيكلي',
                'تحديد المواقع بالـ GNSS',
                'نظام الإنذار المبكر',
                'تقارير الصيانة التنبؤية'
            ]
        }
    }
}
</script>

<style scoped>
/* إضافة خط يدعم العربية بشكل جميل */
@import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Arabic:wght@300;400;700;900&display=swap');

footer * {
    font-family: 'Noto Sans Arabic', sans-serif;
}

/* تأثير التروس أو الدوائر المتحركة في الخلفية بشكل هادئ */
@keyframes spin-slow {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

.animate-spin-slow {
    animation: spin-slow 40s linear infinite;
}
</style>
