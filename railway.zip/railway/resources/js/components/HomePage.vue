<template>
    <div class="min-h-screen bg-gray-100">
        <!-- الهيدر -->
        <nav class="bg-blue-600 text-white p-4">
            <div class="container mx-auto flex justify-between">
                <h1 class="text-2xl font-bold">نظام فحص السكة الحديد</h1>
                <div>
                    <a href="/login" class="px-4 py-2 bg-blue-700 rounded-lg">دخول</a>
                </div>
            </div>
        </nav>

        <!-- المحتوى الرئيسي -->
        <main class="container mx-auto p-6">
            <div class="bg-white rounded-lg shadow-lg p-8">
                <h2 class="text-3xl font-bold mb-4">مرحباً بك في النظام</h2>
                <p class="text-gray-600 mb-6">هذه الصفحة تعمل بـ Vue.js بالكامل</p>

                <!-- مثال على التفاعلية -->
                <div class="bg-blue-50 p-4 rounded-lg">
                    <p class="mb-2">عدد الزيارات: {{ visitCount }}</p>
                    <button
                        @click="visitCount++"
                        class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
                    >
                        زيادة العدد
                    </button>
                </div>
            </div>
        </main>

        <!-- الفوتر -->
        <footer class="bg-gray-800 text-white p-4 mt-8">
            <div class="container mx-auto text-center">
                © {{ currentYear }} جميع الحقوق محفوظة
            </div>
        </footer>
    </div>
</template>

<script>
export default {
    data() {
        return {
            visitCount: 0,
            currentYear: new Date().getFullYear()
        }
    }
}
</script>
