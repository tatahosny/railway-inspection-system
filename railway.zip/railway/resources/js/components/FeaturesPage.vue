<template>
    <section class="pt-40 pb-20 px-6 min-h-screen bg-gradient-to-b from-gray-900 to-black">
        <div class="container mx-auto max-w-6xl">
            <!-- عنوان الصفحة -->
            <div class="text-center mb-16" data-aos="fade-down">
                <h1 class="text-5xl md:text-6xl font-bold mb-4">
                    مميزات <span class="text-transparent bg-clip-text bg-gradient-to-l from-yellow-400 to-orange-500">النظام</span>
                </h1>
                <p class="text-gray-400 text-xl">تقنيات متطورة للكشف عن عيوب السكة الحديد</p>
                <div class="w-24 h-1 bg-gradient-to-l from-yellow-400 to-orange-500 mx-auto mt-4"></div>
            </div>

            <!-- شبكة المميزات -->
            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                <div v-for="(feature, index) in features" :key="index"
                     class="bg-gray-800/30 p-8 rounded-2xl border border-gray-700 hover:border-yellow-400/50 transition-all hover:transform hover:-translate-y-2"
                     :data-aos="'fade-up'" :data-aos-delay="index * 100">

                    <div class="w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-xl flex items-center justify-center mb-6">
                        <svg v-if="feature.icon === 'ai'" xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                        </svg>
                        <svg v-else-if="feature.icon === 'camera'" xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                        </svg>
                        <svg v-else-if="feature.icon === 'lightning'" xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
                        </svg>
                        <svg v-else-if="feature.icon === 'chart'" xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                        </svg>
                        <svg v-else-if="feature.icon === 'wrench'" xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                        </svg>
                        <svg v-else-if="feature.icon === 'globe'" xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                    </div>

                    <h3 class="text-2xl font-bold mb-3 text-white">{{ feature.title }}</h3>
                    <p class="text-gray-400 leading-relaxed">{{ feature.description }}</p>

                    <!-- شريط التقدم -->
                    <div class="mt-6">
                        <div class="flex justify-between text-sm mb-2">
                            <span class="text-gray-400">الدقة</span>
                            <span class="text-yellow-400">{{ feature.accuracy }}%</span>
                        </div>
                        <div class="w-full h-2 bg-gray-700 rounded-full overflow-hidden">
                            <div class="h-full bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full"
                                 :style="{ width: feature.accuracy + '%' }"></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- مميزات إضافية -->
            <div class="mt-20 grid md:grid-cols-2 gap-8">
                <div class="bg-gradient-to-br from-gray-800/50 to-gray-900/50 p-8 rounded-2xl border border-gray-700" data-aos="fade-left">
                    <div class="flex items-center gap-3 mb-4">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
                        </svg>
                        <h3 class="text-2xl font-bold text-yellow-400">تحليل فوري</h3>
                    </div>
                    <p class="text-gray-300 mb-4">يقوم النظام بتحليل الصور في أقل من 0.3 ثانية مع دقة تصل إلى 99.9%</p>
                    <ul class="space-y-2">
                        <li class="flex items-center gap-2 text-gray-400">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                            </svg>
                            <span>كشف التشققات الدقيقة</span>
                        </li>
                        <li class="flex items-center gap-2 text-gray-400">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                            </svg>
                            <span>قياس نسبة التآكل</span>
                        </li>
                        <li class="flex items-center gap-2 text-gray-400">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                            </svg>
                            <span>اكتشاف الصدأ</span>
                        </li>
                    </ul>
                </div>

                <div class="bg-gradient-to-br from-gray-800/50 to-gray-900/50 p-8 rounded-2xl border border-gray-700" data-aos="fade-right">
                    <div class="flex items-center gap-3 mb-4">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                        </svg>
                        <h3 class="text-2xl font-bold text-yellow-400">تقارير شاملة</h3>
                    </div>
                    <p class="text-gray-300 mb-4">تقارير مفصلة مع صور توضيحية وإحصائيات دقيقة لحالة القضبان</p>
                    <ul class="space-y-2">
                        <li class="flex items-center gap-2 text-gray-400">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                            </svg>
                            <span>تحديد موقع العيب بدقة</span>
                        </li>
                        <li class="flex items-center gap-2 text-gray-400">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                            </svg>
                            <span>توصيات للصيانة</span>
                        </li>
                        <li class="flex items-center gap-2 text-gray-400">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                            </svg>
                            <span>تنبيهات فورية</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
export default {
    data() {
        return {
            features: [
                {
                    icon: 'ai',
                    title: 'ذكاء اصطناعي متقدم',
                    description: 'شبكات عصبية عميقة مدربة على ملايين الصور للكشف عن العيوب بدقة متناهية',
                    accuracy: 99.9
                },
                {
                    icon: 'camera',
                    title: 'تحليل الصور آنياً',
                    description: 'معالجة فورية للصور الملتقطة من الكاميرات المثبتة على القطارات',
                    accuracy: 98.5
                },
                {
                    icon: 'lightning',
                    title: 'كشف فوري',
                    description: 'تنبيه فوري عند اكتشاف أي خلل مع تحديد الموقع بدقة متناهية',
                    accuracy: 99.2
                },
                {
                    icon: 'chart',
                    title: 'تقارير شاملة',
                    description: 'تقارير مفصلة عن حالة القضبان مع رسوم بيانية وإحصائيات دقيقة',
                    accuracy: 97.8
                },
                {
                    icon: 'wrench',
                    title: 'صيانة تنبؤية',
                    description: 'توقع الأعطال قبل حدوثها باستخدام تحليل البيانات التاريخية',
                    accuracy: 95.5
                },
                {
                    icon: 'globe',
                    title: 'مراقبة عن بعد',
                    description: 'لوحة تحكم متكاملة لمتابعة حالة الشبكة من أي مكان في العالم',
                    accuracy: 99.5
                }
            ]
        }
    }
}
</script>
