<template>
    <section class="py-20 bg-[#0a0f1a] relative overflow-hidden">
        <div class="absolute inset-0 opacity-20 pointer-events-none">
            <div class="absolute top-0 left-1/4 w-96 h-96 bg-blue-600/10 rounded-full filter blur-[120px] animate-pulse"></div>
            <div class="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-yellow-500/5 rounded-full filter blur-[120px] animate-pulse animation-delay-2000"></div>
        </div>

        <div class="container mx-auto px-6 relative z-10">
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-12">
                <div v-for="(stat, index) in stats" :key="index"
                     class="text-center group"
                     data-aos="fade-up"
                     :data-aos-delay="index * 150">

                    <div class="relative inline-block mb-6">
                        <div class="w-16 h-16 bg-slate-800/80 rounded-2xl rotate-45 group-hover:rotate-0 transition-all duration-500 flex items-center justify-center border border-slate-700 shadow-xl group-hover:border-yellow-500/50">
                            <div class="-rotate-45 group-hover:rotate-0 transition-all duration-500 text-yellow-500">
                                <svg v-if="index === 0" xmlns="http://www.w3.org/2000/svg" class="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                                </svg>
                                <svg v-else-if="index === 1" xmlns="http://www.w3.org/2000/svg" class="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
                                </svg>
                                <svg v-else-if="index === 2" xmlns="http://www.w3.org/2000/svg" class="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 10h18M3 14h18m-9-4v4m-7 0a3 3 0 110-6h14a3 3 0 110 6H5z" />
                                </svg>
                                <svg v-else-if="index === 3" xmlns="http://www.w3.org/2000/svg" class="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                            </div>
                        </div>
                        <div class="absolute -inset-2 border border-dashed border-yellow-500/20 rounded-full animate-spin-slow"></div>
                    </div>

                    <div class="text-4xl font-black text-white mb-2 tracking-tighter">
                        <span>{{ stat.value }}</span>
                        <span v-if="stat.unit" class="text-lg text-yellow-500 ml-1 font-bold">{{ stat.unit }}</span>
                    </div>
                    <div class="text-slate-400 font-medium text-sm uppercase tracking-widest">{{ stat.label }}</div>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
export default {
    data() {
        return {
            stats: [
                { value: '98.4', unit: '%', label: 'دقة رصد العيوب' }, // رقم واقعي لأن 100% مستحيلة برمجياً
                { value: '420', unit: 'ms', label: 'سرعة الاستجابة' }, // سرعة معالجة الفريم الواحد
                { value: '2,850', unit: 'Km', label: 'إجمالي المسح' }, // مسافة واقعية لشبكة سكك حديد
                { value: '1.2', unit: 'M', label: 'صورة تم تحليلها' } // عدد ضخم من الصور التي حللها الذكاء الاصطناعي
            ]
        }
    }
}
</script>

<style scoped>
@keyframes spin-slow {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}
.animate-spin-slow {
    animation: spin-slow 12s linear infinite;
}
.animation-delay-2000 {
    animation-delay: 2s;
}
</style>
