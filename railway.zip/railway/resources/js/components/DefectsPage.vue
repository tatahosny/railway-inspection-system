<template>
    <section class="pt-40 pb-20 px-6 min-h-screen bg-[#0a0f1a] relative overflow-hidden text-right" dir="rtl">
        <div class="absolute inset-0 z-0 opacity-20">
            <div class="absolute top-20 left-10 w-72 h-72 bg-blue-500 blur-[120px]"></div>
            <div class="absolute bottom-20 right-10 w-72 h-72 bg-orange-500 blur-[120px]"></div>
        </div>

        <div class="container mx-auto max-w-6xl relative z-10">
            <div class="text-center mb-20" data-aos="fade-down">
                <span class="text-yellow-500 font-mono tracking-widest uppercase text-sm mb-4 block">Defect Classification Library</span>
                <h1 class="text-5xl md:text-6xl font-black text-white mb-6">
                    فئات <span class="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500">العيوب الهيكلية</span>
                </h1>
                <p class="text-slate-400 text-lg max-w-3xl mx-auto leading-relaxed">
                    يستخدم النظام خوارزميات Deep Learning تم تدريبها على قاعدة بيانات ضخمة لتصنيف العيوب وفقاً لخطورتها وتأثيرها على ديناميكا حركة القطارات.
                </p>
                <div class="w-24 h-1.5 bg-gradient-to-r from-yellow-400 to-orange-500 mx-auto mt-6 rounded-full"></div>
            </div>

            <div class="grid grid-cols-2 md:grid-cols-4 gap-6 mb-20">
                <div v-for="(stat, sIndex) in stats" :key="sIndex"
                     class="bg-white/5 backdrop-blur-md p-6 rounded-2xl border border-white/10 hover:border-yellow-500/40 transition-all group">
                    <div class="text-3xl font-black text-yellow-500 mb-1 group-hover:scale-110 transition-transform">{{ stat.value }}</div>
                    <div class="text-slate-500 text-xs font-bold uppercase tracking-wider">{{ stat.label }}</div>
                </div>
            </div>

            <div class="grid md:grid-cols-2 gap-10">
                <div v-for="(defect, index) in defects" :key="index"
                     class="bg-slate-900/50 rounded-[2rem] overflow-hidden border border-slate-800 hover:border-yellow-500/30 transition-all group relative"
                     data-aos="fade-up" :data-aos-delay="index * 100">

                    <div class="relative h-64 overflow-hidden">
                        <img :src="defect.image" :alt="defect.name" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000">
                        <div class="absolute inset-0 bg-gradient-to-t from-[#0a0f1a] via-transparent to-transparent"></div>

                        <div class="absolute top-4 left-4 bg-black/60 backdrop-blur-md px-3 py-1 rounded-md border border-white/20">
                            <span class="text-[10px] font-mono text-yellow-500">CODE: {{ defect.code }}</span>
                        </div>

                        <div class="absolute top-4 right-4">
                            <span class="px-4 py-1.5 rounded-full text-xs font-black tracking-tighter shadow-xl border"
                                  :class="severityClass(defect.severity)">
                                {{ defect.severity }}
                            </span>
                        </div>
                    </div>

                    <div class="p-8">
                        <div class="flex justify-between items-start mb-4">
                            <h3 class="text-2xl font-bold text-white">{{ defect.name }}</h3>
                            <span class="text-slate-500 font-mono text-sm">ID: #00{{ index + 1 }}</span>
                        </div>

                        <p class="text-slate-400 mb-8 text-sm leading-relaxed h-12 overflow-hidden">
                            {{ defect.description }}
                        </p>

                        <div class="space-y-6">
                            <div>
                                <div class="flex justify-between text-xs mb-2">
                                    <span class="text-slate-500">تردد الظهور في العينات (Frequency)</span>
                                    <span class="text-white font-bold">{{ defect.percentage }}%</span>
                                </div>
                                <div class="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                                    <div class="h-full bg-gradient-to-l from-yellow-500 to-orange-500 rounded-full transition-all duration-1000"
                                         :style="{ width: defect.percentage + '%' }"></div>
                                </div>
                            </div>

                            <div class="grid grid-cols-2 gap-4">
                                <div class="bg-white/5 p-4 rounded-xl border border-white/5">
                                    <div class="text-[10px] text-slate-500 mb-1 uppercase">Mean Precision</div>
                                    <div class="text-lg font-black text-yellow-500">{{ defect.accuracy }}%</div>
                                </div>
                                <div class="bg-white/5 p-4 rounded-xl border border-white/5">
                                    <div class="text-[10px] text-slate-500 mb-1 uppercase">Inference Speed</div>
                                    <div class="text-lg font-black text-yellow-500">{{ defect.detectionTime }}ms</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
export default {
    data() {
        return {
            stats: [
                { label: 'Data Samples', value: '45.2K' },
                { label: 'Classes', value: '08' },
                { label: 'Avg mAP', value: '94.2%' },
                { label: 'Latency', value: '24ms' },
            ],
            defects: [
                {
                    name: 'شقوق الرأس (Head Cracks)',
                    code: 'HC-102',
                    description: 'تشققات طولية أو عرضية في رأس القضيب ناتجة عن التعب المعدني (Rolling Contact Fatigue).',
                    severity: 'حرجة للغاية',
                    percentage: 42,
                    accuracy: 96.5,
                    detectionTime: 18,
                    image: 'https://www.cairo24.com/UploadCache/libfiles/34/6/600x338o/84.jpg'
                },
                {
                    name: 'تآكل السطح (Squats)',
                    code: 'SQ-405',
                    description: 'انخفاضات موضعية في سطح الدحرجة تؤدي إلى صدمات قوية لعجلات القطار واهتزازات غير خطية.',
                    severity: 'متوسطة',
                    percentage: 25,
                    accuracy: 92.8,
                    detectionTime: 22,
                    image: 'https://matsda2sh.com/graph/uploads/870x500/content_images/2021_04_6556-1-645x427-1.jpeg'
                },
                {
                    name: 'الصدأ الإجهادي (Corrosion)',
                    code: 'CR-009',
                    description: 'تأكسد كيميائي عميق يؤدي إلى نقص في المساحة المقطعية للقضيب، مما يقلل من قدرة التحمل القصوى.',
                    severity: 'مراقبة',
                    percentage: 18,
                    accuracy: 89.4,
                    detectionTime: 15,
                    image: 'https://blog.ajsrp.com/wp-content/uploads/2025/04/%D8%B5%D8%AF%D8%A3-%D8%A7%D9%84%D8%AD%D8%AF%D9%8A%D8%AF-%D8%AA%D8%BA%D9%8A%D8%B1-%D9%81%D9%8A%D8%B2%D9%8A%D8%A7%D8%A6%D9%8A-%D8%A3%D9%85-%D9%83%D9%8A%D9%85%D9%8A%D8%A7%D8%A6%D9%8A-696x398.jpeg'
                },
                {
                    name: 'خلل الروابط (Fastener Defect)',
                    code: 'FD-771',
                    description: 'فقدان أو كسر في مسامير التثبيت (E-Clips) مما يهدد باستقرار القضيب العرضي واتساع السكة.',
                    severity: 'حرجة',
                    percentage: 15,
                    accuracy: 97.2,
                    detectionTime: 20,
                    image: 'https://pub.mdpi-res.com/jimaging/jimaging-10-00192/article_deploy/html/images/jimaging-10-00192-g005.png?1723619522'
                }
            ]
        }
    },
    methods: {
        severityClass(severity) {
            switch(severity) {
                case 'حرجة للغاية': return 'bg-red-500/20 text-red-500 border-red-500/50';
                case 'حرجة': return 'bg-orange-500/20 text-orange-500 border-orange-500/50';
                case 'متوسطة': return 'bg-yellow-500/20 text-yellow-500 border-yellow-500/50';
                default: return 'bg-blue-500/20 text-blue-500 border-blue-500/50';
            }
        }
    }
}
</script>

<style scoped>
/* خطوط احترافية */
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@300;400;700&display=swap');

section * {
    font-family: 'IBM Plex Sans Arabic', sans-serif;
}

@keyframes scan {
    0% { transform: translateY(0); opacity: 0.5; }
    50% { opacity: 1; }
    100% { transform: translateY(256px); opacity: 0.5; }
}

.animate-scan {
    animation: scan 2s linear infinite;
}
</style>
