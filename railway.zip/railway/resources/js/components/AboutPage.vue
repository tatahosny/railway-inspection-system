<template>
    <section class="pt-40 pb-20 px-6 min-h-screen bg-[#0a0f1a] relative overflow-hidden">
        <div class="absolute inset-0 z-0 opacity-30">
            <div class="absolute top-0 right-0 w-[600px] h-[600px] bg-blue-600/10 blur-[150px]"></div>
            <div class="absolute bottom-0 left-0 w-[600px] h-[600px] bg-yellow-500/5 blur-[150px]"></div>
        </div>

        <div class="container mx-auto max-w-6xl relative z-10">

            <div class="text-center mb-24" data-aos="fade-down">
                <span class="text-yellow-500 font-mono tracking-[0.3em] uppercase text-sm mb-4 block">Academic Collaboration Project</span>
                <h1 class="text-5xl md:text-7xl font-black text-white mb-6">
                    عن <span class="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-orange-500 to-yellow-600">المشروع</span>
                </h1>
                <p class="text-slate-400 max-w-2xl mx-auto text-lg leading-relaxed">
                    نتاج تعاون بحثي وتقني فريد يجمع بين عقول قسم تكنولوجيا المعلومات وتكنولوجيا السكك الحديدية بجامعة برج العرب التكنولوجية.
                </p>
                <div class="w-32 h-1.5 bg-gradient-to-r from-yellow-400 to-transparent mx-auto mt-8 rounded-full"></div>
            </div>

            <div class="grid md:grid-cols-2 gap-16 items-center mb-32 border-b border-white/5 pb-20">
                <div class="relative order-2 md:order-1" data-aos="fade-right">
                    <div class="absolute -inset-4 bg-gradient-to-r from-blue-500/20 to-yellow-500/20 blur-2xl rounded-full"></div>
                    <img src="https://tse4.mm.bing.net/th/id/OIP.SmqymVCaivBJNe8mOACrmwHaD9?rs=1&pid=ImgDetMain&o=7&rm=3" alt="University" class="relative z-10 rounded-3xl border border-white/10 shadow-2xl">
                    <div class="absolute bottom-6 right-6 z-20 bg-yellow-500 p-6 rounded-2xl shadow-xl hidden md:block">
                        <p class="text-black font-black text-xl italic">BATU</p>
                        <p class="text-black/80 text-xs font-bold">Borg El Arab Technological Univ.</p>
                    </div>
                </div>
                <div class="order-1 md:order-2" data-aos="fade-left">
                    <h2 class="text-3xl font-black text-white mb-6 leading-tight">
                        في رحاب <span class="text-yellow-500">جامعة برج العرب التكنولوجية</span>
                    </h2>
                    <p class="text-slate-300 mb-6 leading-relaxed">
                        تعد جامعة برج العرب التكنولوجية منارة للتعليم التطبيقي في مصر، حيث تتبنى نموذجاً تعليمياً يربط بين الدراسة الأكاديمية واحتياجات سوق العمل الفعلية. من هنا انطلقت شرارة مشروع <b>RailGuard</b> كنموذج تطبيقي رائد.
                    </p>
                    <div class="grid grid-cols-2 gap-4">
                        <div class="p-4 rounded-xl bg-white/5 border border-white/10">
                            <h4 class="text-yellow-500 font-bold mb-1">بيئة بحثية</h4>
                            <p class="text-slate-400 text-xs">مختبرات مجهزة بأحدث تقنيات الـ AI.</p>
                        </div>
                        <div class="p-4 rounded-xl bg-white/5 border border-white/10">
                            <h4 class="text-yellow-500 font-bold mb-1">دعم أكاديمي</h4>
                            <p class="text-slate-400 text-xs">إشراف نخبة من أساتذة التكنولوجيا.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="bg-gradient-to-br from-slate-800/20 to-transparent p-12 rounded-[3rem] border border-white/5 mb-32 relative overflow-hidden">
                <div class="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>
                <div class="text-center mb-16 relative z-10">
                    <h2 class="text-4xl font-black text-white mb-4">تكامل التخصصات</h2>
                    <p class="text-slate-400">عندما تجتمع البرمجة مع الهندسة الميكانيكية للسكك الحديدية</p>
                </div>
                <div class="grid md:grid-cols-2 gap-12 relative z-10">
                    <div class="flex gap-6 p-6 bg-[#0a0f1a]/80 rounded-2xl border-l-4 border-blue-500">
                        <div class="text-blue-500 mt-1">
                            <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4"></path></svg>
                        </div>
                        <div>
                            <h3 class="text-xl font-bold text-white mb-2">قسم تكنولوجيا المعلومات</h3>
                            <p class="text-slate-400 text-sm italic">المسؤول عن بناء العقل المدبر للنظام، تطوير خوارزميات YOLO-v8، إدارة قواعد البيانات السحابية، وتصميم واجهات المستخدم التفاعلية.</p>
                        </div>
                    </div>
                    <div class="flex gap-6 p-6 bg-[#0a0f1a]/80 rounded-2xl border-l-4 border-yellow-500">
                        <div class="text-yellow-500 mt-1">
                            <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M13 5l7 7-7 7M5 5l7 7-7 7"></path></svg>
                        </div>
                        <div>
                            <h3 class="text-xl font-bold text-white mb-2">قسم تكنولوجيا السكك الحديدية</h3>
                            <p class="text-slate-400 text-sm italic">المسؤول عن تحديد المعايير الهندسية للعيوب، تقديم الخبرة الفنية في صيانة القضبان، واختبار النظام في بيئة محاكية للواقع السككي.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="mb-32">
                <div class="flex items-center gap-6 mb-12">
                    <h2 class="text-4xl font-black text-white shrink-0">تحت إشراف <span class="text-yellow-500">الخبراء</span></h2>
                    <div class="h-[1px] w-full bg-white/10"></div>
                </div>
                <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <div v-for="i in 3" :key="i" class="p-8 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/[0.08] transition-all group">
                        <div class="w-16 h-16 rounded-full bg-slate-700 mb-6 overflow-hidden grayscale group-hover:grayscale-0 transition-all border-2 border-yellow-500/30">
                            <img src="https://www.w3schools.com/howto/img_avatar.png" alt="Doctor">
                        </div>
                        <h4 class="text-lg font-bold text-white mb-1">د. اسم الدكتور المشرف</h4>
                        <p class="text-yellow-500 text-xs font-mono mb-4 italic leading-relaxed">استاذ مساعد - قسم تكنولوجيا المعلومات</p>
                        <p class="text-slate-400 text-sm">"إن RailGuard ليس مجرد مشروع تخرج، بل هو خطوة نحو توطين تكنولوجيا الذكاء الاصطناعي في قطاع النقل المصري."</p>
                    </div>
                </div>
            </div>

            <div class="grid md:grid-cols-2 gap-20 items-center mb-32 border-t border-white/5 pt-20">
                <div data-aos="fade-right">
                    <h2 class="text-4xl font-black text-white mb-8 leading-tight">
                        منصة <span class="text-yellow-400">RailGuard</span><br/> للتحليل الجيومكاني
                    </h2>
                    <p class="text-slate-400 mb-6 text-lg leading-relaxed">
                        يعتمد النظام على بنية تحتية هجينة تدمج بين <span class="text-white font-bold">Edge Computing</span> وبين <span class="text-white font-bold">Cloud Analytics</span>. نستخدم نماذج Deep Learning مخصصة مدربة على آلاف العينات الحقيقية.
                    </p>
                    <ul class="space-y-4">
                        <li class="flex items-center gap-3 text-slate-300">
                            <div class="w-1.5 h-1.5 bg-yellow-500 rounded-full"></div>
                            رصد التشققات بدقة تصل إلى 2 ملم.
                        </li>
                        <li class="flex items-center gap-3 text-slate-300">
                            <div class="w-1.5 h-1.5 bg-yellow-500 rounded-full"></div>
                            تحديد المواقع بدقة خطأ أقل من 50 سم.
                        </li>
                    </ul>
                </div>

                <div class="relative" data-aos="zoom-in">
                    <div class="absolute -top-6 -right-6 bg-slate-900/90 p-4 border border-slate-700 rounded-2xl z-20 backdrop-blur-md shadow-2xl animate-float font-mono">
                        <div class="text-[10px] text-slate-500 mb-1 uppercase tracking-tighter">Status: Active</div>
                        <div class="text-lg font-bold text-green-500 tracking-tighter">SYSTEM ONLINE</div>
                    </div>
                    <div class="relative z-10 rounded-[2.5rem] overflow-hidden border border-slate-700 shadow-2xl group">
                        <img src="https://images.unsplash.com/photo-1541427468627-a89a96e5ca1d?q=80&w=1000" alt="Rail" class="w-full h-[450px] object-cover grayscale hover:grayscale-0 transition-all duration-700">
                        <div class="absolute top-0 left-0 w-full h-1 bg-yellow-400 shadow-[0_0_20px_#eab308] animate-scan"></div>
                    </div>
                </div>
            </div>

        </div>
    </section>
</template>

<script>
export default {
    name: 'AboutProject'
}
</script>

<style scoped>
@keyframes scan {
    0% { top: 0%; }
    100% { top: 100%; }
}

@keyframes float {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-10px); }
}

.animate-scan {
    animation: scan 4s linear infinite;
}

.animate-float {
    animation: float 4s ease-in-out infinite;
}

/* تحسين الخط العربي */
* {
    font-family: 'Inter', 'Noto Sans Arabic', sans-serif;
}
</style>
