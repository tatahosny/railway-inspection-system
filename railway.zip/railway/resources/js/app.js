import { createApp } from 'vue';
import AOS from 'aos';
import 'aos/dist/aos.css';
import 'animate.css';

// استيراد المكونات الأساسية والصفحات
import Navbar from './components/Navbar.vue';
import HeroSection from './components/HeroSection.vue';
import StatsSection from './components/StatsSection.vue';
import FeaturesSection from './components/FeaturesSection.vue';
import HowItWorks from './components/HowItWorks.vue';
import InspectionsSection from './components/InspectionsSection.vue';
import AICapabilities from './components/AICapabilities.vue';
import FooterSection from './components/FooterSection.vue';

// استيراد مكونات الصفحات المنفصلة
import AboutPage from './components/AboutPage.vue';
import FeaturesPage from './components/FeaturesPage.vue';
import DefectsPage from './components/DefectsPage.vue';
import ContactPage from './components/ContactPage.vue';

const app = createApp({
    data() {
        return {
            siteName: 'RailGuard',
            loading: true,       // تبدأ بـ true ليظهر اللودينج فوراً
            currentPage: 'home'   // الصفحة الافتراضية عند الفتح
        }
    },
    mounted() {
        // 1. إخفاء شاشة التحميل بعد 3 ثوانٍ
        setTimeout(() => {
            this.loading = false;
        }, 3000);

        // 2. تهيئة مكتبة الأنميشن AOS
        this.initAOS();

        console.log('🚀 RailGuard AI System is ready!');
    },
    methods: {
        // دالة تهيئة AOS
        initAOS() {
            AOS.init({
                duration: 800,
                once: true,
                offset: 50,
                easing: 'ease-out'
            });
        },

        // دالة التنقل بين الصفحات
        changePage(pageId) {
            // تغيير الحالة لتغيير المكون المعروض في Blade
            this.currentPage = pageId;

            // العودة لسلاسة إلى أعلى الصفحة
            window.scrollTo({ top: 0, behavior: 'smooth' });

            // إعادة تحديث AOS بعد تبديل الصفحة لضمان عمل الحركات
            this.$nextTick(() => {
                AOS.refresh();
            });
        }
    }
});

// تسجيل المكونات (Global Registration)
app.component('navbar', Navbar);
app.component('hero-section', HeroSection);
app.component('stats-section', StatsSection);
app.component('features-section', FeaturesSection);
app.component('how-it-works', HowItWorks);
app.component('inspections-section', InspectionsSection);
app.component('ai-capabilities', AICapabilities);
app.component('footer-section', FooterSection);

// تسجيل الصفحات الفرعية
app.component('about-page', AboutPage);
app.component('features-page', FeaturesPage);
app.component('defects-page', DefectsPage);
app.component('contact-page', ContactPage);

// ربط التطبيق بالعنصر الذي يحمل id="app" في ملف Blade
app.mount('#app');
