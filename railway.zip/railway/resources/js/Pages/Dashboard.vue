<template>
    <div class="min-h-screen bg-[#05080f] text-white font-sans pt-24 pb-12 px-6" dir="rtl">
        <div class="container mx-auto max-w-7xl">

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">

                <div class="lg:col-span-2 bg-[#0a101f] rounded-[2.5rem] border border-white/5 overflow-hidden shadow-2xl relative h-[450px]">
                    <div class="absolute top-6 right-6 z-10">
                        <span class="bg-red-500 text-white px-4 py-2 rounded-2xl text-xs font-black shadow-xl animate-pulse">
                            موقع آخر عطل تم رصده
                        </span>
                    </div>
                    <iframe
                        width="100%" height="100%" frameborder="0" style="border:0; filter: invert(90%) hue-rotate(180deg) brightness(95%) contrast(90%);"
                        :src="`https://maps.google.com/maps?q=${latestDefect?.location_lat || 30.0444},${latestDefect?.location_lng || 31.2357}&z=15&output=embed`"
                        allowfullscreen>
                    </iframe>
                </div>

                <div class="bg-[#0a101f] rounded-[2.5rem] border border-white/5 p-8 flex flex-col shadow-2xl">
                    <h3 class="text-xl font-black mb-6 flex items-center gap-3">
                        <span class="w-3 h-3 bg-yellow-500 rounded-full shadow-[0_0_10px_#eab308]"></span>
                        تحليل الروبوت (Gemini AI)
                    </h3>

                    <div v-if="latestDefect" class="flex-1">
                        <div class="bg-white/5 rounded-3xl p-6 mb-6 border border-white/5 italic text-slate-300 leading-relaxed text-sm">
                            "{{ latestDefect.gemini_analysis }}"
                        </div>

                        <div class="grid grid-cols-2 gap-3 mb-6">
                            <div class="relative group">
                                <img :src="latestDefect.image_1_url" class="rounded-2xl border border-white/10 w-full h-24 object-cover" />
                                <span class="absolute bottom-2 right-2 text-[8px] bg-black/50 px-2 py-0.5 rounded">CAM 01</span>
                            </div>
                            <div class="relative group">
                                <img :src="latestDefect.image_2_url" class="rounded-2xl border border-white/10 w-full h-24 object-cover" />
                                <span class="absolute bottom-2 right-2 text-[8px] bg-black/50 px-2 py-0.5 rounded">CAM 02</span>
                            </div>
                        </div>

                        <div class="space-y-3">
                            <div class="flex justify-between items-center bg-white/5 p-3 rounded-xl">
                                <span class="text-xs text-slate-400">Ultrasonic 01</span>
                                <span class="text-yellow-500 font-mono font-bold">{{ latestDefect.ultrasonic_1 }}mm</span>
                            </div>
                            <div class="flex justify-between items-center bg-white/5 p-3 rounded-xl">
                                <span class="text-xs text-slate-400">Danger Level</span>
                                <span class="text-red-500 font-black uppercase text-xs">{{ latestDefect.danger_level }}</span>
                            </div>
                        </div>
                    </div>
                    <div v-else class="flex-1 flex flex-col items-center justify-center text-slate-500 italic">
                        <p>بانتظار بيانات الروبوت...</p>
                    </div>
                </div>
            </div>

            <div class="bg-[#0a101f] rounded-[2.5rem] border border-white/5 p-10 shadow-2xl">
                <div class="flex justify-between items-center mb-10">
                    <h3 class="text-2xl font-black">تاريخ الإنذارات</h3>
                    <button class="bg-white/5 hover:bg-white/10 text-xs px-6 py-2 rounded-full border border-white/10 transition-all">تصدير التقرير PDF</button>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full text-right">
                        <thead>
                            <tr class="text-slate-500 text-sm border-b border-white/5">
                                <th class="pb-5 font-medium">التوقيت</th>
                                <th class="pb-5 font-medium">الموقع الإحداثي</th>
                                <th class="pb-5 font-medium">مستوى الخطر</th>
                                <th class="pb-5 font-medium">ملخص الحالة</th>
                                <th class="pb-5 font-medium">الإجراء</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-white/5">
                            <tr v-for="defect in history" :key="defect.id" class="group hover:bg-white/[0.02] transition-colors">
                                <td class="py-6 text-sm text-slate-300">{{ formatDate(defect.detected_at) }}</td>
                                <td class="py-6 font-mono text-xs text-blue-400">{{ defect.location_lat }}, {{ defect.location_lng }}</td>
                                <td class="py-6">
                                    <span :class="getStatusBadge(defect.danger_level)">{{ defect.danger_level }}</span>
                                </td>
                                <td class="py-6 text-sm text-slate-400 max-w-xs truncate">{{ defect.gemini_analysis }}</td>
                                <td class="py-6">
                                    <button class="text-yellow-500 hover:text-yellow-400 text-xs font-bold underline underline-offset-8">فتح الملف</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
import { computed } from 'vue';

// استقبال البيانات من المتحكم عبر Inertia
defineProps({
    stats: {
        type: Object,
        default: () => ({})
    },
    criticalDefects: {
        type: Array,
        default: () => []
    },
    recentDefects: {
        type: Array,
        default: () => []
    },
    recentSensorData: {
        type: Array,
        default: () => []
    },
    defectDistribution: {
        type: Array,
        default: () => []
    },
    sensorStatus: {
        type: Array,
        default: () => []
    }
});

const latestDefect = computed(() => {
    return criticalDefects.length > 0 ? criticalDefects[0] : null;
});

const history = computed(() => {
    return recentDefects;
});

const formatDate = (d) => {
    if (!d) return 'N/A';
    return new Date(d).toLocaleString('ar-EG');
};

const getStatusBadge = (level) => {
    const base = "px-3 py-1 rounded-full text-[10px] font-black uppercase border ";
    if (level === 'high') return base + "bg-red-500/10 text-red-500 border-red-500/20";
    if (level === 'medium') return base + "bg-orange-500/10 text-orange-500 border-orange-500/20";
    return base + "bg-blue-500/10 text-blue-400 border-blue-500/20";
};
</script>
