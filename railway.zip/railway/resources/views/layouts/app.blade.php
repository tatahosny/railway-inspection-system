<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RailGuard | @yield('title')</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;900&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Tajawal', sans-serif; background-color: #05080f; color: white; overflow-x: hidden; }
        .glass { background: rgba(10, 16, 31, 0.8); backdrop-filter: blur(10px); border: 1px solid rgba(255,255,255,0.05); }
        .sidebar-link.active { background: rgba(37, 99, 235, 0.1); color: #3b82f6; border: 1px solid rgba(37, 99, 235, 0.2); }
        ::-webkit-scrollbar { width: 5px; }
        ::-webkit-scrollbar-thumb { background: #1e293b; border-radius: 10px; }
    </style>
</head>
<body class="flex">

    <aside class="w-64 h-screen fixed right-0 bg-[#0a101f] border-l border-white/5 p-6 z-50 flex flex-col shadow-2xl">
        <div class="text-2xl font-black text-blue-500 mb-10 flex items-center gap-2">
            <i class="fas fa-train-subway"></i> RailGuard
        </div>

        <div class="mb-8 p-4 bg-white/5 rounded-2xl border border-white/10 flex items-center gap-3 relative group">
            <div class="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center font-bold text-white shadow-lg">
                {{ substr(Auth::user()->name, 0, 1) }}
            </div>
            <div class="flex-1 overflow-hidden">
                <p class="text-xs font-bold text-white truncate">{{ Auth::user()->name }}</p>
                <p class="text-[9px] text-slate-500 uppercase tracking-tighter">مهندس مشغل</p>
            </div>
            <a href="{{ route('profile.edit') }}" class="absolute -top-1 -left-1 w-5 h-5 bg-[#1a2235] rounded-full flex items-center justify-center text-[10px] text-slate-400 opacity-0 group-hover:opacity-100 transition-all border border-white/10">
                <i class="fas fa-cog"></i>
            </a>
        </div>

        <nav class="flex-1 space-y-2">
            <a href="{{ route('dashboard') }}" class="sidebar-link flex items-center gap-3 p-4 rounded-2xl transition {{ request()->routeIs('dashboard') ? 'active text-blue-500' : 'text-slate-400 hover:bg-white/5' }}">
                <i class="fas fa-chart-line"></i> لوحة التحكم
            </a>
            <a href="{{ route('tracking') }}" class="sidebar-link flex items-center gap-3 p-4 rounded-2xl transition {{ request()->routeIs('tracking') ? 'active text-blue-500' : 'text-slate-400 hover:bg-white/5' }}">
                <i class="fas fa-map-location-dot"></i> التتبع الحي
            </a>
            @if(Auth::user()->is_admin)
            <a href="{{ route('admin.users.index') }}" class="sidebar-link flex items-center gap-3 p-4 rounded-2xl transition {{ request()->routeIs('admin.users.*') ? 'active text-blue-500' : 'text-slate-400 hover:bg-white/5' }}">
                <i class="fas fa-users-gear"></i> إدارة المستخدمين
            </a>
            @endif
        </nav>

        <div class="mt-auto space-y-4">
            <div class="p-4 bg-white/5 rounded-2xl text-[10px] text-slate-500 text-center font-mono border border-white/5">
                SYSTEM CORE: RASPBERRY PI 5
            </div>
            <form action="{{ route('logout') }}" method="POST">
                @csrf
                <button class="w-full text-right p-4 text-red-500 hover:bg-red-500/5 rounded-2xl transition flex items-center gap-3 font-bold text-xs uppercase tracking-widest">
                    <i class="fas fa-power-off"></i> تسجيل الخروج
                </button>
            </form>
        </div>
    </aside>

    <main class="flex-1 mr-64 p-10 min-h-screen">
        @yield('content')
    </main>

</body>
</html>
