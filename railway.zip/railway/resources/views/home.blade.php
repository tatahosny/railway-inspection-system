<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RailGuard - نظام فحص السكة الحديد</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { font-family: 'Cairo', sans-serif; }
        body { background: #0a0a0a; overflow-x: hidden; }
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: #1a1a1a; }
        ::-webkit-scrollbar-thumb { background: linear-gradient(to bottom, #fbbf24, #f97316); border-radius: 4px; }

        [v-cloak] { display: none; }

        /* تأثير الاختفاء الناعم لشاشة التحميل */
        .fade-exit-active {
            transition: opacity 0.8s ease-in-out;
        }
        .fade-exit-to {
            opacity: 0;
        }
    </style>
    @vite('resources/css/app.css')
</head>
<body class="text-white">
    <div id="app" v-cloak>

        <transition name="fade-exit">
            <div v-if="loading" class="fixed inset-0 bg-[#0a0f1a] flex items-center justify-center z-[100]">
                <div class="text-center">
                    <div class="relative w-32 h-32 mx-auto mb-6">
                        <div class="absolute inset-0 border-4 border-yellow-400/20 rounded-full"></div>
                        <div class="absolute inset-0 border-t-4 border-yellow-500 rounded-full animate-spin"></div>
                        <div class="absolute inset-4 bg-gradient-to-tr from-yellow-400 to-orange-600 rounded-full animate-pulse shadow-[0_0_30px_rgba(251,191,36,0.4)]"></div>
                    </div>
                    <h2 class="text-2xl font-bold text-white tracking-widest mb-2">RAIL<span class="text-yellow-500">GUARD</span></h2>
                    <p class="text-slate-400 animate-pulse text-sm font-light">جاري تهيئة نظام الفحص الذكي...</p>
                </div>
            </div>
        </transition>

        <div v-show="!loading">
            <navbar :current-page="currentPage" @change-page="changePage"></navbar>

            <main class="min-h-screen">
                <div v-if="currentPage === 'home'">
                    <hero-section></hero-section>
                    <stats-section></stats-section>
                    <features-section></features-section>
                    <how-it-works></how-it-works>
                    <inspections-section></inspections-section>
                    <ai-capabilities></ai-capabilities>
                </div>

                <about-page v-else-if="currentPage === 'about'"></about-page>
                <features-page v-else-if="currentPage === 'features'"></features-page>
                <defects-page v-else-if="currentPage === 'defects'"></defects-page>
                <contact-page v-else-if="currentPage === 'contact'"></contact-page>
            </main>

            <footer-section></footer-section>
        </div>
    </div>

    @vite('resources/js/app.js')
</body>
</html>
