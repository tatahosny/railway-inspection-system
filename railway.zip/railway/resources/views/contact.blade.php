@extends('layouts.app')

@section('title', 'Contact')

@section('content')
<div class="container py-5">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <h1 class="fw-bold text-center mb-4">Contact Us</h1>
            <p class="lead text-center mb-5">We're here to answer your questions and discuss how our railway inspection system can benefit your operations</p>
            
            <div class="row mb-5">
                <div class="col-md-4 text-center mb-4">
                    <div class="feature-icon">
                        <i class="fas fa-map-marker-alt"></i>
                    </div>
                    <h5 class="fw-bold">Address</h5>
                    <p class="text-muted">123 Railway Street<br>Industrial Area<br>Cairo, Egypt</p>
                </div>
                <div class="col-md-4 text-center mb-4">
                    <div class="feature-icon">
                        <i class="fas fa-phone"></i>
                    </div>
                    <h5 class="fw-bold">Phone</h5>
                    <p class="text-muted">+20 100 000 0000<br>+20 122 000 0000</p>
                    <small class="text-muted">Available 24/7 for emergencies</small>
                </div>
                <div class="col-md-4 text-center mb-4">
                    <div class="feature-icon">
                        <i class="fas fa-envelope"></i>
                    </div>
                    <h5 class="fw-bold">Email</h5>
                    <p class="text-muted">info@railway-system.com<br>support@railway-system.com</p>
                    <small class="text-muted">Response within 24 hours</small>
                </div>
            </div>
            
            <div class="card card-hover p-4 mb-5">
                <h3 class="fw-bold mb-4 text-center">Send Us a Message</h3>
                <form id="contactForm">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="name" class="form-label fw-semibold">Full Name *</label>
                            <input type="text" class="form-control" id="name" placeholder="Enter your full name" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="email" class="form-label fw-semibold">Email Address *</label>
                            <input type="email" class="form-control" id="email" placeholder="Enter your email" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="company" class="form-label fw-semibold">Company/Organization</label>
                        <input type="text" class="form-control" id="company" placeholder="Enter your company name">
                    </div>
                    <div class="mb-3">
                        <label for="subject" class="form-label fw-semibold">Subject *</label>
                        <select class="form-select" id="subject" required>
                            <option value="">Select a subject</option>
                            <option value="general">General Inquiry</option>
                            <option value="demo">Request a Demo</option>
                            <option value="pricing">Pricing Information</option>
                            <option value="technical">Technical Support</option>
                            <option value="partnership">Partnership Opportunity</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="message" class="form-label fw-semibold">Message *</label>
                        <textarea class="form-control" id="message" rows="6" placeholder="Tell us about your requirements or questions..." required></textarea>
                    </div>
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="newsletter">
                        <label class="form-check-label" for="newsletter">Subscribe to our newsletter for updates</label>
                    </div>
                    <button type="submit" class="btn btn-primary btn-lg w-100">
                        <i class="fas fa-paper-plane me-2"></i>Send Message
                    </button>
                </form>
            </div>

            <!-- FAQ Section -->
            <div class="card card-hover p-4">
                <h3 class="fw-bold mb-4 text-center">Frequently Asked Questions</h3>
                <div class="accordion" id="faqAccordion">
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq1">
                                How quickly can you deploy the inspection system?
                            </button>
                        </h2>
                        <div id="faq1" class="accordion-collapse collapse show" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Standard deployment takes 2-4 weeks, including sensor installation, system configuration, and staff training. Emergency deployments can be arranged within 1 week for critical situations.
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2">
                                What kind of support do you provide?
                            </button>
                        </h2>
                        <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                We provide 24/7 technical support, regular system updates, maintenance services, and comprehensive training for your staff. Our support includes phone, email, and remote assistance.
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq3">
                                Can the system integrate with our existing infrastructure?
                            </button>
                        </h2>
                        <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Yes, our system is designed to integrate seamlessly with existing railway infrastructure and management systems. We provide API access and custom integration services.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@section('scripts')
<script>
document.getElementById('contactForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Simulate form submission
    const submitBtn = this.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Sending...';
    submitBtn.disabled = true;
    
    setTimeout(() => {
        // Show success message
        alert('Thank you for your message! We will get back to you within 24 hours.');
        this.reset();
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }, 2000);
});
</script>
@endsection
@endsection