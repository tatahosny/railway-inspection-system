@extends('layouts.app')

@section('title', 'About')

@section('content')
<div class="container py-5">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <h1 class="fw-bold text-center mb-4">About Our System</h1>
            <p class="lead text-center mb-5">Learn more about our advanced railway inspection system and how it works to ensure railway safety</p>
            
            <div class="card card-hover p-4 mb-4">
                <h3 class="fw-bold mb-3">Our Mission</h3>
                <p>We aim to improve railway transportation safety by providing an integrated system for early detection of rail defects, which helps reduce accidents and increase maintenance efficiency. Our goal is to make railway transportation safer and more reliable through advanced technology.</p>
            </div>
            
            <div class="card card-hover p-4 mb-4">
                <h3 class="fw-bold mb-3">How It Works</h3>
                <p>Our system relies on a set of advanced sensors and high-resolution cameras that continuously collect data from the rails. This data is analyzed using artificial intelligence algorithms to detect any defects or cracks in real-time.</p>
                <ul>
                    <li><strong>4 Advanced Sensors:</strong> Monitor vibrations, pressure, temperature, and deformation</li>
                    <li><strong>High-Resolution Cameras:</strong> Capture detailed images for visual inspection</li>
                    <li><strong>Wireless Communication:</strong> Real-time data transmission to our servers</li>
                    <li><strong>AI Analysis:</strong> Machine learning algorithms detect patterns and defects</li>
                    <li><strong>Instant Alerts:</strong> Immediate notifications for critical issues</li>
                </ul>
            </div>
            
            <div class="card card-hover p-4">
                <h3 class="fw-bold mb-3">System Benefits</h3>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <div class="d-flex align-items-start">
                            <div class="feature-icon-sm bg-primary rounded-circle d-flex align-items-center justify-content-center me-3 mt-1">
                                <i class="fas fa-shield-alt text-white"></i>
                            </div>
                            <div>
                                <h5>Increased Safety</h5>
                                <p class="text-muted mb-0">Early detection of defects prevents accidents and ensures passenger safety</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <div class="d-flex align-items-start">
                            <div class="feature-icon-sm bg-primary rounded-circle d-flex align-items-center justify-content-center me-3 mt-1">
                                <i class="fas fa-money-bill-wave text-white"></i>
                            </div>
                            <div>
                                <h5>Cost Savings</h5>
                                <p class="text-muted mb-0">Preventive maintenance saves major repair costs and extends rail lifespan</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <div class="d-flex align-items-start">
                            <div class="feature-icon-sm bg-primary rounded-circle d-flex align-items-center justify-content-center me-3 mt-1">
                                <i class="fas fa-clock text-white"></i>
                            </div>
                            <div>
                                <h5>Time Efficiency</h5>
                                <p class="text-muted mb-0">Continuous monitoring saves manual inspection time and reduces downtime</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <div class="d-flex align-items-start">
                            <div class="feature-icon-sm bg-primary rounded-circle d-flex align-items-center justify-content-center me-3 mt-1">
                                <i class="fas fa-chart-line text-white"></i>
                            </div>
                            <div>
                                <h5>Performance Improvement</h5>
                                <p class="text-muted mb-0">Accurate data helps optimize maintenance schedules and improve operations</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Technology Stack Section -->
            <div class="card card-hover p-4 mt-4">
                <h3 class="fw-bold mb-3">Our Technology Stack</h3>
                <div class="row text-center">
                    <div class="col-md-4 mb-3">
                        <div class="technology-item">
                            <i class="fas fa-robot fa-3x text-primary mb-3"></i>
                            <h5>AI & Machine Learning</h5>
                            <p class="text-muted small">Advanced algorithms for defect detection and prediction</p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="technology-item">
                            <i class="fas fa-satellite-dish fa-3x text-primary mb-3"></i>
                            <h5>IoT Sensors</h5>
                            <p class="text-muted small">Network of smart sensors for real-time monitoring</p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="technology-item">
                            <i class="fas fa-cloud fa-3x text-primary mb-3"></i>
                            <h5>Cloud Computing</h5>
                            <p class="text-muted small">Scalable cloud infrastructure for data processing</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.technology-item {
    padding: 20px;
    border-radius: 10px;
    transition: all 0.3s ease;
}
.technology-item:hover {
    background: var(--light-color);
    transform: translateY(-5px);
}
.feature-icon-sm {
    width: 40px;
    height: 40px;
    font-size: 1rem;
    flex-shrink: 0;
}
</style>
@endsection