<aside class="w-64 h-screen fixed right-0 bg-[#0a101f] border-l border-white/5 p-6 z-50 flex flex-col">
    <div class="text-2xl font-black text-blue-500 mb-12 flex items-center gap-2">
        <i class="fas fa-train-subway"></i> RailGuard
    </div>

    <div class="mb-10 p-4 bg-white/5 rounded-[1.5rem] border border-white/5 relative group">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-700 rounded-full flex items-center justify-center font-bold text-white shadow-lg">
                {{ substr(auth()->user()->name, 0, 1) }}
            </div>
            <div class="overflow-hidden">
                <p class="text-xs font-black text-white truncate">{{ auth()->user()->name }}</p>
                <p class="text-[9px] text-slate-500 truncate">{{ auth()->user()->email }}</p>
            </div>
        </div>
        {{-- زرار الإعدادات السريع --}}
        <a href="{{ route('profile.edit') }}" class="absolute -top-2 -left-2 w-6 h-6 bg-[#1a2235] border border-white/10 rounded-full flex items-center justify-center text-[10px] text-slate-400 hover:text-blue-500 opacity-0 group-hover:opacity-100 transition-all">
            <i class="fas fa-cog"></i>
        </a>
    </div>

    <nav class="flex-1 space-y-2">
        <a href="{{ route('dashboard') }}" class="flex items-center gap-3 p-4 {{ request()->routeIs('dashboard') ? 'bg-blue-600/10 text-blue-500 border border-blue-600/20' : 'text-slate-400' }} rounded-2xl transition font-bold">
            <i class="fas fa-chart-pie"></i> لوحة التحكم
        </a>
        <a href="{{ route('tracking') }}" class="flex items-center gap-3 p-4 {{ request()->routeIs('tracking') ? 'bg-blue-600/10 text-blue-500 border border-blue-600/20' : 'text-slate-400' }} rounded-2xl transition">
            <i class="fas fa-map-location-dot"></i> التتبع الحي
        </a>
        @if(auth()->user()->is_admin)
        <a href="{{ route('admin.users.index') }}" class="flex items-center gap-3 p-4 {{ request()->routeIs('admin.users.*') ? 'bg-blue-600/10 text-blue-500 border border-blue-600/20' : 'text-slate-400' }} rounded-2xl transition">
            <i class="fas fa-user-shield"></i> إدارة المهندسين
        </a>
        @endif
    </nav>

    {{-- زر الخروج --}}
    <form action="{{ route('logout') }}" method="POST" class="mt-auto">
        @csrf
        <button class="w-full text-right p-4 text-red-500 hover:bg-red-500/5 rounded-2xl transition flex items-center gap-3 font-bold text-sm">
            <i class="fas fa-power-off"></i> تسجيل الخروج
        </button>
    </form>
</aside>
