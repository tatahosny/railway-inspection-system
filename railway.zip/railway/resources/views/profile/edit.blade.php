@extends('layouts.app')

@section('content')
<style>
    /* تأثير الزجاج والخلفية */
    .profile-card {
        background: rgba(17, 25, 40, 0.8);
        backdrop-filter: blur(15px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 20px;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
    }

    /* الحقول */
    .input-field {
        background: rgba(255, 255, 255, 0.03) !important;
        border: 1px solid rgba(255, 255, 255, 0.1) !important;
        color: #fff !important;
        border-radius: 10px !important;
        padding: 12px 15px !important;
        transition: all 0.3s ease;
    }
    .input-field:focus {
        border-color: #3b82f6 !important;
        background: rgba(255, 255, 255, 0.07) !important;
        box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2) !important;
    }

    /* منطقة رفع الصورة المدمجة */
    .avatar-inline-wrapper {
        display: flex;
        align-items: center;
        gap: 20px;
        background: rgba(255, 255, 255, 0.05);
        padding: 20px;
        border-radius: 15px;
        border: 1px dashed rgba(255, 255, 255, 0.2);
    }
    .avatar-preview-small {
        width: 80px;
        height: 80px;
        border-radius: 12px;
        object-fit: cover;
        border: 2px solid #3b82f6;
    }
    .custom-upload-label {
        background: #3b82f6;
        color: white;
        padding: 8px 16px;
        border-radius: 8px;
        cursor: pointer;
        font-size: 14px;
        transition: 0.3s;
    }
    .custom-upload-label:hover { background: #2563eb; }

    label { color: rgba(255, 255, 255, 0.6); font-size: 0.85rem; margin-bottom: 8px; display: block; }
</style>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-xl-9 col-lg-10">
            <div class="profile-card p-4 p-md-5 text-white">

                <div class="mb-5 border-bottom border-white border-opacity-10 pb-4">
                    <h3 class="fw-bold mb-1">الملف الشخصي</h3>
                    <p class="text-muted mb-0">قم بتحديث معلوماتك المهنية وصورتك الشخصية من هنا.</p>
                </div>

                @if (session('status') === 'profile-updated')
                    <div class="alert alert-success border-0 bg-success bg-opacity-10 text-success rounded-3 mb-4 py-3">
                        <i class="fas fa-check-circle me-2"></i> تم تحديث البيانات بنجاح يا هندسة!
                    </div>
                @endif

                <form method="POST" action="{{ route('profile.update') }}" enctype="multipart/form-data">
                    @csrf
                    @method('PATCH')

                    <div class="row g-4">
                        <div class="col-12 mb-2">
                            <label class="text-uppercase fw-bold">الصورة الشخصية</label>
                            <div class="avatar-inline-wrapper">
                                <img id="avatarPreview" src="{{ auth()->user()->avatar_url }}" class="avatar-preview-small shadow">
                                <div>
                                    <p class="small text-muted mb-2">يفضل استخدام صورة مربعة بحجم أقل من 2 ميجا</p>
                                    <label for="avatar" class="custom-upload-label mb-0">
                                        <i class="fas fa-cloud-upload-alt me-2"></i> رفع صورة جديدة
                                    </label>
                                    <input type="file" id="avatar" name="avatar" class="d-none" onchange="previewImage(event)">
                                </div>
                            </div>
                            @error('avatar') <span class="text-danger small d-block mt-2">{{ $message }}</span> @enderror
                        </div>

                        <div class="col-md-6">
                            <label class="text-uppercase fw-bold">الاسم بالكامل</label>
                            <input type="text" name="name" class="form-control input-field" value="{{ old('name', $user->name) }}" required>
                            @error('name') <span class="text-danger small">{{ $message }}</span> @enderror
                        </div>

                        <div class="col-md-6">
                            <label class="text-uppercase fw-bold">البريد الإلكتروني الرسمي</label>
                            <input type="email" name="email" class="form-control input-field" value="{{ old('email', $user->email) }}" required>
                            @error('email') <span class="text-danger small">{{ $message }}</span> @enderror
                        </div>

                        <div class="col-md-6">
                            <label class="text-uppercase fw-bold">القسم الوظيفي</label>
                            <input type="text" class="form-control input-field opacity-50" value="{{ $user->department ?? 'Engineering' }}" disabled>
                        </div>

                        <div class="col-md-6">
                            <label class="text-uppercase fw-bold">رقم التعريف (Device ID)</label>
                            <input type="text" class="form-control input-field opacity-50" value="{{ $user->device_id ?? 'RAIL-882' }}" disabled>
                        </div>

                        <div class="col-12 mt-4">
                            <button type="submit" class="btn btn-primary px-4 py-2 fw-bold rounded-2">
                                <i class="fas fa-save me-2"></i> حفظ التغييرات
                            </button>
                        </div>
                    </div>
                </form>

                <div class="my-5 border-bottom border-white border-opacity-10"></div>

                <div class="row g-4">
                    <div class="col-lg-4">
                        <h5 class="fw-bold"><i class="fas fa-shield-alt me-2 text-primary"></i> الأمان</h5>
                        <p class="text-muted small">تحديث كلمة المرور بانتظام يعزز من حماية بيانات مشروعك.</p>
                    </div>
                    <div class="col-lg-8">
                        <form method="POST" action="{{ route('password.update') }}">
                            @csrf
                            @method('PUT')
                            <div class="row g-3">
                                <div class="col-12">
                                    <input type="password" name="current_password" placeholder="كلمة المرور الحالية" class="form-control input-field">
                                </div>
                                <div class="col-md-6">
                                    <input type="password" name="password" placeholder="الكلمة الجديدة" class="form-control input-field">
                                </div>
                                <div class="col-md-6">
                                    <input type="password" name="password_confirmation" placeholder="تأكيد الكلمة الجديدة" class="form-control input-field">
                                </div>
                                <div class="col-12">
                                    <button type="submit" class="btn btn-outline-light btn-sm px-3 mt-2 border-opacity-25">
                                        تغيير المفتاح السري
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<script>
    function previewImage(event) {
        var reader = new FileReader();
        reader.onload = function() {
            var output = document.getElementById('avatarPreview');
            output.src = reader.result;
        }
        reader.readAsDataURL(event.target.files[0]);
    }
</script>
@endsection
