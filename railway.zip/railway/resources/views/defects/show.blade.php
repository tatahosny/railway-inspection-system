@extends('layouts.app')

@section('title', 'Defect Details: ' . $defect->defect_id)

@section('content')
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-lg-8">
            <!-- Defect Information -->
            <div class="card dashboard-card mb-4">
                <div class="card-header bg-{{ $defect->severity == 'high' ? 'danger' : ($defect->severity == 'medium' ? 'warning' : 'info') }} text-white">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            Defect Details: {{ $defect->defect_id }}
                        </h5>
                        <span class="badge bg-light text-dark">
                            {{ strtoupper($defect->severity) }} PRIORITY
                        </span>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr>
                                    <th width="40%">Defect Type:</th>
                                    <td><strong>{{ $defect->defect_type }}</strong></td>
                                </tr>
                                <tr>
                                    <th>Location:</th>
                                    <td>
                                        <i class="fas fa-map-marker-alt text-danger me-1"></i>
                                        {{ $defect->location }}
                                    </td>
                                </tr>
                                <tr>
                                    <th>Severity:</th>
                                    <td>
                                        <span class="badge bg-{{ $defect->severity == 'high' ? 'danger' : ($defect->severity == 'medium' ? 'warning' : 'success') }}">
                                            {{ ucfirst($defect->severity) }}
                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Status:</th>
                                    <td>
                                        <span class="badge bg-{{ $defect->status == 'open' ? 'warning' : ($defect->status == 'in_progress' ? 'info' : 'success') }}">
                                            {{ ucfirst(str_replace('_', ' ', $defect->status)) }}
                                        </span>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr>
                                    <th width="40%">Detected At:</th>
                                    <td>{{ $defect->detected_at->format('M d, Y H:i:s') }}</td>
                                </tr>
                                <tr>
                                    <th>Assigned To:</th>
                                    <td>
                                        @if($defect->assignedUser)
                                            {{ $defect->assignedUser->name }}
                                        @else
                                            <span class="text-muted">Not assigned</span>
                                        @endif
                                    </td>
                                </tr>
                                <tr>
                                    <th>Coordinates:</th>
                                    <td>
                                        @if($defect->latitude && $defect->longitude)
                                            {{ $defect->latitude }}, {{ $defect->longitude }}
                                        @else
                                            <span class="text-muted">Not available</span>
                                        @endif
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <!-- Description -->
                    <div class="mb-4">
                        <h6 class="fw-bold">Description</h6>
                        <p class="text-muted">{{ $defect->description }}</p>
                    </div>

                    <!-- Sensor Readings -->
                    @if($defect->sensor_readings)
                    <div class="mb-4">
                        <h6 class="fw-bold">Sensor Readings at Detection</h6>
                        <div class="row">
                            @foreach($defect->formatted_readings as $reading)
                            <div class="col-md-3 mb-2">
                                <div class="sensor-reading-card p-3 border rounded text-center">
                                    <div class="h6 mb-1 text-muted">{{ $reading['sensor'] }}</div>
                                    <div class="h4 fw-bold text-primary">{{ $reading['value'] }}</div>
                                    <div class="small text-muted">{{ $reading['unit'] }}</div>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                    @endif

                    <!-- Notes -->
                    @if($defect->notes)
                    <div class="mb-4">
                        <h6 class="fw-bold">Additional Notes</h6>
                        <div class="alert alert-info">
                            {{ $defect->notes }}
                        </div>
                    </div>
                    @endif
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <!-- Defect Image -->
            <div class="card dashboard-card mb-4">
                <div class="card-header bg-secondary text-white">
                    <h6 class="mb-0">
                        <i class="fas fa-camera me-2"></i>Defect Image
                    </h6>
                </div>
                <div class="card-body text-center">
                    @if($defect->hasImage())
                        <img src="{{ $defect->image_url }}" 
                             alt="Defect Image" 
                             class="img-fluid rounded shadow-sm"
                             style="max-height: 300px;">
                        <p class="text-muted mt-2 small">Image captured at detection time</p>
                    @else
                        <div class="py-5 text-center">
                            <i class="fas fa-image fa-3x text-muted mb-3"></i>
                            <p class="text-muted">No image available for this defect</p>
                        </div>
                    @endif
                </div>
            </div>

            <!-- Actions -->
            <div class="card dashboard-card">
                <div class="card-header bg-dark text-white">
                    <h6 class="mb-0">
                        <i class="fas fa-cogs me-2"></i>Actions
                    </h6>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        @if($defect->status !== 'resolved')
                            <button class="btn btn-success mb-2" data-bs-toggle="modal" data-bs-target="#resolveModal">
                                <i class="fas fa-check me-2"></i>Mark as Resolved
                            </button>
                        @endif
                        
                        @if(!$defect->assigned_to)
                            <button class="btn btn-info mb-2" data-bs-toggle="modal" data-bs-target="#assignModal">
                                <i class="fas fa-user-plus me-2"></i>Assign to Inspector
                            </button>
                        @endif

                        <a href="#" class="btn btn-outline-primary mb-2">
                            <i class="fas fa-download me-2"></i>Download Report
                        </a>

                        <a href="{{ route('dashboard') }}" class="btn btn-outline-secondary">
                            <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Resolve Modal -->
<div class="modal fade" id="resolveModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Mark Defect as Resolved</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="{{ route('defects.resolve', $defect->id) }}" method="POST">
                @csrf
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="resolution_notes" class="form-label">Resolution Notes</label>
                        <textarea class="form-control" id="resolution_notes" name="notes" 
                                  rows="4" placeholder="Describe how the defect was resolved..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success">Mark as Resolved</button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
.sensor-reading-card {
    transition: all 0.3s ease;
    background: #f8f9fa;
}
.sensor-reading-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}
</style>
@endsection