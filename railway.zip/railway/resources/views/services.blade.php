@extends('layouts.app')

@section('title', 'Services')

@section('content')
<div class="container py-5">
    <div class="row text-center mb-5">
        <div class="col-lg-8 mx-auto">
            <h1 class="fw-bold mb-3">Our Services</h1>
            <p class="lead text-muted">Comprehensive railway inspection and monitoring solutions tailored to your needs</p>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-6 mb-4">
            <div class="card card-hover h-100">
                <div class="card-body p-4">
                    <div class="feature-icon">
                        <i class="fas fa-search"></i>
                    </div>
                    <h4 class="card-title fw-bold">Rail Inspection</h4>
                    <p class="card-text">Comprehensive inspection of railway rails using advanced sensors to detect defects, cracks, and structural issues with high precision.</p>
                    <ul class="list-unstyled mb-4">
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Vibration analysis and monitoring</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Pressure and stress measurement</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Crack detection and analysis</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Structural integrity assessment</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Wear and tear monitoring</li>
                    </ul>
                    <div class="service-features">
                        <span class="badge bg-primary me-2 mb-2">Real-time Data</span>
                        <span class="badge bg-primary me-2 mb-2">High Accuracy</span>
                        <span class="badge bg-primary me-2 mb-2">24/7 Monitoring</span>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-6 mb-4">
            <div class="card card-hover h-100">
                <div class="card-body p-4">
                    <div class="feature-icon">
                        <i class="fas fa-camera"></i>
                    </div>
                    <h4 class="card-title fw-bold">Visual Inspection</h4>
                    <p class="card-text">Advanced visual inspection using high-resolution cameras and computer vision technology to identify surface defects and anomalies.</p>
                    <ul class="list-unstyled mb-4">
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i>High-resolution imaging</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Automatic image analysis</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Defect location mapping</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Surface quality assessment</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Corrosion detection</li>
                    </ul>
                    <div class="service-features">
                        <span class="badge bg-primary me-2 mb-2">HD Imaging</span>
                        <span class="badge bg-primary me-2 mb-2">AI Analysis</span>
                        <span class="badge bg-primary me-2 mb-2">Precision Mapping</span>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-6 mb-4">
            <div class="card card-hover h-100">
                <div class="card-body p-4">
                    <div class="feature-icon">
                        <i class="fas fa-chart-bar"></i>
                    </div>
                    <h4 class="card-title fw-bold">Data Analytics</h4>
                    <p class="card-text">Comprehensive data analysis and reporting services to transform raw sensor data into actionable insights and maintenance recommendations.</p>
                    <ul class="list-unstyled mb-4">
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Statistical analysis and trends</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Customized reporting</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Predictive maintenance</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Performance analytics</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Risk assessment reports</li>
                    </ul>
                    <div class="service-features">
                        <span class="badge bg-primary me-2 mb-2">Predictive AI</span>
                        <span class="badge bg-primary me-2 mb-2">Custom Reports</span>
                        <span class="badge bg-primary me-2 mb-2">Risk Analysis</span>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-6 mb-4">
            <div class="card card-hover h-100">
                <div class="card-body p-4">
                    <div class="feature-icon">
                        <i class="fas fa-bell"></i>
                    </div>
                    <h4 class="card-title fw-bold">Alert System</h4>
                    <p class="card-text">Instant alert and notification system that immediately informs relevant personnel when critical defects or safety issues are detected.</p>
                    <ul class="list-unstyled mb-4">
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Instant alert notifications</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Defect severity classification</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Multiple notification channels</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Emergency response coordination</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Escalation procedures</li>
                    </ul>
                    <div class="service-features">
                        <span class="badge bg-primary me-2 mb-2">Instant Alerts</span>
                        <span class="badge bg-primary me-2 mb-2">Multi-channel</span>
                        <span class="badge bg-primary me-2 mb-2">Priority System</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Additional Services Section -->
    <div class="row mt-5">
        <div class="col-12">
            <div class="card card-hover">
                <div class="card-body p-5">
                    <div class="row align-items-center">
                        <div class="col-lg-8">
                            <h3 class="fw-bold mb-3">Need Custom Solutions?</h3>
                            <p class="lead mb-4">We offer tailored inspection solutions to meet your specific railway infrastructure requirements and operational needs.</p>
                            <div class="row">
                                <div class="col-md-6">
                                    <ul class="list-unstyled">
                                        <li class="mb-2"><i class="fas fa-cog text-primary me-2"></i>Custom sensor configurations</li>
                                        <li class="mb-2"><i class="fas fa-cog text-primary me-2"></i>Integration with existing systems</li>
                                        <li class="mb-2"><i class="fas fa-cog text-primary me-2"></i>Specialized reporting formats</li>
                                    </ul>
                                </div>
                                <div class="col-md-6">
                                    <ul class="list-unstyled">
                                        <li class="mb-2"><i class="fas fa-cog text-primary me-2"></i>API access for developers</li>
                                        <li class="mb-2"><i class="fas fa-cog text-primary me-2"></i>Training and support</li>
                                        <li class="mb-2"><i class="fas fa-cog text-primary me-2"></i>Maintenance contracts</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 text-center">
                            <div class="feature-icon-lg">
                                <i class="fas fa-tools"></i>
                            </div>
                            <a href="{{ route('contact') }}" class="btn btn-primary btn-lg mt-3">Contact Us</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.service-features {
    margin-top: auto;
}
.feature-icon-lg {
    width: 100px;
    height: 100px;
    margin: 0 auto;
    background: var(--gradient-primary);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 2.5rem;
    color: white;
    box-shadow: 0 10px 20px rgba(26, 82, 118, 0.3);
}
</style>
@endsection