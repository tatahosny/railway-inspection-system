@extends('layouts.app')

@section('content')
<style>
    .tracking-body { background-color: #05080f; min-height: 100vh; color: white; }
    .glass { background: rgba(10, 16, 31, 0.8); backdrop-filter: blur(12px); border: 1px solid rgba(255,255,255,0.05); }
    .pulse-red { animation: pulse 2s infinite; }
    @keyframes pulse { 0% { opacity: 1; } 50% { opacity: 0.5; } 100% { opacity: 1; } }
    .map-container { height: 600px; }
    @media (max-width: 768px) { .map-container { height: 400px; } }

    /* أنيميشن بسيط للارقام عند التغير */
    .value-update { transition: all 0.3s ease; color: #60a5fa; }
</style>

<div class="tracking-body p-4 md:p-8 text-right" dir="rtl">
    <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
            <h1 class="text-3xl font-black italic tracking-tight text-white">نظام التتبع والسرعة اللحظي</h1>
            <p id="status-text" class="text-slate-500 text-sm mt-1">جاري مزامنة بيانات الـ GPS والـ Encoder...</p>
        </div>

        <div id="connection-badge" class="px-6 py-2 rounded-2xl border flex items-center gap-2 transition-all duration-500">
            </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div class="lg:col-span-3 glass rounded-[2.5rem] map-container overflow-hidden relative shadow-2xl border border-white/10">
            <div class="absolute top-4 right-4 z-10 glass p-3 rounded-xl border border-white/10">
                <p class="text-[10px] text-slate-400 uppercase mb-1">الموقع اللحظي (DMS)</p>
                <p id="live-coords" class="text-xs font-mono text-blue-400 tracking-tighter">0.000000, 0.000000</p>
            </div>
            <iframe id="google-map" width="100%" height="100%" frameborder="0"
                    style="border:0; filter: invert(90%) hue-rotate(180deg);"
                    src="" allowfullscreen></iframe>
        </div>

        <div class="space-y-6">
            <div class="glass p-6 rounded-[2rem] border border-blue-500/10">
                <h3 class="text-sm font-bold mb-4 text-blue-500 uppercase italic flex items-center gap-2">
                    <i class="fas fa-tachometer-alt"></i> مؤشرات الحركة
                </h3>

                <div class="mb-6 text-center py-4 bg-white/5 rounded-3xl border border-white/5">
                    <p class="text-[10px] text-slate-500 uppercase mb-1 font-bold tracking-widest">السرعة الحالية</p>
                    <div class="flex items-baseline justify-center gap-2">
                        <span id="val-speed" class="text-5xl font-black text-blue-500 italic">0.0</span>
                        <span class="text-xs text-slate-400 font-bold uppercase font-mono">Km/h</span>
                    </div>
                </div>

                <div class="space-y-3">
                    <div class="flex justify-between items-center p-3 bg-white/5 rounded-xl border border-white/5">
                        <span class="text-[10px] text-slate-500 font-bold">المسافة المقطوعة</span>
                        <span id="val-distance" class="font-mono text-blue-400 text-sm font-bold">0.00 m</span>
                    </div>
                    <div class="flex justify-between items-center p-3 bg-white/5 rounded-xl border border-white/5">
                        <span class="text-[10px] text-slate-500 font-bold">الاهتزاز (IMU)</span>
                        <span id="val-vibration" class="font-mono text-yellow-500 text-sm font-bold">0.0 G</span>
                    </div>
                    <div class="flex justify-between items-center p-3 bg-red-500/10 rounded-xl border border-red-500/20">
                        <span class="text-[10px] text-red-400 font-black">مستوى الخطر</span>
                        <span id="val-risk" class="font-mono text-red-500 text-sm font-black text-lg">0%</span>
                    </div>
                </div>
            </div>

            <div class="glass p-6 rounded-[2rem] border border-white/5">
                <h3 class="text-sm font-bold mb-4 text-slate-400 uppercase flex items-center gap-2">
                    <i class="fas fa-bolt"></i> تحكم سريع
                </h3>
                <form action="{{ route('robot.move') }}" method="POST" class="space-y-4">
                    @csrf
                    <input type="number" name="distance" step="0.1" placeholder="أدخل المسافة للمتر..."
                           class="w-full bg-white/5 border border-white/10 p-4 rounded-2xl outline-none focus:border-blue-500 text-sm text-white placeholder:text-slate-600 text-center">
                    <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 py-4 rounded-2xl font-black text-[11px] uppercase tracking-widest transition-all shadow-lg shadow-blue-600/30">
                        تنفيذ التحرك <i class="fas fa-arrow-left mr-2"></i>
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    let lastLat = null;
    let lastLng = null;

    function fetchLiveTracking() {
        // نستخدم الـ route اللي بيجيب آخر قراءة من الداتا بيز اللي بيبعتها الراسبري باي
        fetch("{{ route('api.defects.latest') }}")
        .then(response => response.json())
        .then(data => {
            // تأكد من هيكلة الـ JSON اللي راجع من الـ API بتاعك
            if(data.status === 'success' || data.latest_reading) {
                const reading = data.latest_reading;

                // 1. تحديث الخريطة فقط في حالة تغير الموقع لتقليل التحميل
                const lat = parseFloat(reading.latitude) || 0;
                const lng = parseFloat(reading.longitude) || 0;

                if (lat !== lastLat || lng !== lastLng) {
                    document.getElementById('google-map').src = `https://maps.google.com/maps?q=${lat},${lng}&z=18&output=embed&t=k`; // t=k للصور الصناعية
                    document.getElementById('live-coords').innerText = `${lat.toFixed(6)}, ${lng.toFixed(6)}`;
                    lastLat = lat;
                    lastLng = lng;
                }

                // 2. تحديث السرعة من الانكودر (Speed from Encoder)
                // افترضنا أن الراسبري باي بيبعت قيمة باسم encoder_speed
                document.getElementById('val-speed').innerText = reading.encoder_speed || '0.0';

                // 3. تحديث المسافة التراكمية
                document.getElementById('val-distance').innerText = (reading.total_distance || '0.0') + ' m';

                // 4. الحساسات الأخرى
                document.getElementById('val-vibration').innerText = (reading.vibration_value || '0.0') + ' G';
                document.getElementById('val-risk').innerText = (reading.risk_percentage || '0') + '%';

                updateStatus(true);
            } else {
                updateStatus(false);
            }
        })
        .catch(error => {
            console.error('Connection Error:', error);
            updateStatus(false);
        });
    }

    function updateStatus(isOnline) {
        const badge = document.getElementById('connection-badge');
        const statusText = document.getElementById('status-text');

        if(isOnline) {
            badge.className = "px-6 py-2 rounded-2xl border border-green-500/30 text-green-500 flex items-center gap-2 bg-green-500/5 shadow-[0_0_15px_rgba(34,197,94,0.1)]";
            badge.innerHTML = '<span class="w-2 h-2 bg-green-500 rounded-full animate-ping"></span> نظام التتبع نشط';
            statusText.innerText = "يتم الآن استقبال بيانات Encoder و GPS في الوقت الفعلي";
        } else {
            badge.className = "px-6 py-2 rounded-2xl border border-red-500/30 text-red-500 flex items-center gap-2 bg-red-500/5 pulse-red";
            badge.innerHTML = '<i class="fas fa-satellite-dish"></i> جاري البحث عن إشارة...';
            statusText.innerText = "انقطع الاتصال بالروبوت.. تأكد من اتصال الـ 4G/WiFi في الراسبري باي";
        }
    }

    // تحديث سريع جداً (كل ثانية) لضمان دقة السرعة
    setInterval(fetchLiveTracking, 1000);
    fetchLiveTracking();
</script>
@endsection
