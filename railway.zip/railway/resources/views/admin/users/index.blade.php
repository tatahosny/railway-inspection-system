@extends('layouts.app')
@section('title', 'إدارة المستخدمين')

@section('content')
<div class="flex justify-between items-center mb-10">
    <h1 class="text-3xl font-black italic">إدارة فريق العمل</h1>
    <button onclick="toggleModal()" class="bg-blue-600 px-8 py-3 rounded-2xl font-black text-xs uppercase tracking-widest"><i class="fas fa-plus ml-2"></i> إضافة مهندس</button>
</div>

<div class="glass rounded-[2.5rem] overflow-hidden">
    <table class="w-full text-right">
        <thead class="bg-white/5 text-[10px] text-slate-500 font-black uppercase tracking-widest">
            <tr>
                <th class="p-6">المهندس</th>
                <th class="p-6">البريد الإلكتروني</th>
                <th class="p-6">الصلاحية</th>
                <th class="p-6">الإجراءات</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-white/5">
            @foreach($users as $user)
            <tr class="hover:bg-white/[0.02]">
                <td class="p-6 font-bold">{{ $user->name }}</td>
                <td class="p-6 font-mono text-xs text-slate-400">{{ $user->email }}</td>
                <td class="p-6"><span class="px-3 py-1 bg-blue-500/10 text-blue-500 rounded-full text-[9px] font-black uppercase tracking-widest">{{ $user->role }}</span></td>
                <td class="p-6">
                    <form action="{{ route('admin.users.destroy', $user->id) }}" method="POST">
                        @csrf @method('DELETE')
                        <button class="text-red-500/50 hover:text-red-500 transition-all"><i class="fas fa-trash-alt"></i></button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
