@extends('layouts.app') {{-- افترضنا وجود Layout --}}

@section('content')
<div class="flex">
    {{-- السايد بار اللي فيه بيانات الأكونت (كوده في الأسفل) --}}
    @include('partials.sidebar')

    <main class="flex-1 mr-64 p-10 bg-[#05080f] min-h-screen">
        <div class="flex justify-between items-center mb-10">
            <div>
                <h1 class="text-3xl font-black italic text-white">إدارة فريق العمل</h1>
                <p class="text-slate-500 text-xs uppercase mt-1">إضافة وصلاحيات المهندسين المشغلين</p>
            </div>
            <button onclick="document.getElementById('userModal').classList.remove('hidden')" class="bg-blue-600 hover:bg-blue-700 px-8 py-3 rounded-2xl font-black text-xs shadow-lg shadow-blue-600/20 transition-all">
                <i class="fas fa-user-plus ml-2"></i> إضافة مهندس جديد
            </button>
        </div>

        <div class="glass rounded-[2.5rem] overflow-hidden border border-white/5">
            <table class="w-full text-right border-collapse">
                <thead class="bg-white/5 text-slate-500 text-[10px] uppercase font-black tracking-widest">
                    <tr>
                        <th class="p-6">المهندس</th>
                        <th class="p-6">البريد الإلكتروني</th>
                        <th class="p-6">تاريخ الانضمام</th>
                        <th class="p-6 text-center">الإجراءات</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-white/5">
                    @foreach($users as $user)
                    <tr class="hover:bg-white/[0.02] transition-colors">
                        <td class="p-6 flex items-center gap-3">
                            <div class="w-10 h-10 bg-blue-600/20 rounded-full flex items-center justify-center text-blue-500 font-bold">
                                {{ substr($user->name, 0, 1) }}
                            </div>
                            <span class="font-bold text-white">{{ $user->name }}</span>
                        </td>
                        <td class="p-6 text-slate-400 text-sm font-mono">{{ $user->email }}</td>
                        <td class="p-6 text-slate-500 text-xs">{{ $user->created_at->format('Y/m/d') }}</td>
                        <td class="p-6 text-center">
                            <form action="{{ route('admin.users.destroy', $user->id) }}" method="POST">
                                @csrf @method('DELETE')
                                <button class="text-red-500/50 hover:text-red-500 transition-all text-sm">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </main>
</div>

{{-- مودال إضافة مستخدم --}}
<div id="userModal" class="fixed inset-0 bg-black/80 backdrop-blur-sm hidden z-[100] flex items-center justify-center p-4">
    <div class="glass max-w-md w-full p-10 rounded-[3rem] border border-white/10">
        <h2 class="text-2xl font-black mb-6">تسجيل مهندس جديد</h2>
        <form action="{{ route('admin.users.store') }}" method="POST" class="space-y-4">
            @csrf
            <input type="text" name="name" placeholder="الاسم بالكامل" class="w-full bg-white/5 border border-white/10 p-4 rounded-2xl outline-none focus:border-blue-500 text-white" required>
            <input type="email" name="email" placeholder="البريد الإلكتروني" class="w-full bg-white/5 border border-white/10 p-4 rounded-2xl outline-none focus:border-blue-500 text-white" required>
            <input type="password" name="password" placeholder="كلمة المرور" class="w-full bg-white/5 border border-white/10 p-4 rounded-2xl outline-none focus:border-blue-500 text-white" required>
            <div class="flex gap-4 mt-6">
                <button type="submit" class="flex-1 bg-blue-600 py-4 rounded-2xl font-black text-sm">حفظ الحساب</button>
                <button type="button" onclick="document.getElementById('userModal').classList.add('hidden')" class="flex-1 bg-white/5 py-4 rounded-2xl font-bold text-sm text-slate-400">إلغاء</button>
            </div>
        </form>
    </div>
</div>
@endsection
