@extends('layouts.app')

@section('title', 'User Details: ' . $user->name)

@section('content')
<div class="container-fluid py-4">
    <div class="row">
        <!-- User Information -->
        <div class="col-lg-4 mb-4">
            <div class="card dashboard-card">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0">
                        <i class="fas fa-user-circle me-2"></i>User Information
                    </h5>
                </div>
                <div class="card-body text-center">
                    <div class="avatar-circle-lg bg-primary text-white rounded-circle mx-auto mb-3">
                        {{ strtoupper(substr($user->name, 0, 1)) }}
                    </div>
                    <h4 class="fw-bold">{{ $user->name }}</h4>
                    <p class="text-muted">{{ $user->email }}</p>
                    
                    <div class="row text-start mt-4">
                        <div class="col-12 mb-2">
                            <strong>Role:</strong>
                            <span class="badge 
                                @if($user->role == 'admin') bg-danger
                                @elseif($user->role == 'inspector') bg-warning
                                @else bg-info @endif float-end">
                                {{ ucfirst($user->role) }}
                            </span>
                        </div>
                        <div class="col-12 mb-2">
                            <strong>Department:</strong>
                            <span class="float-end">{{ $user->department }}</span>
                        </div>
                        <div class="col-12 mb-2">
                            <strong>Phone:</strong>
                            <span class="float-end">{{ $user->phone ?: 'Not provided' }}</span>
                        </div>
                        <div class="col-12 mb-2">
                            <strong>Device ID:</strong>
                            <span class="float-end">
                                @if($user->device_id)
                                    <code>{{ $user->device_id }}</code>
                                @else
                                    <span class="text-muted">Not assigned</span>
                                @endif
                            </span>
                        </div>
                        <div class="col-12 mb-2">
                            <strong>Status:</strong>
                            <span class="badge {{ $user->is_active ? 'bg-success' : 'bg-secondary' }} float-end">
                                {{ $user->is_active ? 'Active' : 'Inactive' }}
                            </span>
                        </div>
                        <div class="col-12 mb-2">
                            <strong>Last Login:</strong>
                            <span class="float-end">
                                @if($user->last_login_at)
                                    {{ $user->last_login_at->diffForHumans() }}
                                @else
                                    <span class="text-muted">Never</span>
                                @endif
                            </span>
                        </div>
                        <div class="col-12">
                            <strong>Member Since:</strong>
                            <span class="float-end">{{ $user->created_at->format('M d, Y') }}</span>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <div class="d-grid gap-2">
                        <a href="{{ route('admin.users.edit', $user->id) }}" class="btn btn-warning">
                            <i class="fas fa-edit me-2"></i>Edit User
                        </a>
                        @if($user->id !== auth()->id())
                        <form action="{{ route('admin.users.toggle-status', $user->id) }}" method="POST">
                            @csrf
                            <button type="submit" class="btn w-100 
                                {{ $user->is_active ? 'btn-outline-warning' : 'btn-outline-success' }}">
                                <i class="fas {{ $user->is_active ? 'fa-user-slash' : 'fa-user-check' }} me-2"></i>
                                {{ $user->is_active ? 'Deactivate' : 'Activate' }}
                            </button>
                        </form>
                        @endif
                    </div>
                </div>
            </div>
        </div>

        <!-- User Statistics -->
        <div class="col-lg-8">
            <div class="row mb-4">
                <div class="col-md-4 mb-3">
                    <div class="card dashboard-card border-left-primary">
                        <div class="card-body text-center">
                            <div class="h2 fw-bold text-primary">{{ $userStats['sensor_data_count'] }}</div>
                            <div class="text-muted">Sensor Data Records</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card dashboard-card border-left-success">
                        <div class="card-body text-center">
                            <div class="h2 fw-bold text-success">{{ $userStats['defects_detected'] }}</div>
                            <div class="text-muted">Defects Detected</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card dashboard-card border-left-warning">
                        <div class="card-body text-center">
                            <div class="h2 fw-bold text-warning">{{ $userStats['assigned_defects'] }}</div>
                            <div class="text-muted">Assigned Defects</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Activity -->
            <div class="card dashboard-card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">
                        <i class="fas fa-history me-2"></i>Recent Activity
                    </h5>
                </div>
                <div class="card-body">
                    @if($userStats['recent_activity']->count() > 0)
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Sensor Type</th>
                                    <th>Value</th>
                                    <th>Location</th>
                                    <th>Defect</th>
                                    <th>Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($userStats['recent_activity'] as $activity)
                                <tr>
                                    <td>
                                        <span class="badge bg-info text-capitalize">
                                            {{ $activity->sensor_type }}
                                        </span>
                                    </td>
                                    <td>{{ $activity->value }} {{ $activity->unit }}</td>
                                    <td>{{ $activity->location }}</td>
                                    <td>
                                        @if($activity->defect_detected)
                                        <span class="badge bg-danger">Defect</span>
                                        @else
                                        <span class="badge bg-success">Normal</span>
                                        @endif
                                    </td>
                                    <td>{{ $activity->created_at->diffForHumans() }}</td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    @else
                    <div class="text-center py-4">
                        <i class="fas fa-chart-line fa-3x text-muted mb-3"></i>
                        <p class="text-muted">No recent activity found for this user.</p>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <!-- Back Button -->
    <div class="row mt-4">
        <div class="col-12">
            <a href="{{ route('admin.users.index') }}" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-2"></i>Back to Users List
            </a>
        </div>
    </div>
</div>

<style>
.avatar-circle-lg {
    width: 80px;
    height: 80px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    font-size: 2rem;
}
</style>
@endsection