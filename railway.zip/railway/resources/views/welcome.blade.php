<!DOCTYPE html>
<html>
<head>
    <title>مشروع Laravel + Vue</title>
    @vite('resources/css/app.css')
</head>
<body>
    <div id="app">
        <h1>مرحباً من Laravel 👋</h1>
        {{-- هنا هيفضهر المكون بتاع Vue --}}
        <welcome-message></welcome-message>
    </div>

    @vite('resources/js/app.js')
</body>
</html>
    