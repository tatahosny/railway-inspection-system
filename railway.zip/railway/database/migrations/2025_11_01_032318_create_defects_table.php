<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('defects', function (Blueprint $table) {
    $table->id();
    $table->foreignId('user_id')->constrained(); // المهندس أو المشغل المرتبط بالجهاز
    $table->string('location_lat');
    $table->string('location_lng');
    $table->enum('danger_level', ['low', 'medium', 'high', 'critical']);
    $table->text('gemini_analysis'); // تحليل جيمناي الكامل
    $table->string('image_1_url');
    $table->string('image_2_url');
    $table->float('ultrasonic_1');
    $table->float('ultrasonic_2');
    $table->json('mpu_data'); // بيانات الحركة
    $table->timestamp('detected_at');
    $table->timestamps();
});
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('defects');
    }
};
