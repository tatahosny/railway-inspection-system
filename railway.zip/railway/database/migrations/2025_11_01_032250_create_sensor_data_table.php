<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('sensor_data', function (Blueprint $table) {
            $table->id();
            $table->string('sensor_id');
            $table->enum('sensor_type', ['vibration', 'pressure', 'temperature', 'deformation']);
            $table->decimal('value', 10, 4);
            $table->string('unit');
            $table->string('location');
            $table->decimal('latitude', 10, 6)->nullable();
            $table->decimal('longitude', 10, 6)->nullable();
            $table->enum('status', ['active', 'inactive'])->default('active');
            $table->string('image_path')->nullable();
            $table->boolean('defect_detected')->default(false);
            $table->string('defect_type')->nullable();
            $table->enum('severity', ['low', 'medium', 'high'])->nullable();
            $table->timestamp('timestamp');
            $table->foreignId('user_id')->nullable()->constrained()->onDelete('set null');
            $table->timestamps();

            $table->index(['sensor_type', 'timestamp']);
            $table->index(['defect_detected', 'severity']);
        });
    }

    public function down()
    {
        Schema::dropIfExists('sensor_data');
    }
};