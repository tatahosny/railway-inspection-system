<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
   public function up()
{
    Schema::table('sensor_data', function (Blueprint $table) {
        // إزالة الأعمدة القديمة
        $table->dropColumn(['sensor_id', 'sensor_type', 'value', 'unit']);
        
        // إضافة الأعمدة الجديدة
        $table->string('device_id')->after('id');
        $table->decimal('vibration_value', 10, 4)->after('device_id');
        $table->decimal('pressure_value', 10, 4)->after('vibration_value');
        $table->decimal('temperature_value', 10, 4)->after('pressure_value');
        $table->decimal('deformation_value', 10, 4)->after('temperature_value');
        $table->string('vibration_unit', 10)->after('deformation_value');
        $table->string('pressure_unit', 10)->after('vibration_unit');
        $table->string('temperature_unit', 10)->after('pressure_unit');
        $table->string('deformation_unit', 10)->after('temperature_unit');
        $table->decimal('risk_percentage', 5, 2)->nullable()->after('defect_type');
    });
}
};
