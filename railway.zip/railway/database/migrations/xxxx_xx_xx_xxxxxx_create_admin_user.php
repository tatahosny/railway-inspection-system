<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\User;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // إنشاء المستخدم الأدمن
        User::create([
            'name' => 'System Administrator',
            'email' => 'admin@railway.com',
            'password' => 'admin123',
            'role' => 'admin',
            'department' => 'Administration',
            'phone' => '+201000000000',
            'is_active' => true,
            'email_verified_at' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        User::where('email', 'admin@railway.com')->delete();
    }
};