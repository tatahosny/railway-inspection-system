<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {

    public function up(): void {

        /*
        |--------------------------------------------------------------------------
        | 1. Sensor Data Table
        |--------------------------------------------------------------------------
        */
        Schema::create('sensor_data', function (Blueprint $table) {
            $table->id();

            $table->string('device_id')->index();

            $table->decimal('vibration_value', 10, 4);
            $table->decimal('pressure_value', 10, 4);
            $table->decimal('temperature_value', 10, 4);

            $table->decimal('risk_percentage', 5, 2)->nullable();

            // GPS
            $table->decimal('latitude', 10, 8)->nullable();
            $table->decimal('longitude', 11, 8)->nullable();
            $table->string('location_name')->nullable();

            $table->timestamps();
        });


        /*
        |--------------------------------------------------------------------------
        | 2. Defects Table
        |--------------------------------------------------------------------------
        */
        Schema::create('defects', function (Blueprint $table) {
            $table->id();

            $table->decimal('location_lat', 10, 8);
            $table->decimal('location_lng', 11, 8);

            // بدل enum → string (عشان التوافق)
            $table->string('danger_level')->default('low');

            $table->text('gemini_analysis');

            $table->string('image_path')->nullable();

            $table->float('ultrasonic_distance')->nullable();

            $table->timestamp('detected_at')->useCurrent();

            $table->timestamps();
        });


        /*
        |--------------------------------------------------------------------------
        | 3. Robot Controls Table
        |--------------------------------------------------------------------------
        */
        Schema::create('robot_controls', function (Blueprint $table) {
            $table->id();

            $table->float('distance_to_move')->default(0);

            // بدل enum → string
            $table->string('command')->default('stop');

            $table->boolean('is_executed')->default(false);

            $table->timestamp('executed_at')->nullable();

            $table->timestamps();
        });
    }


    public function down(): void {
        Schema::dropIfExists('robot_controls');
        Schema::dropIfExists('defects');
        Schema::dropIfExists('sensor_data');
    }
};
