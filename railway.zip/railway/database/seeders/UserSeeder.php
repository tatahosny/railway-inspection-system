<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // 1. إنشاء حساب المشغل (Operator) المسؤول عن الروبوت
        User::create([
            'name' => 'مصطفى حسني',
            'email' => 'op1@railguard.com',
            'password' => 'password123', // سيتم تشفيره تلقائياً بواسطة الـ Setter في الموديل أو نستخدم Hash::make
            'role' => 'operator',
            'phone' => '01012345678',
            'department' => 'قسم صيانة السكك الحديدية',
            'device_id' => 'RG-ROBOT-01', // كود الروبوت المرتبط بهذا المستخدم
            'is_active' => true,
            'last_login_at' => now(),
        ]);

        // 2. إنشاء حساب المدير (Admin) للتحكم الكامل (اختياري)
        User::create([
            'name' => 'مدير النظام',
            'email' => 'admin@railguard.com',
            'password' => 'admin123',
            'role' => 'admin',
            'phone' => '01198765432',
            'department' => 'الإدارة التقنية',
            'device_id' => null,
            'is_active' => true,
        ]);

        // 3. إنشاء حساب فحص (Inspector) للمراجعة الميدانية
        User::create([
            'name' => 'مهندس فحص ميداني',
            'email' => 'inspector@railguard.com',
            'password' => 'ins123',
            'role' => 'inspector',
            'phone' => '01234567890',
            'department' => 'المعاينة الفنية',
            'device_id' => null,
            'is_active' => true,
        ]);
    }
}
