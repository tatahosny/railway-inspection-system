<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminUserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        User::create([
            'name' => 'System Administrator',
            'email' => 'admin@railway.com',
            'password' => 'admin123', // سيتم تشفيرها تلقائياً
            'role' => 'admin',
            'department' => 'Administration',
            'phone' => '+201000000000',
            'is_active' => true,
            'email_verified_at' => now(),
        ]);

        $this->command->info('Admin user created successfully!');
        $this->command->info('Email: admin@railway.com');
        $this->command->info('Password: admin123');
    }
}