

<?php $__env->startSection('title', 'User Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <!-- Header -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <h1 class="h2 fw-bold">
                    <i class="fas fa-users me-2"></i>User Management
                </h1>
                <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i>Add New User
                </a>
            </div>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-xl-2 col-md-4 mb-3">
            <div class="card dashboard-card border-left-primary">
                <div class="card-body">
                    <div class="text-center">
                        <div class="h3 fw-bold text-primary"><?php echo e($stats['total']); ?></div>
                        <div class="text-muted">Total Users</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-md-4 mb-3">
            <div class="card dashboard-card border-left-success">
                <div class="card-body">
                    <div class="text-center">
                        <div class="h3 fw-bold text-success"><?php echo e($stats['admins']); ?></div>
                        <div class="text-muted">Admins</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-md-4 mb-3">
            <div class="card dashboard-card border-left-info">
                <div class="card-body">
                    <div class="text-center">
                        <div class="h3 fw-bold text-info"><?php echo e($stats['inspectors']); ?></div>
                        <div class="text-muted">Inspectors</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-md-4 mb-3">
            <div class="card dashboard-card border-left-warning">
                <div class="card-body">
                    <div class="text-center">
                        <div class="h3 fw-bold text-warning"><?php echo e($stats['operators']); ?></div>
                        <div class="text-muted">Operators</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-md-4 mb-3">
            <div class="card dashboard-card border-left-success">
                <div class="card-body">
                    <div class="text-center">
                        <div class="h3 fw-bold text-success"><?php echo e($stats['active']); ?></div>
                        <div class="text-muted">Active</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-md-4 mb-3">
            <div class="card dashboard-card border-left-danger">
                <div class="card-body">
                    <div class="text-center">
                        <div class="h3 fw-bold text-danger"><?php echo e($stats['inactive']); ?></div>
                        <div class="text-muted">Inactive</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Filters -->
    <div class="card dashboard-card mb-4">
        <div class="card-body">
            <form action="<?php echo e(route('admin.users.index')); ?>" method="GET">
                <div class="row g-3">
                    <div class="col-md-4">
                        <input type="text" name="search" class="form-control" 
                               placeholder="Search by name, email, or department..."
                               value="<?php echo e(request('search')); ?>">
                    </div>
                    <div class="col-md-2">
                        <select name="role" class="form-select">
                            <option value="all">All Roles</option>
                            <option value="admin" <?php echo e(request('role') == 'admin' ? 'selected' : ''); ?>>Admin</option>
                            <option value="inspector" <?php echo e(request('role') == 'inspector' ? 'selected' : ''); ?>>Inspector</option>
                            <option value="operator" <?php echo e(request('role') == 'operator' ? 'selected' : ''); ?>>Operator</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <select name="status" class="form-select">
                            <option value="all">All Status</option>
                            <option value="active" <?php echo e(request('status') == 'active' ? 'selected' : ''); ?>>Active</option>
                            <option value="inactive" <?php echo e(request('status') == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-filter me-2"></i>Filter
                        </button>
                    </div>
                    <div class="col-md-2">
                        <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-outline-secondary w-100">
                            <i class="fas fa-redo me-2"></i>Reset
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Users Table -->
    <div class="card dashboard-card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Role</th>
                            <th>Department</th>
                            <th>Device ID</th>
                            <th>Status</th>
                            <th>Last Login</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="avatar-circle bg-primary text-white rounded-circle me-3">
                                        <?php echo e(strtoupper(substr($user->name, 0, 1))); ?>

                                    </div>
                                    <div>
                                        <div class="fw-bold"><?php echo e($user->name); ?></div>
                                        <div class="text-muted small"><?php echo e($user->email); ?></div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <span class="badge 
                                    <?php if($user->role == 'admin'): ?> bg-danger
                                    <?php elseif($user->role == 'inspector'): ?> bg-warning
                                    <?php else: ?> bg-info <?php endif; ?>">
                                    <?php echo e(ucfirst($user->role)); ?>

                                </span>
                            </td>
                            <td><?php echo e($user->department); ?></td>
                            <td>
                                <?php if($user->device_id): ?>
                                    <code><?php echo e($user->device_id); ?></code>
                                <?php else: ?>
                                    <span class="text-muted">Not assigned</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge <?php echo e($user->is_active ? 'bg-success' : 'bg-secondary'); ?>">
                                    <?php echo e($user->is_active ? 'Active' : 'Inactive'); ?>

                                </span>
                            </td>
                            <td>
                                <?php if($user->last_login_at): ?>
                                    <span class="text-muted small"><?php echo e($user->last_login_at->diffForHumans()); ?></span>
                                <?php else: ?>
                                    <span class="text-muted small">Never</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="btn-group">
                                    <a href="<?php echo e(route('admin.users.show', $user->id)); ?>" 
                                       class="btn btn-sm btn-outline-primary" title="View">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" 
                                       class="btn btn-sm btn-outline-warning" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form action="<?php echo e(route('admin.users.toggle-status', $user->id)); ?>" 
                                          method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm 
                                            <?php echo e($user->is_active ? 'btn-outline-warning' : 'btn-outline-success'); ?>"
                                            title="<?php echo e($user->is_active ? 'Deactivate' : 'Activate'); ?>">
                                            <i class="fas <?php echo e($user->is_active ? 'fa-user-slash' : 'fa-user-check'); ?>"></i>
                                        </button>
                                    </form>
                                    <?php if($user->id !== auth()->id()): ?>
                                    <form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" 
                                          method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger" 
                                                title="Delete" onclick="return confirm('Are you sure?')">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center py-4">
                                <i class="fas fa-users fa-3x text-muted mb-3"></i>
                                <p class="text-muted">No users found.</p>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="d-flex justify-content-between align-items-center mt-3">
                <div class="text-muted">
                    Showing <?php echo e($users->firstItem()); ?> to <?php echo e($users->lastItem()); ?> of <?php echo e($users->total()); ?> users
                </div>
                <?php echo e($users->links()); ?>

            </div>
        </div>
    </div>
</div>

<style>
.avatar-circle {
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
}
.btn-group .btn {
    margin-right: 5px;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\trean\railway-inspection-system\resources\views/admin/users/index.blade.php ENDPATH**/ ?>