<footer class="footer mt-5">
    <div class="container">
        <div class="row py-5">
            <!-- Company Info -->
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="footer-brand mb-3">
                    <i class="fas fa-train fa-2x text-white me-2"></i>
                    <span class="h4 fw-bold text-white">Railway Inspection</span>
                </div>
                <p class="text-light mb-4">
                    Advanced railway inspection system using AI technology and smart sensors 
                    to ensure railway safety and prevent accidents through real-time monitoring.
                </p>
                <div class="social-links">
                    <a href="#" class="social-icon">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a href="#" class="social-icon">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a href="#" class="social-icon">
                        <i class="fab fa-linkedin-in"></i>
                    </a>
                    <a href="#" class="social-icon">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a href="#" class="social-icon">
                        <i class="fab fa-youtube"></i>
                    </a>
                </div>
            </div>

            <!-- Quick Links -->
            <div class="col-lg-2 col-md-6 mb-4">
                <h5 class="text-white fw-bold mb-3">Quick Links</h5>
                <ul class="list-unstyled">
                    <li class="mb-2">
                        <a href="<?php echo e(route('home')); ?>" class="text-light text-decoration-none footer-link">
                            <i class="fas fa-chevron-right me-2 small"></i>Home
                        </a>
                    </li>
                    <li class="mb-2">
                        <a href="<?php echo e(route('about')); ?>" class="text-light text-decoration-none footer-link">
                            <i class="fas fa-chevron-right me-2 small"></i>About
                        </a>
                    </li>
                    <li class="mb-2">
                        <a href="<?php echo e(route('services')); ?>" class="text-light text-decoration-none footer-link">
                            <i class="fas fa-chevron-right me-2 small"></i>Services
                        </a>
                    </li>
                    <li class="mb-2">
                        <a href="<?php echo e(route('contact')); ?>" class="text-light text-decoration-none footer-link">
                            <i class="fas fa-chevron-right me-2 small"></i>Contact
                        </a>
                    </li>
                    <li class="mb-2">
                        <a href="<?php echo e(route('dashboard')); ?>" class="text-light text-decoration-none footer-link">
                            <i class="fas fa-chevron-right me-2 small"></i>Dashboard
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Services -->
            <div class="col-lg-3 col-md-6 mb-4">
                <h5 class="text-white fw-bold mb-3">Our Services</h5>
                <ul class="list-unstyled">
                    <li class="mb-2">
                        <a href="#" class="text-light text-decoration-none footer-link">
                            <i class="fas fa-cog me-2 small"></i>Rail Inspection
                        </a>
                    </li>
                    <li class="mb-2">
                        <a href="#" class="text-light text-decoration-none footer-link">
                            <i class="fas fa-cog me-2 small"></i>Visual Inspection
                        </a>
                    </li>
                    <li class="mb-2">
                        <a href="#" class="text-light text-decoration-none footer-link">
                            <i class="fas fa-cog me-2 small"></i>Data Analytics
                        </a>
                    </li>
                    <li class="mb-2">
                        <a href="#" class="text-light text-decoration-none footer-link">
                            <i class="fas fa-cog me-2 small"></i>Alert System
                        </a>
                    </li>
                    <li class="mb-2">
                        <a href="#" class="text-light text-decoration-none footer-link">
                            <i class="fas fa-cog me-2 small"></i>Maintenance
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Contact Info -->
            <div class="col-lg-3 col-md-6 mb-4">
                <h5 class="text-white fw-bold mb-3">Contact Info</h5>
                <div class="contact-info">
                    <div class="d-flex align-items-start mb-3">
                        <div class="footer-icon me-3">
                            <i class="fas fa-map-marker-alt text-primary"></i>
                        </div>
                        <div>
                            <span class="text-light">123 Railway Street</span><br>
                            <span class="text-light">Industrial Area, Cairo, Egypt</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-start mb-3">
                        <div class="footer-icon me-3">
                            <i class="fas fa-phone text-primary"></i>
                        </div>
                        <div>
                            <span class="text-light">+20 100 000 0000</span><br>
                            <span class="text-light">+20 122 000 0000</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-start mb-3">
                        <div class="footer-icon me-3">
                            <i class="fas fa-envelope text-primary"></i>
                        </div>
                        <div>
                            <span class="text-light">info@railway-system.com</span><br>
                            <span class="text-light">support@railway-system.com</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-start">
                        <div class="footer-icon me-3">
                            <i class="fas fa-clock text-primary"></i>
                        </div>
                        <div>
                            <span class="text-light">24/7 Support Available</span><br>
                            <span class="text-light">Emergency Response Team</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Newsletter Section -->
        <div class="row py-4 border-top border-light">
            <div class="col-lg-6 mb-3">
                <h6 class="text-white fw-bold mb-2">Subscribe to Our Newsletter</h6>
                <p class="text-light mb-3">Get the latest updates on railway safety technology and industry insights.</p>
            </div>
            <div class="col-lg-6 mb-3">
                <div class="input-group">
                    <input type="email" class="form-control" placeholder="Enter your email address">
                    <button class="btn btn-primary" type="button">
                        <i class="fas fa-paper-plane me-2"></i>Subscribe
                    </button>
                </div>
            </div>
        </div>

        <!-- Bottom Bar -->
        <div class="row py-3 border-top border-light">
            <div class="col-md-6 text-center text-md-start">
                <p class="text-light mb-0">
                    &copy; 2024 Railway Inspection System. All rights reserved.
                </p>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <div class="footer-links">
                    <a href="#" class="text-light text-decoration-none me-3">Privacy Policy</a>
                    <a href="#" class="text-light text-decoration-none me-3">Terms of Service</a>
                    <a href="#" class="text-light text-decoration-none">Cookie Policy</a>
                </div>
            </div>
        </div>
    </div>
</footer>

<style>
.footer {
    background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
    position: relative;
    overflow: hidden;
}

.footer::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 3px;
    background: var(--gradient-primary);
}

.footer-brand {
    display: flex;
    align-items: center;
}

.social-links {
    display: flex;
    gap: 10px;
}

.social-icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.1);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    color: white;
    text-decoration: none;
    transition: all 0.3s ease;
    border: 1px solid rgba(255, 255, 255, 0.2);
}

.social-icon:hover {
    background: var(--primary-color);
    transform: translateY(-3px);
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
}

.footer-link {
    transition: all 0.3s ease;
    padding: 5px 0;
    display: block;
}

.footer-link:hover {
    color: var(--secondary-color) !important;
    transform: translateX(5px);
}

.footer-icon {
    width: 20px;
    text-align: center;
    margin-top: 2px;
}

.contact-info .footer-icon {
    width: 20px;
    flex-shrink: 0;
}

.newsletter-input {
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.3);
    color: white;
}

.newsletter-input::placeholder {
    color: rgba(255, 255, 255, 0.7);
}

.newsletter-input:focus {
    background: rgba(255, 255, 255, 0.15);
    border-color: var(--primary-color);
    color: white;
    box-shadow: 0 0 0 0.2rem rgba(52, 152, 219, 0.25);
}

.footer-links a {
    transition: all 0.3s ease;
}

.footer-links a:hover {
    color: var(--secondary-color) !important;
}

/* Responsive Design */
@media (max-width: 768px) {
    .footer-brand {
        justify-content: center;
        text-align: center;
    }
    
    .social-links {
        justify-content: center;
    }
    
    .contact-info {
        text-align: center;
    }
    
    .contact-info .d-flex {
        justify-content: center;
    }
}
</style><?php /**PATH D:\trean\railway-inspection-system\resources\views/partials/footer.blade.php ENDPATH**/ ?>