<?php $__env->startSection('title', 'لوحة التحكم الرئيسية'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        // مصفوفة ترجمة مستويات الخطر للألوان والنصوص
        $dangerMap = [
            'low'      => ['text' => 'منخفض', 'class' => 'bg-green-500/20 text-green-500'],
            'medium'   => ['text' => 'متوسط', 'class' => 'bg-yellow-500/20 text-yellow-500'],
            'high'     => ['text' => 'مرتفع', 'class' => 'bg-orange-500/20 text-orange-500'],
            'critical' => ['text' => 'حرج جداً', 'class' => 'bg-red-600 text-white shadow-[0_0_15px_rgba(220,38,38,0.4)]'],
        ];
    ?>

    <div class="flex justify-between items-start mb-10">
        <div>
            <h1 class="text-3xl font-black italic">نظام مراقبة السكك الحديدية</h1>
            <p class="text-slate-500 mt-1 uppercase tracking-tighter text-[10px]">Real-time Telemetry & Control System</p>
        </div>

        <?php if($isOnline): ?>
            <div class="glass px-6 py-3 rounded-2xl border-green-500/30 text-green-500 flex items-center gap-3 shadow-[0_0_20px_rgba(34,197,94,0.1)]">
                <span class="w-2 h-2 bg-green-500 rounded-full animate-ping"></span> الجهاز متصل الآن
            </div>
        <?php else: ?>
            <div class="glass px-6 py-3 rounded-2xl border-red-500/30 text-red-500 flex items-center gap-3 shadow-[0_0_20px_rgba(239,68,68,0.2)]">
                <i class="fas fa-circle-exclamation animate-pulse"></i> الجهاز معطل عن العمل
            </div>
        <?php endif; ?>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-10">
        <div class="glass p-8 rounded-[2.5rem] border border-blue-500/10">
            <h3 class="text-xl font-bold mb-6 text-blue-400"><i class="fas fa-gamepad ml-2 text-sm"></i> التحكم اليدوي</h3>
            <form action="<?php echo e(route('robot.move')); ?>" method="POST" class="space-y-6">
                <?php echo csrf_field(); ?>
                <div>
                    <label class="text-[10px] text-slate-500 block mb-2 font-black uppercase">المسافة المطلوب تحركها (متر)</label>
                    <input type="number" name="distance" step="0.1" required
                           class="w-full bg-white/5 border border-white/10 p-4 rounded-2xl outline-none focus:border-blue-500 transition-all font-mono text-center text-xl text-blue-400"
                           placeholder="0.0">
                </div>
                <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 py-4 rounded-2xl font-black shadow-lg shadow-blue-600/30 transition-all uppercase tracking-widest text-[11px] flex items-center justify-center gap-2">
                    <i class="fas fa-paper-plane"></i> إرسال الأمر للعربية
                </button>
            </form>
        </div>

        <div class="lg:col-span-2 glass rounded-[2.5rem] overflow-hidden relative min-h-[400px] border border-white/5 shadow-2xl">
            <?php
                $lastDefect = $history->first();
                $lat = $isOnline ? ($stats['current_lat'] ?? $stats['lat'] ?? 0.0) : ($lastDefect->location_lat ?? 0.0);
                $lng = $isOnline ? ($stats['current_lng'] ?? $stats['lng'] ?? 0.0) : ($lastDefect->location_lng ?? 0.0);
            ?>

            <iframe width="100%" height="100%" frameborder="0" style="border:0; filter: invert(90%) hue-rotate(180deg);"
                src="https://maps.google.com/maps?q=<?php echo e($lat); ?>,<?php echo e($lng); ?>&z=17&output=embed">
            </iframe>

            <?php if($lastDefect): ?>
                <div class="absolute top-4 left-4 z-10 w-52 glass rounded-3xl p-3 border border-red-500/20 shadow-2xl backdrop-blur-xl">
                    <p class="text-[8px] text-red-500 mb-2 font-black uppercase tracking-widest flex items-center gap-2">
                        <span class="w-1.5 h-1.5 bg-red-500 rounded-full"></span> آخر عطل تم رصده
                    </p>
                    <img src="<?php echo e(asset($lastDefect->image_1_url)); ?>" class="w-full h-28 object-cover rounded-2xl border border-white/10 mb-2">
                    <p class="text-[9px] text-slate-300 line-clamp-2 leading-relaxed italic">"<?php echo e($lastDefect->gemini_analysis); ?>"</p>
                </div>
            <?php endif; ?>

            <div class="absolute bottom-4 right-4 glass px-4 py-2 rounded-xl text-[10px] text-blue-400 font-mono border border-blue-500/20">
                <?php echo e($lat); ?>, <?php echo e($lng); ?>

            </div>
        </div>
    </div>

    <div class="glass rounded-[2.5rem] p-10 overflow-hidden border border-white/5">
        <div class="flex justify-between items-center mb-8">
            <h3 class="text-2xl font-black italic">سجل العوارض المكتشفة</h3>
            <span class="text-[10px] text-slate-500 font-mono px-3 py-1 bg-white/5 rounded-full border border-white/5">
                إجمالي السجلات: <?php echo e($history->total()); ?>

            </span>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-right border-collapse">
                <thead>
                    <tr class="text-slate-500 text-[10px] uppercase border-b border-white/5 font-black tracking-widest">
                        <th class="pb-6">التوقيت</th>
                        <th class="pb-6">الموقع الجغرافي</th>
                        <th class="pb-6 text-center">مستوى الخطر</th>
                        <th class="pb-6 pr-10">تحليل Gemini Vision</th>
                        <th class="pb-6 text-left pl-6">الإجراء</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-white/5">
                    <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $defect): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-blue-600/[0.03] transition-colors group">
                        <td class="py-6 text-[11px] font-mono text-slate-400"><?php echo e($defect->detected_at->format('Y-m-d H:i')); ?></td>
                        <td class="py-6 text-xs text-blue-400/80 font-mono"><?php echo e($defect->location_lat); ?>, <?php echo e($defect->location_lng); ?></td>
                        <td class="py-6 text-center">
                            <?php
                                $level = $dangerMap[$defect->danger_level] ?? ['text' => $defect->danger_level, 'class' => ''];
                            ?>
                            <span class="px-4 py-1.5 rounded-full text-[10px] font-black tracking-widest inline-block min-w-[90px] <?php echo e($level['class']); ?>">
                                <?php echo e($level['text']); ?>

                            </span>
                        </td>
                        <td class="py-6 text-[11px] text-slate-300 leading-relaxed max-w-md pr-10 group-hover:text-white transition-colors">
                            <?php echo e($defect->gemini_analysis); ?>

                        </td>
                        <td class="py-6 text-left pl-6">
                            <button onclick="showDefectDetails(<?php echo e(json_encode($defect)); ?>)"
                                    class="bg-blue-600/20 hover:bg-blue-600 text-blue-400 hover:text-white px-4 py-2 rounded-xl text-[10px] font-black transition-all border border-blue-500/20">
                                التفاصيل <i class="fas fa-eye mr-1"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="mt-8"><?php echo e($history->links()); ?></div>
    </div>

    <div id="detailsModal" class="fixed inset-0 z-[100] hidden flex items-center justify-center p-4">
        <div class="absolute inset-0 bg-slate-950/90 backdrop-blur-md" onclick="closeModal()"></div>
        <div class="glass w-full max-w-4xl rounded-[3rem] border border-white/10 overflow-hidden relative z-10">
            <div class="p-8 md:p-12 text-right">
                <div class="flex justify-between items-start mb-8 flex-row-reverse">
                    <div>
                        <h2 class="text-3xl font-black italic text-white uppercase">تفاصيل العطل</h2>
                        <p id="modalDate" class="text-blue-400 font-mono text-[10px] mt-2 tracking-widest uppercase"></p>
                    </div>
                    <button onclick="closeModal()" class="w-10 h-10 flex items-center justify-center rounded-full bg-white/5 text-slate-500 hover:bg-red-500 hover:text-white transition-all">
                        <i class="fas fa-times"></i>
                    </button>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div class="grid grid-cols-1 gap-4">
                        <div>
                            <p class="text-[8px] text-slate-500 uppercase mb-2 font-black tracking-widest">الكاميرا الرئيسية</p>
                            <img id="modalImg1" src="" class="w-full h-44 object-cover rounded-3xl border border-white/10">
                        </div>
                        <div>
                            <p class="text-[8px] text-slate-500 uppercase mb-2 font-black tracking-widest">كاميرا الدعم</p>
                            <img id="modalImg2" src="" class="w-full h-44 object-cover rounded-3xl border border-white/10">
                        </div>
                    </div>

                    <div class="flex flex-col justify-between text-right">
                        <div class="glass p-6 rounded-[2rem] border-white/5 bg-white/[0.02]">
                            <p class="text-[9px] text-blue-400 uppercase mb-3 font-black tracking-widest">تقرير الذكاء الاصطناعي</p>
                            <p id="modalAnalysis" class="text-[13px] leading-relaxed text-slate-200 italic"></p>
                        </div>

                        <div class="grid grid-cols-2 gap-4 mt-6 mb-6">
                            <div class="bg-white/5 p-4 rounded-2xl border border-white/5 text-center">
                                <p class="text-[8px] text-slate-500 uppercase font-black mb-1">مستوى الخطر</p>
                                <p id="modalDanger" class="font-black text-sm"></p>
                            </div>
                            <div class="bg-white/5 p-4 rounded-2xl border border-white/5 text-center">
                                <p class="text-[8px] text-slate-500 uppercase font-black mb-1">الإحداثيات</p>
                                <p id="modalCoords" class="text-blue-400 text-[10px] font-mono"></p>
                            </div>
                        </div>

                        <a id="modalMapLink" target="_blank"
                           class="w-full bg-white text-black py-4 rounded-2xl font-black text-[11px] text-center uppercase tracking-widest hover:bg-blue-600 hover:text-white transition-all shadow-xl">
                            فتح الموقع في خرائط جوجل <i class="fas fa-map-marker-alt mr-2"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function showDefectDetails(defect) {
            const translations = {'low': 'منخفض', 'medium': 'متوسط', 'high': 'مرتفع', 'critical': 'حرج جداً'};

            document.getElementById('modalDate').innerText = 'توقيت الرصد: ' + defect.detected_at;
            document.getElementById('modalImg1').src = defect.image_1_url;
            document.getElementById('modalImg2').src = defect.image_2_url;
            document.getElementById('modalAnalysis').innerText = defect.gemini_analysis;
            document.getElementById('modalCoords').innerText = defect.location_lat + ', ' + defect.location_lng;
            document.getElementById('modalMapLink').href = `https://www.google.com/maps/search/?api=1&query=${defect.location_lat},${defect.location_lng}`;

            const dangerP = document.getElementById('modalDanger');
            dangerP.innerText = translations[defect.danger_level] || defect.danger_level;
            dangerP.className = 'font-black text-sm ' + (defect.danger_level === 'critical' ? 'text-red-500' : 'text-orange-400');

            document.getElementById('detailsModal').classList.remove('hidden');
        }

        function closeModal() {
            document.getElementById('detailsModal').classList.add('hidden');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\trean\railway-inspection-system\resources\views/dashboard.blade.php ENDPATH**/ ?>