<?php

namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as Middleware;

class VerifyCsrfToken extends Middleware
{
    /**
     * The URIs that should be excluded from CSRF verification.
     *
     * @var array<int, string>
     */
    protected $except = [
      'api/*',              // استثناء كل مسارات الـ API
        'api/robot/sync',     // استثناء مسار المزامنة تحديداً
        'robot/sync',         // احتياطاً لو بتنادي عليه بدون كلمة api
    ];
}
