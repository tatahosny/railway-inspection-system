<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Session;

class Localization
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        // التحقق إذا كانت اللغة مخزنة في الجلسة
        if (Session::has('locale')) {
            App::setLocale(Session::get('locale'));
        }
        
        // يمكنك أيضاً التحقق من لغة المتصفح إذا أردت
        // $browserLocale = substr($request->server('HTTP_ACCEPT_LANGUAGE'), 0, 2);
        // if (in_array($browserLocale, ['ar', 'en'])) {
        //     App::setLocale($browserLocale);
        // }
        
        return $next($request);
    }
}