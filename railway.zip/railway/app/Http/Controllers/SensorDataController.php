<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Defect;
use App\Models\SensorData;
use App\Models\RobotControl;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

class RobotDataController extends Controller
{
    /**
     * معالجة البيانات القادمة من Raspberry Pi وحقن أوامر التحكم
     */
    public function store(Request $request)
    {
        // 1. التحقق من البيانات المستلمة
        $request->validate([
            'device_id'    => 'required|string',
            'image_1'      => 'required|image|mimes:jpeg,png,jpg|max:4096',
            'image_2'      => 'nullable|image|mimes:jpeg,png,jpg|max:4096',
            'vibration'    => 'required|numeric',
            'pressure'     => 'required|numeric',
            'temp'         => 'required|numeric',
            'gps_lat'      => 'required|numeric',
            'gps_lng'      => 'required|numeric',
            'mpu_data'     => 'required|array',
        ]);

        try {
            // 2. حفظ قراءة الحساسات الدورية (Telemetry)
            // دي عشان الخريطة في الداش بورد تتحدث والـ Online/Offline يشتغل
            SensorData::create([
                'device_id'         => $request->device_id,
                'vibration_value'   => $request->vibration,
                'pressure_value'    => $request->pressure,
                'temperature_value' => $request->temp,
                'latitude'          => $request->gps_lat,
                'longitude'         => $request->gps_lng,
                'risk_percentage'   => 0, // هيتحدث بعد تحليل جيمناي
            ]);

            // 3. تجهيز الصور لتحليل Gemini
            $img1Base64 = base64_encode(file_get_contents($request->file('image_1')));
            $img2Base64 = $request->hasFile('image_2') ? base64_encode(file_get_contents($request->file('image_2'))) : null;

            // 4. استدعاء Gemini Flash 1.5
            $geminiRawResponse = $this->analyzeWithGemini($img1Base64, $img2Base64, $request->all());
            $analysis = json_decode($geminiRawResponse, true);

            // 5. إذا وجد عطل (High أو Critical) نقوم بتخزينه
            $alertCreated = false;
            if (isset($analysis['danger_level']) && in_array($analysis['danger_level'], ['high', 'critical'])) {

                $path1 = $request->file('image_1')->store('defects', 'public');

                Defect::create([
                    'location_lat'    => $request->gps_lat,
                    'location_lng'    => $request->gps_lng,
                    'danger_level'    => $analysis['danger_level'],
                    'gemini_analysis' => $analysis['technical_summary'],
                    'image_1_url'     => Storage::url($path1),
                    'ultrasonic_1'    => $request->ultrasonic ?? 0,
                    'mpu_data'        => json_encode($request->mpu_data),
                    'detected_at'     => Carbon::now(),
                ]);
                $alertCreated = true;
            }

            // 6. جلب أوامر التحكم (هنا بنشوف لو فيه أمر حركة "Move" لم ينفذ بعد)
            $pendingCommand = RobotControl::where('is_executed', false)
                                        ->orderBy('created_at', 'desc')
                                        ->first();

            $commandData = [
                'action'   => 'stay',
                'distance' => 0
            ];

            if ($pendingCommand) {
                $commandData = [
                    'action'   => $pendingCommand->command,
                    'distance' => $pendingCommand->distance_to_move
                ];
                // تحديث الحالة لـ "تم التنفيذ" بمجرد إرساله للراسبري
                $pendingCommand->update(['is_executed' => true]);
            }

            // 7. الرد النهائي للراسبري باي
            return response()->json([
                'status'         => 'success',
                'alert_status'   => $alertCreated ? 'danger_detected' : 'normal',
                'control_command' => $commandData, // الراسبري هيقرأ ده ويتحرك
                'server_time'    => now()->toDateTimeString()
            ], 200);

        } catch (\Exception $e) {
            Log::error("Robot Data Store Error: " . $e->getMessage());
            return response()->json(['status' => 'error', 'message' => 'Internal Server Error'], 500);
        }
    }

    /**
     * التواصل مع Google Gemini API
     */
    private function analyzeWithGemini($img1, $img2, $sensors)
    {
        $apiKey = config('services.gemini.key');
        $apiUrl = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" . $apiKey;

        $prompt = "As a railway engineer, analyze the track images.
                   Sensor Context: Vibration: {$sensors['vibration']}, Temp: {$sensors['temp']}°C.
                   Check for cracks, loose bolts, or obstacles.
                   Output ONLY valid JSON:
                   {
                     \"danger_level\": \"low|medium|high|critical\",
                     \"technical_summary\": \"شرح فني دقيق بالعربي عما تراه في الصور\"
                   }";

        $response = Http::post($apiUrl, [
            'contents' => [
                [
                    'parts' => [
                        ['text' => $prompt],
                        ['inline_data' => ['mime_type' => 'image/jpeg', 'data' => $img1]],
                    ]
                ]
            ],
            'generationConfig' => [
                'response_mime_type' => 'application/json',
            ]
        ]);

        if ($response->successful()) {
            return $response->json()['candidates'][0]['content']['parts'][0]['text'];
        }

        return json_encode(['danger_level' => 'low', 'technical_summary' => 'تحليل تلقائي: تعذر الاتصال بالذكاء الاصطناعي']);
    }
}
