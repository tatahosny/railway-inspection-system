<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Session;

class LanguageController extends Controller
{
    public function changeLanguage(Request $request)
    {
        $request->validate([
            'locale' => 'required|in:ar,en'
        ]);

        // حفظ اللغة في الجلسة
        Session::put('locale', $request->locale);
        
        // تعيين اللغة للتطبيق
        App::setLocale($request->locale);

        return response()->json([
            'success' => true,
            'message' => 'Language changed successfully',
            'locale' => $request->locale
        ]);
    }

    public function getCurrentLanguage()
    {
        return response()->json([
            'locale' => App::getLocale(),
            'available_locales' => config('app.available_locales')
        ]);
    }
}