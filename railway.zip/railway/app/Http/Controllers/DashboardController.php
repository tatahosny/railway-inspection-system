<?php

namespace App\Http\Controllers;

use App\Models\SensorData;
use App\Models\Defect;
use App\Models\RobotControl;
use Illuminate\Http\Request;

class DashboardController extends Controller {

    public function index() {
        // فحص حالة الاتصال (Online/Offline)
        // لو آخر قراءة للحساسات كانت من أقل من 60 ثانية يبقى الجهاز متصل
        $lastUpdate = SensorData::latest()->first();
        $isOnline = $lastUpdate && $lastUpdate->created_at >= now()->subSeconds(60);

        // تجميع الإحصائيات
        $stats = [
            'status_text' => $isOnline ? 'نشط ومتصل' : 'الجهاز معطل عن العمل',
            'defects_count' => Defect::count(),
            'critical_count' => Defect::where('danger_level', 'critical')->count(),
            'current_lat' => $isOnline ? $lastUpdate->latitude : 30.0444,
            'current_lng' => $isOnline ? $lastUpdate->longitude : 31.2357,
        ];

        $latestDefect = Defect::latest('detected_at')->first();
        $history = Defect::latest('detected_at')->paginate(10);

        return view('dashboard', compact('stats', 'isOnline', 'latestDefect', 'history'));
    }

    // دالة إرسال أمر الحركة من الداش بورد
    public function sendCommand(Request $request) {
        $request->validate(['distance' => 'required|numeric|min:0']);

        RobotControl::create([
            'command' => 'move',
            'distance_to_move' => $request->distance,
            'is_executed' => false
        ]);

        return back()->with('success', 'تم إرسال أمر التحرك لمسافة ' . $request->distance . ' متر بنجاح');
    }
}
