<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Defect;
use App\Services\GeminiAgent;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class RobotDataController extends Controller
{
    protected $geminiAgent;

    public function __construct(GeminiAgent $geminiAgent)
    {
        $this->geminiAgent = $geminiAgent;
    }

    public function store(Request $request)
    {
        // 1. التحقق من البيانات (Validation)
        $request->validate([
            'image_1'      => 'required|image|max:5120',
            'image_2'      => 'required|image|max:5120',
            'ultrasonic_1' => 'required|numeric',
            'ultrasonic_2' => 'required|numeric',
            'gps_lat'      => 'required|string',
            'gps_lng'      => 'required|string',
            'mpu_data'     => 'nullable',
        ]);

        try {
            // 2. تحويل الصور لـ Base64 لإرسالها للـ API
            $img1Base64 = base64_encode(file_get_contents($request->file('image_1')));
            $img2Base64 = base64_encode(file_get_contents($request->file('image_2')));

            // 3. استدعاء الأيجنت للتحليل
            $analysis = $this->geminiAgent->analyzeRailwayData($img1Base64, $img2Base64, $request->all());

            if (!$analysis) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'AI Analysis failed. Check logs for details.'
                ], 500);
            }

            // 4. حفظ البيانات إذا كان هناك خطر (High أو Critical)
            if (in_array($analysis['danger_level'], ['high', 'critical'])) {

                return DB::transaction(function () use ($request, $analysis) {
                    // حفظ الصور في التخزين
                    $dateFolder = Carbon::now()->format('Y-m-d');
                    $path1 = $request->file('image_1')->store("defects/{$dateFolder}/cam1", 'public');
                    $path2 = $request->file('image_2')->store("defects/{$dateFolder}/cam2", 'public');

                    // إنشاء السجل في الداتا بيز
                    $defect = Defect::create([
                        'user_id'         => auth()->id() ?? 1, // افتراضي 1 للتجربة
                        'location_lat'    => $request->gps_lat,
                        'location_lng'    => $request->gps_lng,
                        'danger_level'    => $analysis['danger_level'],
                        'gemini_analysis' => $analysis['technical_summary'],
                        'image_1_url'     => Storage::url($path1),
                        'image_2_url'     => Storage::url($path2),
                        'ultrasonic_1'    => $request->ultrasonic_1,
                        'ultrasonic_2'    => $request->ultrasonic_2,
                        'mpu_data'        => is_array($request->mpu_data) ? json_encode($request->mpu_data) : $request->mpu_data,
                        'detected_at'     => Carbon::now(),
                    ]);

                    return response()->json([
                        'status' => 'danger_logged',
                        'message' => 'Warning! High risk detected and saved.',
                        'data' => $defect
                    ], 201);
                });
            }

            // 5. في حالة الحالة سليمة
            return response()->json([
                'status' => 'safe',
                'message' => 'Railway is normal. No danger detected.',
                'analysis' => $analysis['technical_summary']
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Server Exception: ' . $e->getMessage()
            ], 500);
        }
    }
}
