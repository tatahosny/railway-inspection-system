<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\Rule;

class UserManagementController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('admin');
    }

    /**
     * Display all users
     */
    public function index(Request $request)
    {
        try {
            $query = User::query();

            // Search filter
            if ($request->has('search')) {
                $search = $request->search;
                $query->where(function($q) use ($search) {
                    $q->where('name', 'like', '%' . $search . '%')
                      ->orWhere('email', 'like', '%' . $search . '%')
                      ->orWhere('department', 'like', '%' . $search . '%');
                });
            }

            // Role filter
            if ($request->has('role') && $request->role !== 'all') {
                $query->where('role', $request->role);
            }

            // Status filter
            if ($request->has('status') && $request->status !== 'all') {
                $query->where('is_active', $request->status === 'active');
            }

            $users = $query->latest()->paginate(15);

            $stats = [
                'total' => User::count(),
                'admins' => User::where('role', 'admin')->count(),
                'inspectors' => User::where('role', 'inspector')->count(),
                'operators' => User::where('role', 'operator')->count(),
                'active' => User::where('is_active', true)->count(),
                'inactive' => User::where('is_active', false)->count()
            ];

            return view('admin.users.index', compact('users', 'stats'));

        } catch (\Exception $e) {
            Log::error('Error fetching users', ['error' => $e->getMessage()]);
            return redirect()->back()->with('error', 'Failed to load users list.');
        }
    }

    /**
     * Show user creation form
     */
    public function create()
    {
        return view('admin.users.create');
    }

    /**
     * Store new user
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|string|min:8|confirmed',
            'role' => 'required|in:admin,inspector,operator',
            'phone' => 'nullable|string|max:20',
            'department' => 'required|string|max:255',
            'device_id' => 'nullable|string|max:100|unique:users,device_id',
            'is_active' => 'boolean'
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        try {
            $userData = [
                'name' => $request->name,
                'email' => $request->email,
                'password' => $request->password,
                'role' => $request->role,
                'phone' => $request->phone,
                'department' => $request->department,
                'device_id' => $request->device_id,
                'is_active' => $request->has('is_active')
            ];

            $user = User::create($userData);

            Log::info('User created by admin', ['admin_id' => auth()->id(), 'user_id' => $user->id]);

            return redirect()->route('admin.users.index')
                ->with('success', 'User created successfully.');

        } catch (\Exception $e) {
            Log::error('Error creating user', ['error' => $e->getMessage()]);
            return redirect()->back()->with('error', 'Failed to create user.');
        }
    }

    /**
     * Show user edit form
     */
    public function edit($id)
    {
        try {
            $user = User::findOrFail($id);
            return view('admin.users.edit', compact('user'));

        } catch (\Exception $e) {
            Log::error('Error fetching user for edit', ['error' => $e->getMessage()]);
            return redirect()->back()->with('error', 'User not found.');
        }
    }

    /**
     * Update user
     */
    public function update(Request $request, $id)
    {
        $user = User::findOrFail($id);

        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => [
                'required',
                'email',
                Rule::unique('users')->ignore($user->id)
            ],
            'password' => 'nullable|string|min:8|confirmed',
            'role' => 'required|in:admin,inspector,operator',
            'phone' => 'nullable|string|max:20',
            'department' => 'required|string|max:255',
            'device_id' => [
                'nullable',
                'string',
                'max:100',
                Rule::unique('users')->ignore($user->id)
            ],
            'is_active' => 'boolean'
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        try {
            $updateData = [
                'name' => $request->name,
                'email' => $request->email,
                'role' => $request->role,
                'phone' => $request->phone,
                'department' => $request->department,
                'device_id' => $request->device_id,
                'is_active' => $request->has('is_active')
            ];

            // Update password if provided
            if ($request->filled('password')) {
                $updateData['password'] = $request->password;
            }

            $user->update($updateData);

            Log::info('User updated by admin', ['admin_id' => auth()->id(), 'user_id' => $user->id]);

            return redirect()->route('admin.users.index')
                ->with('success', 'User updated successfully.');

        } catch (\Exception $e) {
            Log::error('Error updating user', ['error' => $e->getMessage()]);
            return redirect()->back()->with('error', 'Failed to update user.');
        }
    }

    /**
     * Delete user
     */
    public function destroy($id)
    {
        try {
            $user = User::findOrFail($id);

            // Prevent admin from deleting themselves
            if ($user->id === auth()->id()) {
                return redirect()->back()->with('error', 'You cannot delete your own account.');
            }

            $user->delete();

            Log::info('User deleted by admin', ['admin_id' => auth()->id(), 'user_id' => $id]);

            return redirect()->route('admin.users.index')
                ->with('success', 'User deleted successfully.');

        } catch (\Exception $e) {
            Log::error('Error deleting user', ['error' => $e->getMessage()]);
            return redirect()->back()->with('error', 'Failed to delete user.');
        }
    }

    /**
     * Toggle user active status
     */
    public function toggleStatus($id)
    {
        try {
            $user = User::findOrFail($id);
            $user->update(['is_active' => !$user->is_active]);

            $status = $user->is_active ? 'activated' : 'deactivated';

            Log::info('User status toggled by admin', [
                'admin_id' => auth()->id(), 
                'user_id' => $id,
                'new_status' => $status
            ]);

            return redirect()->back()->with('success', "User {$status} successfully.");

        } catch (\Exception $e) {
            Log::error('Error toggling user status', ['error' => $e->getMessage()]);
            return redirect()->back()->with('error', 'Failed to update user status.');
        }
    }

    /**
     * Show user details and activities
     */
    public function show($id)
    {
        try {
            $user = User::with(['sensorData', 'defects', 'assignedDefects'])->findOrFail($id);
            
            $userStats = [
                'sensor_data_count' => $user->sensorData->count(),
                'defects_detected' => $user->defects->count(),
                'assigned_defects' => $user->assignedDefects->count(),
                'recent_activity' => $user->sensorData()->latest()->limit(10)->get()
            ];

            return view('admin.users.show', compact('user', 'userStats'));

        } catch (\Exception $e) {
            Log::error('Error fetching user details', ['error' => $e->getMessage()]);
            return redirect()->back()->with('error', 'User not found.');
        }
    }
}