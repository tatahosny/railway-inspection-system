<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Defect;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class RobotDataController extends Controller
{
    /**
     * معالجة البيانات القادمة من Raspberry Pi
     */
    public function store(Request $request)
    {
        // 1. التحقق من البيانات المستلمة
        // تم تعديل mpu_data لتكون nullable أو string لسهولة الاختبار من بوست مان
        $request->validate([
            'image_1'      => 'required|image|mimes:jpeg,png,jpg|max:2048',
            'image_2'      => 'required|image|mimes:jpeg,png,jpg|max:2048',
            'ultrasonic_1' => 'required|numeric',
            'ultrasonic_2' => 'required|numeric',
            'gps_lat'      => 'required|string',
            'gps_lng'      => 'required|string',
            'mpu_data'     => 'nullable', // خليناها مرنة عشان متعملش Error 422
        ]);

        try {
            // 2. إعداد الصور وتحويلها لـ Base64
            $img1Base64 = base64_encode(file_get_contents($request->file('image_1')));
            $img2Base64 = base64_encode(file_get_contents($request->file('image_2')));

            // 3. استدعاء Gemini Flash 1.5 للتحليل
            $geminiResponse = $this->analyzeWithGemini($img1Base64, $img2Base64, $request->all());

            // 4. فك تشفير الرد
            $analysis = json_decode($geminiResponse, true);

            // التأكد من أن Gemini أرجع بيانات صحيحة، وإلا نضع قيم افتراضية
            $dangerLevel = $analysis['danger_level'] ?? 'low';
            $summary = $analysis['technical_summary'] ?? 'تحليل تلقائي: لم يتم تحديد تفاصيل';

            // 5. منطق القرار: التخزين في حالة الخطر High أو Critical
            if (in_array($dangerLevel, ['high', 'critical'])) {

                // حفظ الصور
                $path1 = $request->file('image_1')->store('defects/camera1', 'public');
                $path2 = $request->file('image_2')->store('defects/camera2', 'public');

                // حفظ البيانات في قاعدة البيانات
                $defect = Defect::create([
                    'user_id'          => auth()->id() ?? 1,
                    'location_lat'     => $request->gps_lat,
                    'location_lng'     => $request->gps_lng,
                    'danger_level'     => $dangerLevel,
                    'gemini_analysis'  => $summary,
                    'image_1_url'      => Storage::url($path1),
                    'image_2_url'      => Storage::url($path2),
                    'ultrasonic_1'     => $request->ultrasonic_1,
                    'ultrasonic_2'     => $request->ultrasonic_2,
                    'mpu_data'         => is_array($request->mpu_data) ? json_encode($request->mpu_data) : $request->mpu_data,
                    'detected_at'      => Carbon::now(),
                ]);

                return response()->json([
                    'status' => 'alert_created',
                    'message' => 'تم رصد عطل خطير وتنبيه النظام',
                    'analysis' => $analysis,
                    'data' => $defect
                ], 201);
            }

            return response()->json([
                'status' => 'normal',
                'message' => 'حالة القضبان سليمة، لم يتم تسجيل تنبيه',
                'analysis' => $analysis
            ], 200);

        } catch (\Exception $e) {
            Log::error('Robot Sync Error: ' . $e->getMessage());
            return response()->json([
                'status' => 'error',
                'message' => 'حدث خطأ في معالجة البيانات: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * التواصل مع Google Gemini API
     */
    private function analyzeWithGemini($img1, $img2, $sensors)
    {
        $apiKey = config('services.gemini.key');
        $apiUrl = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" . $apiKey;

        // تجهيز بيانات الحساسات للنص
        $mpuText = is_array($sensors['mpu_data']) ? json_encode($sensors['mpu_data']) : $sensors['mpu_data'];

        $prompt = "You are a railway safety expert. Analyze these 2 images and sensor data:
                   Ultrasonic1: {$sensors['ultrasonic_1']}mm, Ultrasonic2: {$sensors['ultrasonic_2']}mm.
                   MPU Data: {$mpuText}.
                   Identify cracks, missing bolts, or track misalignment.
                   Return ONLY a valid JSON object with these keys:
                   'danger_level': ('low', 'medium', 'high', 'critical'),
                   'technical_summary': 'Short Arabic analysis description'";

        $response = Http::post($apiUrl, [
            'contents' => [
                [
                    'parts' => [
                        ['text' => $prompt],
                        ['inline_data' => ['mime_type' => 'image/jpeg', 'data' => $img1]],
                        ['inline_data' => ['mime_type' => 'image/jpeg', 'data' => $img2]],
                    ]
                ]
            ],
            'generationConfig' => [
                'response_mime_type' => 'application/json',
            ]
        ]);

        if ($response->failed()) {
            throw new \Exception("Gemini API Connection Failed");
        }

        return $response->json()['candidates'][0]['content']['parts'][0]['text'];
    }
}
