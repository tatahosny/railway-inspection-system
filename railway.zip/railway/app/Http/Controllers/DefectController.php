<?php

namespace App\Http\Controllers;

use App\Models\Defect;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;

class DefectController extends Controller
{
    /**
     * Get all defects with filters
     */
    public function index(Request $request)
    {
        try {
            $query = Defect::with(['sensorData', 'assignedUser']);

            // Apply filters
            if ($request->has('status')) {
                $query->where('status', $request->status);
            }

            if ($request->has('severity')) {
                $query->where('severity', $request->severity);
            }

            if ($request->has('type')) {
                $query->where('defect_type', 'like', '%' . $request->type . '%');
            }

            // Search
            if ($request->has('search')) {
                $search = $request->search;
                $query->where(function($q) use ($search) {
                    $q->where('defect_id', 'like', '%' . $search . '%')
                      ->orWhere('location', 'like', '%' . $search . '%')
                      ->orWhere('defect_type', 'like', '%' . $search . '%');
                });
            }

            $defects = $query->latest()->paginate(20);

            return response()->json([
                'status' => 'success',
                'data' => $defects,
                'filters' => $request->all()
            ]);

        } catch (\Exception $e) {
            Log::error('Error fetching defects', ['error' => $e->getMessage()]);
            
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to fetch defects'
            ], 500);
        }
    }

    /**
     * Get defect by ID
     */
    public function show($id)
    {
        try {
            $defect = Defect::with(['sensorData', 'assignedUser'])->findOrFail($id);

            return response()->json([
                'status' => 'success',
                'data' => $defect
            ]);

        } catch (\Exception $e) {
            Log::error('Error fetching defect', ['error' => $e->getMessage(), 'defect_id' => $id]);
            
            return response()->json([
                'status' => 'error',
                'message' => 'Defect not found'
            ], 404);
        }
    }

    /**
     * Update defect status
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'status' => 'sometimes|in:open,in_progress,resolved',
            'assigned_to' => 'sometimes|exists:users,id',
            'notes' => 'sometimes|string|max:1000',
            'severity' => 'sometimes|in:low,medium,high'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $defect = Defect::findOrFail($id);
            $updates = $validator->validated();

            // If marking as resolved, set resolved_at
            if (isset($updates['status']) && $updates['status'] === 'resolved') {
                $updates['resolved_at'] = now();
            }

            $defect->update($updates);

            Log::info('Defect updated', ['defect_id' => $id, 'updates' => $updates]);

            return response()->json([
                'status' => 'success',
                'message' => 'Defect updated successfully',
                'data' => $defect->fresh(['sensorData', 'assignedUser'])
            ]);

        } catch (\Exception $e) {
            Log::error('Error updating defect', ['error' => $e->getMessage(), 'defect_id' => $id]);
            
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to update defect'
            ], 500);
        }
    }

    /**
     * Get defect statistics
     */
    public function getStatistics()
    {
        try {
            $totalDefects = Defect::count();
            $openDefects = Defect::where('status', 'open')->count();
            $highSeverityDefects = Defect::where('severity', 'high')->count();
            $resolvedThisWeek = Defect::where('status', 'resolved')
                                    ->where('resolved_at', '>=', now()->subWeek())
                                    ->count();

            $defectsByType = Defect::selectRaw('defect_type, count(*) as count')
                                 ->groupBy('defect_type')
                                 ->get();

            $defectsBySeverity = Defect::selectRaw('severity, count(*) as count')
                                     ->groupBy('severity')
                                     ->get();

            return response()->json([
                'status' => 'success',
                'data' => [
                    'total_defects' => $totalDefects,
                    'open_defects' => $openDefects,
                    'high_severity_defects' => $highSeverityDefects,
                    'resolved_this_week' => $resolvedThisWeek,
                    'defects_by_type' => $defectsByType,
                    'defects_by_severity' => $defectsBySeverity
                ]
            ]);

        } catch (\Exception $e) {
            Log::error('Error fetching defect statistics', ['error' => $e->getMessage()]);
            
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to fetch defect statistics'
            ], 500);
        }
    }

    /**
     * Assign defect to user
     */
    public function assignDefect(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'assigned_to' => 'required|exists:users,id'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $defect = Defect::findOrFail($id);
            $defect->update([
                'assigned_to' => $request->assigned_to,
                'status' => 'in_progress'
            ]);

            Log::info('Defect assigned', [
                'defect_id' => $id,
                'assigned_to' => $request->assigned_to
            ]);

            return response()->json([
                'status' => 'success',
                'message' => 'Defect assigned successfully',
                'data' => $defect->fresh('assignedUser')
            ]);

        } catch (\Exception $e) {
            Log::error('Error assigning defect', ['error' => $e->getMessage(), 'defect_id' => $id]);
            
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to assign defect'
            ], 500);
        }
    }
}