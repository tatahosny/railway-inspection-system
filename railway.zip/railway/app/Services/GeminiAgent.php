<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class GeminiAgent
{
    protected $apiKey;
    protected $apiUrl;

    public function __construct()
    {
        // سحب المفتاح من ملف الـ .env
        $this->apiKey = config('services.gemini.key');

        // اللينك الرسمي والفعال حسب تجربة الـ curl الأخيرة
        $this->apiUrl = "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent";
    }

    public function analyzeRailwayData($img1, $img2, $sensorData)
    {
        // 1. تجهيز البرومبت الهندسي
        $prompt = "You are an Expert Railway Structural Engineer.
        Analyze 2 images from an inspection robot and these sensors:
        - Ultrasonic Left: {$sensorData['ultrasonic_1']}mm
        - Ultrasonic Right: {$sensorData['ultrasonic_2']}mm
        - MPU (Vibration/Tilt): " . json_encode($sensorData['mpu_data']) . "

        TASK: Identify structural defects like cracks, missing bolts, or misalignment.

        OUTPUT FORMAT:
        Return ONLY a valid JSON object:
        {
            \"danger_level\": \"low\" | \"medium\" | \"high\" | \"critical\",
            \"technical_summary\": \"وصف فني دقيق بالعربي للحالة المكتشفة بناءً على الصورة والمستشعرات\",
            \"detected_issues\": [\"crack\", \"bolt_missing\", \"corrosion\"],
            \"confidence_score\": 0.95
        }";

        try {
            // 2. إرسال الطلب لـ Google Gemini
            $response = Http::withHeaders([
                'Content-Type' => 'application/json',
                'X-goog-api-key' => $this->apiKey, // إرسال المفتاح في الهيدر
            ])->post($this->apiUrl, [
                'contents' => [
                    [
                        'parts' => [
                            ['text' => $prompt],
                            ['inline_data' => ['mime_type' => 'image/jpeg', 'data' => $img1]],
                            ['inline_data' => ['mime_type' => 'image/jpeg', 'data' => $img2]],
                        ]
                    ]
                ],
                'generationConfig' => [
                    'response_mime_type' => 'application/json',
                    'temperature' => 0.1, // درجة حرارة منخفضة لضمان الدقة التقنية
                ]
            ]);

            if ($response->successful()) {
                $result = $response->json();
                $text = $result['candidates'][0]['content']['parts'][0]['text'];

                // تنظيف أي علامات Markdown قد يضيفها الموديل
                $cleanJson = str_replace(['```json', '```'], '', $text);

                return json_decode(trim($cleanJson), true);
            }

            // تسجيل الخطأ في حالة فشل الرد
            Log::error('Gemini API Error: ' . $response->body());
            throw new \Exception("Gemini API Error: " . $response->status());

        } catch (\Exception $e) {
            Log::error('Gemini Agent Exception: ' . $e->getMessage());
            return null;
        }
    }
}
