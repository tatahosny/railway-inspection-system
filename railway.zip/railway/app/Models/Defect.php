<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Defect extends Model
{
    use HasFactory;

    /**
     * اسم الجدول المرتبط بهذا الموديل في قاعدة البيانات
     * لارافيل بيفترض تلقائياً إن اسم الجدول هو جمع اسم الموديل (defects)
     */
    protected $table = 'defects';

    /**
     * الأعمدة المسموح بإدخال البيانات فيها جملة واحدة (Mass Assignment)
     * دي الحقول اللي الـ Controller بيبعتها عشان تتخزن
     */
    protected $fillable = [
        'user_id',          // معرف المهندس المشغل
        'location_lat',     // خط العرض (GPS)
        'location_lng',     // خط الطول (GPS)
        'danger_level',     // مستوى الخطر (low, medium, high, critical)
        'gemini_analysis',  // التحليل الفني من الذكاء الاصطناعي
        'image_1_url',      // رابط صورة الكاميرا الأولى
        'image_2_url',      // رابط صورة الكاميرا الثانية
        'ultrasonic_1',     // قراءة حساس السونار الأول
        'ultrasonic_2',     // قراءة حساس السونار الثاني
        'mpu_data',         // بيانات الحركة (JSON)
        'detected_at',      // وقت رصد العطل
    ];

    /**
     * تحديد نوع البيانات لبعض الحقول
     * هنا بنعرف لارافيل إن mpu_data هي JSON عشان يحولها لـ Array تلقائياً
     */
    protected $casts = [
        'mpu_data'    => 'array',
        'detected_at' => 'datetime',
    ];

    /**
     * علاقة: العطل ينتمي لمستخدم (المهندس)
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
