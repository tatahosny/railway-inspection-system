<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class RobotControl extends Model {
    protected $fillable = ['distance_to_move', 'command', 'is_executed'];
}
