<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Support\Facades\Storage; // مهمة للتعامل مع الصور

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * Attributes that are mass assignable.
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'avatar',        // العمود الجديد
        'role',
        'phone',
        'department',
        'device_id',
        'is_active',
        'last_login_at'
    ];

    /**
     * Attributes hidden for serialization.
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Attributes that should be cast.
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'is_active' => 'boolean',
        'last_login_at' => 'datetime'
    ];

    /**
     * دالة Accessor لجلب رابط الصورة الشخصية بسهولة
     * تنادي عليها في الـ Blade كدة: {{ auth()->user()->avatar_url }}
     */
    public function getAvatarUrlAttribute()
    {
        if ($this->avatar && Storage::disk('public')->exists($this->avatar)) {
            return asset('storage/' . $this->avatar);
        }

        // لو ملوش صورة، نرجع صورة افتراضية فيها أول حرف من اسمه
        return 'https://ui-avatars.com/api/?name=' . urlencode($this->name) . '&background=3b82f6&color=fff&size=128';
    }

    /**
     * Automatically hash the password when setting it
     */
    public function setPasswordAttribute($value)
    {
        if (!empty($value)) {
            $this->attributes['password'] = bcrypt($value);
        }
    }

    /**
     * Get the sensor data for the user.
     */
    public function sensorData()
    {
        return $this->hasMany(SensorData::class);
    }

    /**
     * Get the defects for the user.
     */
    public function defects()
    {
        return $this->hasMany(Defect::class);
    }

    /**
     * Get the assigned defects for the user.
     */
    public function assignedDefects()
    {
        return $this->hasMany(Defect::class, 'assigned_to');
    }

    /**
     * Role Checks
     */
    public function isAdmin() { return $this->role === 'admin'; }
    public function isInspector() { return $this->role === 'inspector'; }
    public function isOperator() { return $this->role === 'operator'; }
    public function isActive() { return $this->is_active; }

    /**
     * Query Scopes
     */
    public function scopeAdmins($query) { return $query->where('role', 'admin'); }
    public function scopeActive($query) { return $query->where('is_active', true); }

    /**
     * Get user's device data
     */
    public function deviceData()
    {
        return $this->hasMany(SensorData::class, 'device_id', 'device_id');
    }
}
