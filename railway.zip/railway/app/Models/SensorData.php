<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SensorData extends Model
{
    use HasFactory;

    protected $fillable = [
        'device_id',
        'vibration_value',
        'pressure_value', 
        'temperature_value',
        'deformation_value',
        'vibration_unit',
        'pressure_unit',
        'temperature_unit',
        'deformation_unit',
        'image_path',
        'location',
        'latitude',
        'longitude',
        'defect_detected',
        'defect_type',
        'risk_percentage',
        'severity',
        'timestamp'
    ];

    protected $casts = [
        'vibration_value' => 'decimal:4',
        'pressure_value' => 'decimal:4',
        'temperature_value' => 'decimal:4',
        'deformation_value' => 'decimal:4',
        'latitude' => 'decimal:6',
        'longitude' => 'decimal:6',
        'defect_detected' => 'boolean',
        'risk_percentage' => 'decimal:2',
        'timestamp' => 'datetime'
    ];

    /**
     * Get the user that owns the sensor data.
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get all sensor readings as array
     */
    public function getAllReadingsAttribute()
    {
        return [
            'vibration' => [
                'value' => $this->vibration_value,
                'unit' => $this->vibration_unit,
                'formatted' => $this->vibration_value . ' ' . $this->vibration_unit
            ],
            'pressure' => [
                'value' => $this->pressure_value,
                'unit' => $this->pressure_unit,
                'formatted' => $this->pressure_value . ' ' . $this->pressure_unit
            ],
            'temperature' => [
                'value' => $this->temperature_value,
                'unit' => $this->temperature_unit,
                'formatted' => $this->temperature_value . ' ' . $this->temperature_unit
            ],
            'deformation' => [
                'value' => $this->deformation_value,
                'unit' => $this->deformation_unit,
                'formatted' => $this->deformation_value . ' ' . $this->deformation_unit
            ]
        ];
    }

    /**
     * Get image URL
     */
    public function getImageUrlAttribute()
    {
        if ($this->image_path) {
            return asset('storage/' . $this->image_path);
        }
        return null;
    }

    /**
     * Check if has image
     */
    public function hasImage()
    {
        return !empty($this->image_path);
    }

    /**
     * Scope a query to only include critical defects.
     */
    public function scopeCritical($query)
    {
        return $query->where('defect_detected', true)
                    ->where('severity', 'high');
    }

    /**
     * Get formatted risk percentage
     */
    public function getFormattedRiskAttribute()
    {
        return $this->risk_percentage . '%';
    }
}