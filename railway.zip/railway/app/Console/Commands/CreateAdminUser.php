<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;

class CreateAdminUser extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'user:create-admin';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Create an admin user for the railway inspection system';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $this->info('Creating admin user...');

        $user = User::create([
            'name' => 'System Administrator',
            'email' => 'admin@railway.com',
            'password' => 'admin123',
            'role' => 'admin',
            'department' => 'Administration',
            'phone' => '+201000000000',
            'is_active' => true,
            'email_verified_at' => now(),
        ]);

        $this->info('Admin user created successfully!');
        $this->info('Email: admin@railway.com');
        $this->info('Password: admin123');
        $this->info('You can now login and create more users from the admin panel.');

        return Command::SUCCESS;
    }
}