<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\RobotDataController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProfileController;

/*
|--------------------------------------------------------------------------
| RailGuard Master API - الرابط بين الهاردوير والسيرفر
|--------------------------------------------------------------------------
*/

// --- 1. مسار المزامنة الرئيسي (Raspberry Pi <-> Server) ---
// الراسبري بيبعت داتا الأردوينو (السرعة، الحساسات، الـ GPS) وبياخد أوامر الحركة
Route::post('/robot/sync', [RobotDataController::class, 'store'])->name('api.robot.sync');


// --- 2. مسارات جلب البيانات للداش بورد (Frontend API) ---
Route::prefix('telemetry')->group(function () {

    // جلب السرعة والـ GPS والاهتزاز لحظياً (للتتبع الحي)
    Route::get('/latest', [DashboardController::class, 'getLatestReadings'])->name('api.telemetry.latest');

    // جلب سجل العوارض المكتشفة من جيمناي
    Route::get('/history', [DashboardController::class, 'getHistory'])->name('api.telemetry.history');
});


// --- 3. مسارات التحكم اليدوي (Manual Override) ---
Route::middleware('auth:sanctum')->group(function () {
    // إرسال أمر حركة جديد
    Route::post('/robot/move', [DashboardController::class, 'sendCommand'])->name('api.robot.move');
});


// --- 4. إعدادات الحساب (Profile Settings API) ---
Route::middleware('auth:sanctum')->prefix('profile')->group(function () {
    Route::put('/update', [ProfileController::class, 'update'])->name('api.profile.update');
    Route::put('/password', [ProfileController::class, 'updatePassword'])->name('api.profile.password');
});


// --- 5. اختبار الاتصال (Heartbeat) ---
Route::get('/ping', function () {
    return response()->json([
        'status' => 'online',
        'hardware' => 'Raspberry Pi 5 + Arduino Mega',
        'server_time' => now()->toDateTimeString(),
        'connection' => 'Serial Ready'
    ]);
});
