<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProfileController; // الجديد
use App\Http\Controllers\Api\RobotDataController;
use App\Http\Controllers\Admin\UserManagementController;

/*
|--------------------------------------------------------------------------
| Web Routes - RailGuard System v2.0
|--------------------------------------------------------------------------
*/

// --- 1. المسارات العامة (Public Routes) ---
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/about', [HomeController::class, 'about'])->name('about');
Route::get('/contact', [HomeController::class, 'contact'])->name('contact');

// نظام الدخول (Guest Middleware)
Route::middleware('guest')->group(function () {
    Route::get('/login', [HomeController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [HomeController::class, 'login']);
});

Route::post('/logout', [HomeController::class, 'logout'])->name('logout');


// --- 2. المسارات المحمية (Dashboard & User Profile) ---
Route::middleware(['auth'])->group(function () {

    // عرض الداش بورد (Laravel Blade)
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // صفحة التتبع الحي
    Route::get('/tracking', function () {
        return view('tracking');
    })->name('tracking');

    // إرسال أوامر التحكم للعربية
    Route::post('/robot/move', [DashboardController::class, 'sendCommand'])->name('robot.move');

    // --- الجديد: إدارة الملف الشخصي (Profile) ---
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::put('/profile/password', [ProfileController::class, 'updatePassword'])->name('password.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    // عرض تفاصيل عطل معين
    Route::get('/defects/{id}', [DashboardController::class, 'showDefect'])->name('defects.show');
});


// --- 3. مسارات الإدارة (Admin Panel) ---
Route::middleware(['auth', 'admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::controller(UserManagementController::class)->group(function () {
        Route::get('/users', 'index')->name('users.index');
        Route::get('/users/create', 'create')->name('users.create');
        Route::post('/users', 'store')->name('users.store');
        Route::get('/users/{id}/edit', 'edit')->name('users.edit');
        Route::put('/users/{id}', 'update')->name('users.update');
        Route::delete('/users/{id}', 'destroy')->name('users.destroy');
    });
});


// --- 4. مسارات الـ API (التعامل مع الروبوت والبيانات اللحظية) ---
Route::prefix('api')->name('api.')->group(function () {

    // المسار الرئيسي لاستقبال بيانات الراسبري باي ومعالجتها بـ Gemini
    Route::post('/robot/sync', [RobotDataController::class, 'store'])->name('robot.sync');

    // مسارات جلب البيانات للـ Frontend (Axios)
    Route::get('/defects/latest', [DashboardController::class, 'getLatestDefect'])->name('defects.latest');
    Route::get('/defects/history', [DashboardController::class, 'getHistory'])->name('defects.history');
});
